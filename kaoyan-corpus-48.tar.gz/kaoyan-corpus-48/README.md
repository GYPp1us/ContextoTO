# 考研英语一 · 高密度语料 48 篇（审阅包）

## 这是什么

把考研英语一的考纲词汇嵌进**成篇文章**，让背单词变成读文章。
48 篇文章共 58,815 词，覆盖考纲清单 **2,412/3,000
= 80.4%**。

| 指标 | 实测 | 真题基线 |
|---|---|---|
| 篇数 | 48（30 改写 + 18 定向） | — |
| 总词数 | 58,815 | — |
| 平均词数 | 1,225 | 约束 1,120–1,330 |
| 平均句长 | **21.6** | 22.1 |
| 平均目标词密度 | **29.1%** | 27.3% |
| **可读性 Flesch-Kincaid** | **中位数 12.8** | **12.6**（真题阅读 A 实测） |
| 约束达标 | **48/48** | — |
| 清单覆盖 | **2,412/3,000 = 80.4%** | — |
| 319 个"零语料词" | **319/319 = 100%** | — |

## 目录结构

```
01-30 改写/     n01.md … n30.md   从真实新闻/评论改写压缩而成
31-48 定向/     g01.md … g18.md   为 319 个"零语料词"定向原创
sources/        n01-source.txt …  30 篇改写的源文（仅供对照，勿再分发）
_index.json                       全部指标（机器可读）
```

每个 `.md` 结构：题目与指标 → 正文 → 本篇用到的目标词清单。
**定向篇**额外附"指定靶词表 + 是否用上"，可直接核对是否硬塞。

## 两类文章的区别

**改写篇（n01–n30）**：源文是 204 篇真实新闻/评论（VOA、The Conversation、
Lawfare、SCOTUSblog 等）。保留真实事实、数据与论证结构，删掉新闻器械
（署名、电头、引语归属），把领域词换成清单词、简单词换成高阶词。
**sources/ 里的源文可与成稿对照，看压缩与改写是否得当。**

**定向篇（g01–g18）**：针对 **319 个在 22 年真题阅读与全部 204 篇新闻中
出现次数为 0** 的考纲词（`ankle` `cake` `wolf` `wedding` `cricket` …，
几乎全是生活/身体/自然/叙事类具象词）。新闻文体天然不含这些词，
没有源文可改，只能按题材聚类定向写。每篇承载 7–26 个同域词。

## 审阅时建议重点看

1. **自然度**——有没有"为了塞词而塞"的句子（这是最大风险）。
2. **语域是否像真题**——是否学术-评论文体、有明确论点和论证。
3. **长句是否可读**——FK 年级列已给出，长句比例过高会显得笨重。
4. **定向篇的靶词用法**——`g*.md` 末尾有词表核对，重点看
   `ankle`/`cake`/`wolf` 这类具象词是否被放进了自然场景。
5. **改写篇的事实保真**——对照 `sources/`，看有无事实走样。

## 已知局限（如实说明）

- **平均密度 29.1% 略高于真题基线 27.3%**，是为了给测量误差留余量而有意
  偏高的；若要求严格贴合，可整体下调 2 个百分点。
- **超纲实词仍有个位数到两位数**（表中 `硬词` 列）——人名、机构名、
  以及部分必要领域术语。
- **平均句长 21.7，与真题 22.1 接近但略短。**
- 文章由 LLM 生成。**已经 6 个子代理逐句审校、20 处硬错误已修复**，
  但仍非人工逐句校订；若发现事实错误或语病，请直接标注篇号反馈。

## 全部指标一览

| 篇号 | 类型 | 词数 | 均句长 | 密度 | FK年级 | 超纲实词 | 题目 |
|---|---|---|---|---|---|---|---|
| [n01](01-30%20改写/n01.md) | 改写 | 1,231 | 22.4 | 31.19% | 13.3 | 16 | International law plainly forbids Iran's tolls in the Strait of Hormuz, but  |
| [n02](01-30%20改写/n02.md) | 改写 | 1,320 | 21.0 | 29.77% | 10.9 | 10 | A senator's biography of Justice Clarence Thomas and the debate over origina |
| [n03](01-30%20改写/n03.md) | 改写 | 1,224 | 21.5 | 27.61% | 13.0 | 21 | The collapse of Banco Master and the corrosion of Brazil's system of checks  |
| [n04](01-30%20改写/n04.md) | 改写 | 1,146 | 20.8 | 30.28% | 12.2 | 8 | What the protest art aimed at Ed Sheeran reveals about the politics of pop m |
| [n05](01-30%20改写/n05.md) | 改写 | 1,276 | 22.8 | 31.9% | 13.5 | 12 | The regulatory implementation of domestic procurement preferences and its po |
| [n06](01-30%20改写/n06.md) | 改写 | 1,293 | 21.9 | 30.55% | 11.1 | 1 | Industrial heritage and the politics of memory |
| [n07](01-30%20改写/n07.md) | 改写 | 1,169 | 20.2 | 31.48% | 12.5 | 10 | The growing judicial role in settling election disputes, and its costs for d |
| [n08](01-30%20改写/n08.md) | 改写 | 1,175 | 21.4 | 30.13% | 13.6 | 15 | How environmental change in the Arctic has unsettled both its legal order an |
| [n09](01-30%20改写/n09.md) | 改写 | 1,282 | 21.4 | 28.24% | 11.8 | 9 | The cross-border popularity of Pakistani television drama in India and its l |
| [n10](01-30%20改写/n10.md) | 改写 | 1,223 | 21.1 | 30.83% | 11.9 | 11 | Taryn Simon's Guggenheim installation and the contested nature of American h |
| [n11](01-30%20改写/n11.md) | 改写 | 1,210 | 22.4 | 28.6% | 12.7 | 9 | The political economy of public subsidies for sports stadiums |
| [n12](01-30%20改写/n12.md) | 改写 | 1,250 | 23.1 | 31.76% | 14.9 | 9 | The humanities under threat: Australia's Job-Ready Graduates policy and the  |
| [n13](01-30%20改写/n13.md) | 改写 | 1,140 | 21.9 | 26.75% | 12.1 | 12 | Corporate art patronage, tax deductions, and the public cost of LVMH's gift  |
| [n14](01-30%20改写/n14.md) | 改写 | 1,262 | 21.8 | 31.54% | 14.0 | 16 | Technological optimism about shared abundance versus the politics of taxing  |
| [n15](01-30%20改写/n15.md) | 改写 | 1,233 | 22.4 | 29.76% | 12.8 | 7 | The U.S. Supreme Court's criminal docket and why it should accept more cases |
| [n16](01-30%20改写/n16.md) | 改写 | 1,152 | 21.7 | 30.21% | 13.2 | 7 | Two new books trace Australia's twenty-first-century leadership instability  |
| [n17](01-30%20改写/n17.md) | 改写 | 1,199 | 22.2 | 30.36% | 13.2 | 10 | Disaster preparedness and the myth of technological rescue |
| [n18](01-30%20改写/n18.md) | 改写 | 1,189 | 22.0 | 31.62% | 12.4 | 4 | The escalating tariff dispute between the United States and the European Uni |
| [n19](01-30%20改写/n19.md) | 改写 | 1,210 | 21.6 | 29.59% | 13.1 | 12 | Museums and scholars are reframing colonial histories, and the reckoning dem |
| [n20](01-30%20改写/n20.md) | 改写 | 1,235 | 20.9 | 26.96% | 12.4 | 7 | Harriet Taylor Mill's neglected contribution to political philosophy, and th |
| [n21](01-30%20改写/n21.md) | 改写 | 1,247 | 21.5 | 30.79% | 12.4 | 13 | American public opinion on proposals to reform the Supreme Court |
| [n22](01-30%20改写/n22.md) | 改写 | 1,248 | 21.2 | 26.04% | 12.6 | 16 | Liu Wei's Speculation and the politics of the museum facade |
| [n23](01-30%20改写/n23.md) | 改写 | 1,170 | 20.5 | 29.91% | 12.7 | 8 | The tariff conflict between the United States and its three largest trading  |
| [n24](01-30%20改写/n24.md) | 改写 | 1,172 | 20.6 | 27.82% | 13.8 | 17 | A former Honduran president's pardoned return shows how external pressure an |
| [n25](01-30%20改写/n25.md) | 改写 | 1,255 | 20.9 | 30.68% | 11.3 | 1 | NASA's Spherex mission and the scientific case for surveying the whole sky r |
| [n26](01-30%20改写/n26.md) | 改写 | 1,257 | 21.3 | 31.98% | 12.9 | 11 | The engineering potential of ancient basket weaving |
| [n27](01-30%20改写/n27.md) | 改写 | 1,267 | 22.6 | 30.39% | 13.8 | 14 | How judicial independence and the Senate's confirmation rules have become en |
| [n28](01-30%20改写/n28.md) | 改写 | 1,197 | 22.2 | 26.23% | 12.4 | 11 | The Roosevelt Hotel and the politics of preservation |
| [n29](01-30%20改写/n29.md) | 改写 | 1,222 | 21.8 | 31.1% | 12.9 | 4 | Why economic reform is slow, contested and evidence-driven, as three Austral |
| [n30](01-30%20改写/n30.md) | 改写 | 1,160 | 20.4 | 30.0% | 12.9 | 10 | The structural causes of high diesel prices |
| [g01](31-48%20定向/g01.md) | 定向 | 1,283 | 21.4 | 26.73% | 11.2 | 2 | How household objects preserve family history |
| [g02](31-48%20定向/g02.md) | 定向 | 1,240 | 22.5 | 30.0% | 11.7 | 7 | Backyards and Neighborhoods: How Private Space Shapes Community Relations |
| [g03](31-48%20定向/g03.md) | 定向 | 1,253 | 20.5 | 27.06% | 12.3 | 9 | The Kitchen as Archive: Migration, Food, and Cultural Memory |
| [g04](31-48%20定向/g04.md) | 定向 | 1,214 | 22.5 | 27.1% | 12.0 | 7 | The politics of pain — whose body is believed and treated, and whose is left |
| [g05](31-48%20定向/g05.md) | 定向 | 1,250 | 20.8 | 26.24% | 12.6 | 9 | The tacit knowledge of skilled craft and the limits of automation. |
| [g06](31-48%20定向/g06.md) | 定向 | 1,255 | 21.3 | 28.05% | 13.4 | 11 | Shame and courage — the psychological price reformers pay when they confront |
| [g07](31-48%20定向/g07.md) | 定向 | 1,228 | 22.3 | 28.26% | 13.6 | 3 | The attention economy manufactures desire rather than satisfying it, and res |
| [g08](31-48%20定向/g08.md) | 定向 | 1,204 | 21.1 | 29.15% | 13.3 | 11 | The disappearing neighbours — how urban expansion is quietly reorganising wi |
| [g09](31-48%20定向/g09.md) | 定向 | 1,272 | 21.6 | 26.26% | 12.2 | 7 | Phenological mismatch — how climate warming desynchronises the timing of the |
| [g10](31-48%20定向/g10.md) | 定向 | 1,211 | 21.6 | 28.65% | 13.1 | 9 | The ledger of the land: why the smallholder's exposure to global grain price |
| [g11](31-48%20定向/g11.md) | 定向 | 1,186 | 22.0 | 28.84% | 13.9 | 13 | The price of perfection: what the performance industry extracts from craft a |
| [g12](31-48%20定向/g12.md) | 定向 | 1,245 | 22.6 | 26.51% | 13.2 | 9 | The decline of a cricket club and its town's identity. |
| [g13](31-48%20定向/g13.md) | 定向 | 1,236 | 21.3 | 26.05% | 12.3 | 8 | In a secular age, religious ritual survives not because of what it asserts b |
| [g14](31-48%20定向/g14.md) | 定向 | 1,222 | 21.8 | 28.4% | 14.2 | 8 | After the diploma: how universities define a qualified person |
| [g15](31-48%20定向/g15.md) | 定向 | 1,221 | 21.1 | 26.04% | 12.8 | 7 | The Grammar of Dress: How Clothing Marks Identity and Resistance |
| [g16](31-48%20定向/g16.md) | 定向 | 1,222 | 21.4 | 26.1% | 11.6 | 8 | The gender lessons of fairy tales |
| [g17](31-48%20定向/g17.md) | 定向 | 1,260 | 23.3 | 30.0% | 15.1 | 4 | How scientific claims win acceptance: hypothesis, evidence and the social ma |
| [g18](31-48%20定向/g18.md) | 定向 | 1,199 | 21.0 | 31.03% | 13.2 | 8 | The collapse of trust in public speech is a collapse of listening, not a sho |

---
生成脚本：`kaoyan-vocab/poc/run_tasks.py`（批量生成 + 约束修复循环）、
`check_draft.py`（客观核验）。核验口径：ECDICT `exchange` + `0:` 指针合并屈折形式。


## 语言质量审校（重要，请先读）

48 篇已由 6 个子代理**逐句通读**（约 2,700 句），分 A 类语法错误 /
B 类用词搭配错误 / C 类不自然表达 三类报告。**20 处硬错误已修复**，
另有 20 篇的英美拼写混用已统一。

详见包内 `review/` 目录：

| 文件 | 内容 |
|---|---|
| `review/REVIEW_SUMMARY.md` | 审校方法、原始计数、系统性缺陷、假阳性记录 |
| `review/APPLIED_FIXES.md` | 逐条修复清单（原文 → 修正 → 依据） |
| `review/group1..6_REPORT.md` | 每组 8 篇的逐句审校原始报告（含句号与引用） |

**一条诚实的提醒**：子代理报的原始数字（A 71 / B 89 / C 104）远大于实际修复数
（20 处）。经我逐条复核，大量条目属**可接受变体**被误报（如 `a number of X have`、
`consider X to be`、`series of X that do` 均为正确用法）。我自己写的正则检查
6 条断言里也有 4 条是误报。**这意味着自动审校会系统性高估错误数，
判读 `review/` 里的数字时需要打折。**

审校覆盖：48/48 篇。修复后三项自动检查全部通过：
约束 0/48 越界 · 自然度 48/48 通过 · 拼写混用 0/48。

## 可读性校验（独立验证语域是否像真题）

用 Flesch-Kincaid 年级公式算本语料 48 篇，并与**真题阅读原文**对比：

| | FK 年级 | 平均句长 |
|---|---|---|
| 本语料 48 篇 | **中位数 12.8**（区间 10.9–15.1） | 21.6 词 |
| 真题阅读 A（73,100 词实测） | **12.6** | 20.9 词 |

两者几乎重合（差 0.2 个年级），说明这批文章的**语言难度落在真题区间内**，
不是偏易或偏难的仿制品。这是除密度/句长之外，对"像不像真题"的独立检验。
