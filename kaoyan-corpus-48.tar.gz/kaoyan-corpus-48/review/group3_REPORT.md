# 组3 语法审校报告

审校范围：`/root/DSH/kaoyan-vocab/internal/grammar_review/group3/` 下全部 8 篇、共 457 句，逐句通读。
分类约定：**A 类**=语法/形态错误（含冠词、时态、一致、平行、指代、介词、专名大小写，以及同一篇内英美拼写混用）；**B 类**=用词/搭配错误；**C 类**=语法无误但不自然（每篇最多 3 条）。
拿不准的条目一律标注「存疑」，不计入"确定错误"的错觉，但仍列入表中。**未发现问题的篇目已明确写明。**

## 总览
| 篇名 | A类 | B类 | C类 |
|---|---|---|---|
| article_03 | 3 | 3 | 3 |
| article_09 | 6 | 4 | 3 |
| article_15 | 1 | 0 | 3 |
| article_21 | 2 | 3 | 3 |
| article_27 | 3 | 2 | 3 |
| B_饮食与烹饪 | 5 | 8 | 3 |
| E_自然与动物_2 | 4 | 5 | 3 |
| K_服饰与外观 | 4 | 5 | 3 |

**总计：A类 28 处，B类 30 处，C类 24 处**

其中标注「存疑」者：A 类 9 处、B 类 3 处。若只计确定错误，则为 **A类 19 处、B类 27 处**。

---

## A 类：语法错误

### article_03
- **[句 41]** 原文：`Police recovered the banker's side of conversations with this justice, which suggest an unusual degree of intimacy between the two men.` ｜ 问题：关系代词 `which` 的先行项是 `conversations`（复数）还是整个 `the banker's side of conversations`（单数）无法判定，谓语 `suggest`（复数）与最贴近的中心名词 `side` 冲突，属主谓一致/指代不明。｜ 建议：`...the banker's side of the conversations, which suggests an unusual degree of intimacy...`（**存疑**：把 `which` 理解为 `conversations` 亦勉强可通，但读者需要回读。）
- **[句 17]** 原文：`In Brazil, Congress executes the budget as much as it legislates, and congressional earmarks became mandatory.` ｜ 问题：`executes the budget as much as it legislates` 把及物短语 `executes the budget` 与不及物动词 `legislates` 并列比较，平行结构被破坏，原意（国会既立法也执行预算）被读成"执行预算的程度等同于立法的程度"。｜ 建议：`In Brazil, Congress implements the budget as well as legislating it, and...`（**存疑**：若按省略理解为 `as much as it legislates [the budget]` 亦可辩解，但歧义明显。）
- **[句 2] / [句 30] / [句 32]** 原文：`now awaits judgment` ／ `political favours` ／ `favoured the bank's businesses` ｜ 问题：**同一篇内英美拼写混用**：全篇其余拼写为英式（`favours`、`favoured`、`recognise` 型），但 [句 2] 用美式 `judgment`（英式应为 `judgement`）。｜ 建议：统一为英式 `judgement`，或全篇改美式 `favors / favored`。

### article_09
- **[句 18]** 原文：`For older audience the habit began long before the network, when a determined household could sometimes catch a signal from Pakistan's state broadcaster.` ｜ 问题：**可数名词单数 `audience` 前缺限定词**（冠词错误）。｜ 建议：`For an older audience the habit began...` 或 `For older audiences the habit began...`
- **[句 5]** 原文：`The series is one of about a hundred that Pakistan produces every year, an industry that employs several thousand individuals.` ｜ 问题：同位语 `an industry` 语法上只能指前面的 `one of about a hundred [series]`，而"一部剧"不是"一个产业"，同位语错位导致主谓语义不搭。｜ 建议：`...every year; the industry employs several thousand individuals.`（改分号独立成句）
- **[句 21]** 原文：`Two decades later she was viewing the same series with her own daughter, and they had lost none of their appeal.` ｜ 问题：**代词指代不明**：`they` 最自然的先行项是 `she and her daughter`（复数人），但 `their appeal` 要求 `they` 指 `the series`（单数）。｜ 建议：`...and the series had lost none of its appeal.`
- **[句 4]** 原文：`Within a period of months, a considerable audience will view that furniture, and a good many of them will be viewing from India.` ｜ 问题：前句用单数集合名词 `a considerable audience`，后半句 `a good many of them` 却要求复数先行词，**代词与先行词数不一致**。另 `will be viewing` 用将来进行时表一般将来，时态选择不当。｜ 建议：`...a considerable audience will view that furniture, and a good many of those viewers will be watching from India.`（**存疑**：`audience` 作集合名词时数可变，但同句内必须一致。）
- **[句 28]** 原文：`After a period of official statement, such direct experience of a neighboring culture is difficult to ignore.` ｜ 问题：`of official statement` 中 `statement` 为可数名词单数，在 `a period of + N` 框架内无冠词、无复数，属**限定词缺失**。｜ 建议：`After a period of official statements, ...`（**存疑**：作者或想用 `statement` 作不可数抽象名词，但英语中不成立。）
- **[句 1] / [句 20] / [句 26] / [句 28] / [句 50]** 原文：`at the centre of the plot` ／ `the neighbor was a producer` ／ `the titles of neighborhoods` ／ `of a neighboring culture` ｜ 问题：**同一篇内英美拼写混用**：[句 1] 用英式 `centre`，其余四处用美式 `neighbor / neighborhoods / neighboring`，文中平行处（如 [句 50] `the neighbor would take everything from India`）应与之统一。｜ 建议：全篇统一（推荐 `centre / neighbour / neighbourhood` 或 `center / neighbor / neighborhood` 二选一）。

### article_15
- **[句 32]（对照 [句 18]、[句 29]、[句 2]）** 原文：`it therefore ought to be treated as part of the binding judgment of the court.` ｜ 问题：**同一篇内英美拼写混用**：文中为英式体系——`per cent`（[句 2]）、`offence`（[句 12]、[句 53]）、`emphasised`（[句 18]）、`recognised`、`self-defence`（[句 29]）——唯独 [句 32] 用美式 `judgment`（英式应为 `judgement`）。｜ 建议：改为 `judgement`（或全篇转美式）。
- **本篇其余部分未发现语法错误。** 值得肯定的是几处易错点均正确：`must consist of twelve members`（[句 42] 用 `consist of` 而非 `comprise`）、`anticipate questions from justices`（[句 33] 后接名词而非不定式）、`depends less on X than on Y`（[句 48]）、`neither could have been in common use`（[句 36]）。

### article_21
- **[句 56]** 原文：`A survey can tell us what people think; it cannot tell us how firmly they hold their views, or how much they understand of what they are being asked.` ｜ 问题：句末 `what they are being asked` 是 `ask sb sth` 的被动形式，宾语槽位空缺，`understand of what they are being asked` 语义不完整（缺 `about` 或补语）。｜ 建议：`...or how much they understand of what they are being asked about.`
- **[句 16] / [句 28]** 原文：`drew support from fifty-three percent and opposition from forty-seven.` ／ `from forty-seven percent to forty-three over two months` ｜ 问题：并列数字中第二项**省略 `percent` 不当**：[句 16] 的 `forty-seven`、[句 28] 的 `forty-three` 都悬空，读者需自行补回单位；[句 28] 中 `forty-three` 还与 `over two months` 邻接，易被误读为"降至 43（个百分点）用了两个月"。｜ 建议：`...from fifty-three percent to forty-seven percent.` ／ `from forty-seven percent to forty-three percent over two months`（**存疑**：新闻体偶见此种省略，但此处已影响理解。）
- **本篇拼写内部一致（全美式 `percent / favor / favored / practice`），未发现英美混用。**

### article_27
- **[句 37]** 原文：`It weighs the risk that an unfavourable ruling will produce a precedent harder to dislodge than the problem the case was meant to solve.` ｜ 问题：**比较结构不平行**：把 `a precedent`（可"推翻"）与 `the problem`（可"解决"）直接对比，`harder to dislodge than the problem ... solve` 中被比较项与比较动词不匹配。｜ 建议：`...a precedent harder to dislodge than the problem was to solve.`（补出 `was to solve`，使两端都能挂上 `hard`）
- **[句 16]** 原文：`particularly the court of appeals for the District of Columbia.` ｜ 问题：**专有名词大小写错误**，该法院的正式名称为 `the United States Court of Appeals for the District of Columbia Circuit`，`Court of Appeals` 须大写。｜ 建议：`particularly the Court of Appeals for the District of Columbia Circuit.`
- **[句 40]** 原文：`What makes these arguments so difficult to resolve, however, is that the two mechanisms are intimately connected.` ｜ 问题：`these arguments` 无明确先行项——前文 [句 33]–[句 39] 谈的是律师的诉讼策略与案件选择，并非"论点"。**代词指代不明**。｜ 建议：`What makes these disputes so difficult to resolve...`（**存疑**：若把 [句 35] `Strategy matters as much as preparation` 视为"论点"，勉强可通。）

### B_饮食与烹饪
- **[句 11]** 原文：`Consider, for a moment, what such a vessel contains and where each of its ingredients originally derived.` ｜ 问题：`derive` 表"起源于"时为不及物动词，必须带 `from`；此处用疑问副词 `where` 替代了 `from where`，**介词缺失**，`where ... derived` 不成立。｜ 建议：`...and from where each of its ingredients originally came.`
- **[句 12]** 原文：`The tomato, now inseparable from southern European cookery, reached the Mediterranean only after 1520, transported home from Mexico via Spanish ships.` ｜ 问题：**悬垂修饰/逻辑主语错位**：分词短语 `transported home` 的逻辑主语是 `the tomato`，而 `home` 只能指主语自己的家——番茄被运离墨西哥，墨西哥不是它的"家"，语义自相矛盾（真正要表达的是"被运回欧洲"）。｜ 建议：`...reached the Mediterranean only after 1520, carried to Europe from Mexico in Spanish ships.`
- **[句 35]** 原文：`Garlic was crushed upon the flat of a knife and left to sit, a technique that liberates a sharper flavor than mincing ever does.` ｜ 问题：**介词搭配错误**：用刀面拍蒜是 `crush with / under the flat of a knife`，`upon` 表示"在……之上"，与"拍"这一动作不搭。｜ 建议：`Garlic was crushed with the flat of a knife and left to sit...`
- **[句 45]** 原文：`A salad is imported from other continents, a mushroom is cultivated within the dark, and a nut is transported within vacuum packs to factories that crush them into paste.` ｜ 问题：**代词与先行词数不一致**：三个并列小句的主语都是泛指单数（`a salad / a mushroom / a nut`），末句却用复数 `them` 回指 `a nut`。｜ 建议：`...to factories that crush them into paste` → `...to factories that crush it into paste`（或统一改为复数 `Salads ... mushrooms ... nuts ... them`）。
- **[句 19]** 原文：`that instability constitutes one reason official records seldom trace such preparations at all.` ｜ 问题：`one reason` 后接同位从句时省略 `why`，在正式书面语中不合规范。｜ 建议：`...constitutes one reason why official records seldom trace such preparations at all.`（**存疑**：美式口语及部分新闻体接受 `the reason + 从句`，但本文语域为书面正式体。）
- **拼写核查：全篇统一为美式（`neighbors / labor / practice / judgment / traveled`），未发现英美混用。**

### E_自然与动物_2
- **[句 24]** 原文：`Species that navigate by scent across vast, featureless ocean may find their prey harder to locate as the chemistry of the water alters.` ｜ 问题：**冠词缺失**：`ocean` 在此为可数名词单数（`the ocean`），前面不能裸用。｜ 建议：`...across the vast, featureless ocean...` 或 `...across vast, featureless stretches of ocean...`
- **[句 16]** 原文：`The chick that hatches to meet the caterpillar has missed its meal.` ｜ 问题：**时态错误**：该句陈述物候错配的一般规律（无时间状语，前句 [句 14] 亦为 `may advance ... barely shifts` 的一般现在时），`has missed`（现在完成）表达"迄今已错过"的完成义，与泛指的规律陈述不符。｜ 建议：`The chick that hatches to meet the caterpillar misses its meal.`
- **[句 48]** 原文：`Evolution could, in principle, retune those clocks, but the process is slow and the change is rapid.` ｜ 问题：`the change` 无明确先行项（[句 46] 用 `conditions ... change`，[句 12] 起谈的是整体变暖），**指代不明**且与 `the process`（=演化）对比对象模糊。｜ 建议：`...but evolution is slow and the warming is rapid.`（**存疑**：读者可自行还原，但需回读。）
- **[句 56]** 原文：`That would constitute a loss out of all proportion to its cost, because these records provide something that no model or satellite can supply.` ｜ 问题：`its cost` 的 `its` 试图回指"损失"本身（`a loss ... its cost`），形成循环指代；真正要对比的是"维护这些记录的代价"。｜ 建议：`That would constitute a loss out of all proportion to the cost of maintaining them...`（**存疑**。）
- **拼写核查：全篇统一为英式（`digitised`、`generalisation`、`colours`、`towards`、`programme`），未发现英美混用。**

### K_服饰与外观
- **[句 5]** 原文：`it is enforced not by textbooks but by stares, exclusions and, occasionally, by legislation.` ｜ 问题：**平行结构破坏**：`not by X but by Y, Z and, occasionally, by W` 中，第三项重复使用 `by`，使 `stares, exclusions` 与 `legislation` 不再处于同一层级。｜ 建议：`...but by stares, exclusions and, occasionally, legislation.`（删去第二个 `by`）
- **[句 26]** 原文：`The modern state has been equally inventive when it wished to disarm a defeated people.` ｜ 问题：**时态错误**：现在完成时 `has been` 与时间从句中的过去时 `wished` 冲突，二者需一致（要么全现在，要么全过去）。｜ 建议：`The modern state is equally inventive when it wishes to disarm a defeated people.` 或 `The modern state was equally inventive when it wished to...`
- **[句 27]** 原文：`After the Jacobite rising of 1745, the British parliament prohibited Highland dress in Scotland...` ｜ 问题：**专有名词大小写错误**：英国议会为 `Parliament`，须大写。｜ 建议：`the British Parliament prohibited...`
- **[句 9] / [句 14] / [句 19] / [句 20] / [句 22] / [句 37] / [句 44] / [句 48] / [句 52]** 原文：`a single color` ／ `towards Western habits` ／ `the wrong shade of grey` ／ `Each offence` ／ `had long been honored` ／ `converting a color` ／ `practiced by feminist` ／ `their enrollment` ／ `Its grey conventions` ｜ 问题：**同一篇内英美拼写混用最严重**：美式 `color`（[句 9]、[句 37]）、`honored`（[句 22]）、`enrollment`（[句 48]）、`practiced`（[句 44]）与英式 `grey`（[句 19]、[句 52]）、`offence`（[句 20]）、`towards`（[句 14]）在同一篇内交替出现。｜ 建议：全篇统一（若取美式，则 `grey → gray`、`offence → offense`、`towards → toward`；若取英式，则 `color → colour`、`honored → honoured`、`enrollment → enrolment`、`practiced → practised`）。

### 跨篇：英美拼写混用汇总
| 篇名 | 内部是否混用 | 证据 |
|---|---|---|
| article_03 | **是** | `judgment`（句 2，美）vs `favours`/`favoured`（句 30/32，英） |
| article_09 | **是** | `centre`（句 1，英）vs `neighbor`/`neighborhoods`/`neighboring`（句 20/26/28/50，美） |
| article_15 | **是** | `judgment`（句 32，美）vs `per cent`/`offence`/`emphasised`/`recognised`/`self-defence`（英） |
| K_服饰与外观 | **是（最严重）** | `color`/`honored`/`enrollment`/`practiced`（美）vs `grey`/`offence`/`towards`（英） |
| article_21 | 否（全美式） | `percent`×5、`favor`、`favored`、`practice` |
| article_27 | 否（基本英式） | 仅 `unfavourable`（句 37）；`practice` 英式名词亦拼作 `practice`，非混用 |
| B_饮食与烹饪 | 否（全美式） | `neighbors`、`labor`、`practice`、`judgment`、`traveled` |
| E_自然与动物_2 | 否（全英式） | `digitised`、`generalisation`、`colours`、`towards`、`programme` |

**结论：8 篇中 4 篇存在篇内英美拼写混用**（article_03、article_09、article_15、K_服饰与外观），其中 K 篇最严重。另需注意"定向生成"三篇各自自洽但彼此不一致（B 全美、E 全英、K 混合），若作为同一套模拟题交付，建议由统一编辑器一次性统一。

---

## B 类：用词错误

### article_03
- **[句 22]** 原文：`The Supreme Court, meanwhile, legislates whenever lawmakers reach a standstill...` ｜ 问题：`reach a standstill` 是搭配生造——`reach` 搭配 `deadlock / impasse / agreement`，`standstill` 则搭配 `come to / bring to`。｜ 建议：`...whenever lawmakers reach a deadlock...` 或 `...come to a standstill...`
- **[句 44]** 原文：`That justice, an Evangelical Christian, has since become a devotional figure at far-right rallies.` ｜ 问题：`devotional` 修饰"物/活动"（`devotional music`），不能指"受人崇敬的人物"；此处词义误用。｜ 建议：`...has since become a revered figure at far-right rallies.`
- **[句 2]** 原文：`He was initially detained as a flight risk...` ｜ 问题：`as a flight risk` 把"潜逃风险"当成身份标签，与 `detained` 的搭配勉强；更规范的是 `detained on the ground that he posed a flight risk`。｜ 建议：`He was initially detained on the ground that he posed a flight risk...`（**存疑**：法律新闻报道中 `detained as a flight risk` 确有使用。）

### article_09
- **[句 2]** 原文：`A young lady has opposed her senior relatives, and her quality as a partner is now in doubt.` ｜ 问题：两处搭配生硬——`her quality as a partner` 应为 `her suitability as a partner`；`opposed her senior relatives`（"反对长辈"）不是英语中表达"违抗长辈"的说法。｜ 建议：`A young woman has defied her elders, and her suitability as a partner is now in doubt.`
- **[句 25]** 原文：`for most Indians a tour to Pakistan is an impossibility rather than a proposal.` ｜ 问题：`a tour to + 地点` 搭配错误（应为 `a trip to / a visit to`）；`an impossibility rather than a proposal` 语义对立错位——"不可能"的对照项应是"只是不吸引人/不明智"，而 `proposal`（提议）与之不同范畴。｜ 建议：`...a trip to Pakistan is an impossibility rather than merely an unattractive option.`
- **[句 35]** 原文：`saying that what Bollywood is to India, the series is to Pakistan.` ｜ 问题：`what X is to A, Y is to B` 句型中 Y 必须是类指名词，而定冠词 `the series` 是回指上文的具体指称，无法承担类指，导致句子读不通。｜ 建议：`...what Bollywood is to India, Pakistani drama is to Pakistan.`（或 `...so the drama series is to Pakistan`）
- **[句 22]** 原文：`The characters feel familiar to her, and at the same time they offer a relief from ordinary living.` ｜ 问题：`ordinary living` 是生造搭配（英语说 `ordinary life` / `everyday life`）；`a relief` 用于"从……中得到宽慰"通常作不可数。｜ 建议：`...they offer relief from ordinary life.`（**存疑**：`a relief from X` 在英语中确有零星用例，主要问题在 `ordinary living`。）

### article_15
- **未发现用词/搭配错误。** 本篇 `consist of`、`account for`、`turn on`、`rest on`、`ought to be treated as`、`in common use at the founding` 等搭配均准确；无 `comprise`/`constitute` 误用，无 `anticipate + to do` 类错误。

### article_21
- **[句 54]** 原文：`...and the shared vocabulary in which constitutional argument once took place has grown thinner.` ｜ 问题：`a vocabulary in which an argument takes place` 搭配错位——"论证"是在"议题/框架"中进行的，"词汇"是论证所使用的工具。｜ 建议：`...the shared vocabulary in which constitutional argument was once conducted has grown thinner.`
- **[句 43]** 原文：`These are serious objections rather than mere excuses, and any honest account of the debate must contain them.` ｜ 问题：`account ... must contain them` 词义误用——`contain` 指"内部盛有"，此处要表达的是"必须回应/纳入讨论"。｜ 建议：`...must address them.`（或 `must take them into account`）
- **[句 27]** 原文：`Republicans and Democrats disagreed sharply about expansion, yet they agreed about ethics...` ｜ 问题：`expansion` 单独使用指代不明——全文 [句 15]–[句 16] 说的是增加大法官人数，此处应明确为 `court expansion`。｜ 建议：`...disagreed sharply about court expansion...`（**存疑**：可从上下文还原，但本篇此处首次单用 `expansion` 作名词。）

### article_27
- **[句 7]** 原文：`judges who need not seek re-election can decide cases by law rather than by majority preference.` ｜ 问题：**介词搭配错误**：`decide by law` 不成立，"依法律裁判"是 `decide according to law` 或 `decide on the law`。｜ 建议：`...can decide cases according to law rather than by majority preference.`
- **[句 20]** 原文：`the bench would be occupied by a very different category of justices.` ｜ 问题：`a very different category of justices` 是生造的量化说法，"另一类法官"英语说 `a very different kind of justice`。｜ 建议：`...the bench would be occupied by a very different kind of justice.`（**存疑**：`category` 可用于人，但与 `very different` 连用不自然。）

### B_饮食与烹饪
- **[句 13]** 原文：`For two full centuries northern Europeans cultivated it as a garden ornament and suspected it of poison.` ｜ 问题：**搭配错误**：`suspect sb/sth of + 名词` 要求表示"罪行/过错"的名词（`theft`, `bias`），`poison` 是物质而非过错，不能作 `of` 的宾语。｜ 建议：`...and suspected it of being poisonous.`（或 `thought it poisonous`）
- **[句 14]** 原文：`Peasants within the south, by contrast, consumed it daily, sliced with oil and salt or simmered into a sauce.` ｜ 问题：**动作主体/工具错位**：`sliced with oil and salt` 把油和盐当成"切"的工具；实际是"切片后以油盐调味"。｜ 建议：`...consumed it daily, sliced and dressed with oil and salt, or simmered into a sauce.`
- **[句 17]** 原文：`a carrot could be extracted from any decent garden` ｜ 问题：**用词不当**：`extract` 用于拔胡萝卜是伪雅用词（extract 用于牙齿、矿物、数据）。｜ 建议：`a carrot could be pulled from any decent garden`
- **[句 27]** 原文：`Once a dish is adopted by the rich, it forfeits its association with the individuals who invented it, while the practitioners themselves persist invisible.` ｜ 问题：两处错误——(1) `forfeit` 要求有意志的主体（放弃权利/财产），"一道菜"不会 forfeit，应为 `loses`；(2) `persist invisible` 是生造搭配，`persist` 不接形容词补语，应为 `remain invisible`。｜ 建议：`...it loses its association with the people who invented it, while the cooks themselves remain invisible.`
- **[句 29]** 原文：`it is precisely how a cuisine is appropriated while its practitioners are confined to the door.` ｜ 问题：**搭配错误**：`confined to the door` 不是英语，"被挡在门外"是 `kept at the door` / `left on the doorstep`。｜ 建议：`...while its practitioners are kept at the door.`
- **[句 33]** 原文：`She never wrote anything down, and when my mother endeavored to document her measurements, the figures proved erroneous.` ｜ 问题：**词义误用**：`erroneous` 用于命题、结论之"错误"，量取不准应是 `inaccurate`。｜ 建议：`...the figures proved inaccurate.`
- **[句 39]** 原文：`Something had gone missing within the crossing, and the cookbooks that purport to conserve it petrify what was once fluid.` ｜ 问题：**词义误用**：`conserve` 指保护自然资源/防止损耗，此处应为 `preserve`（保存）。｜ 建议：`...the cookbooks that purport to preserve it petrify what was once fluid.`
- **[句 45]** 原文：`A salad is imported from other continents, a mushroom is cultivated within the dark...` ｜ 问题：**动作主体错位**：被进口的是色拉的原料（生菜等），不是"色拉"本身。｜ 建议：`Salad greens are imported from other continents, mushrooms are cultivated in the dark, and nuts are transported...`

### E_自然与动物_2
- **[句 12]** 原文：`Temperature constitutes the primary mechanism behind these shifts: warmth accelerates the development of buds, eggs and seeds...` ｜ 问题：**词义误用**：温度不是"机制"，而是驱动力/成因；`constitute`（构成）用在此处属典型的 constitute/comprise 混用。｜ 建议：`Temperature is the primary driver of these shifts: ...`
- **[句 15]** 原文：`Such variation is never uniform; it is evident by region, by altitude and by species...` ｜ 问题：**语义自相矛盾**：`variation`（差异）按定义就不可能是"uniform"（一律的），该判断近乎同义反复。｜ 建议：`Such variation follows no uniform pattern; it differs by region, by altitude and by species...`
- **[句 25]** 原文：`the cliff is a cage whose walls are constituted by geography.` ｜ 问题：**搭配错误**：`constituted by` 表"由……组成/设立"（如委员会由……组成），"高墙由地理构成"应为 `formed by`。｜ 建议：`...the cliff is a cage whose walls are made of geography.`
- **[句 30]** 原文：`Deprived of a sufficient signal, some seeds remain asleep in the clay for a second winter, or a third.` ｜ 问题：**用词不当**：种子是 `dormant`，"睡着了"（`asleep`）用于种子属不当拟人；`clay`（黏土）是土壤类型，此处泛指土壤应为 `soil`。｜ 建议：`...some seeds remain dormant in the soil for a second winter, or a third.`
- **[句 33]** 原文：`registers as a trend when the same mildness returns a decade running.` ｜ 问题：**搭配错误**：`a decade running` 必须与 `for` 连用（`for a decade running`），`returns a decade running` 不是英语。｜ 建议：`...when the same mildness returns for a decade in a row.`

### K_服饰与外观
- **[句 24]** 原文：`A purse, after all, is not a convenience but a substitute for a pocket, and it must be carried rather than merely worn.` ｜ 问题：**语义矛盾**：手袋当然是一种 convenience（便利之物），作者要说的对立项是"并非可有可无的配件，而是口袋的替代品"。｜ 建议：`A purse, after all, is not an accessory but a substitute for a pocket...`
- **[句 15]** 原文：`Barbers stationed at the gates of Moscow were instructed to apply the blade to any chin whose owner had not purchased the privilege of remaining covered.` ｜ 问题：**词义/搭配错位**：剃刀施于的是胡须而非下巴（`apply the blade to any chin` 字面读作"割下巴"）；`the privilege of remaining covered`（"保留遮盖的特权"）也是回避 `beard` 的绕弯说法。｜ 建议：`...to apply the razor to any beard whose owner had not paid the beard tax.`
- **[句 32]** 原文：`The cloth woven on a village wheel became, in this reading, an argument about who possessed the right to supply a nation.` ｜ 问题：**术语误用**：布是在织机（`loom`）上织成的，`wheel` 是纺车（charkha），纺的是纱；本句把 `handloom`（[句 31]）与 `wheel` 混为一谈。另 `the right to supply a nation` 表意含混。｜ 建议：`The cloth woven on a village handloom became...an argument about who had the right to clothe a nation.`
- **[句 48]** 原文：`Here the grammar of dress merges with the grammar of credit, and the purse that women were once denied becomes the instrument of their enrollment as consumers.` ｜ 问题：**与前文自相矛盾**：全文 [句 23]–[句 24] 的论点是"女性被剥夺的是口袋，手袋只是口袋的替代品"，此处却写成"女性曾被剥夺手袋"，指称颠倒。｜ 建议：`...the pocket that women were once denied becomes the instrument of their enrollment as consumers.`
- **[句 3]** 原文：`distinguishing legitimate combinations from illegitimate ones` ｜ 问题：`illegitimate` 用于着装规范时表意不准（该词多指"非婚生/不合法"），此处应为"不被许可的"。｜ 建议：`...distinguishing permissible combinations from impermissible ones.`（**存疑**：`illegitimate` 可引申为"不合规"，但与前句 `regulate` 的语义场不如 `permissible` 贴合。）

---

## C 类：不自然表达（每篇最多 3 条）

### article_03
- **[句 55]** 原文：`Perhaps the deeper issue is not corruption itself but the structure of institutions that makes corruption so effective.` ｜ 问题：`the structure of institutions that makes...` 中关系从句紧贴复数 `institutions`，读者会先按复数理解而被 `makes` 绊住；且 `the structure of institutions` 本身抽象空泛。｜ 建议：`...but an institutional structure that makes corruption so effective.`
- **[句 16]** 原文：`his procedural office could be converted into a sword hanging over the presidency.` ｜ 问题：把"议长职务"比作"悬在总统头上的剑"，前半的 `office`（职位）与后半的 `sword`（器物）喻体断裂，属生硬混合隐喻。｜ 建议：`...that his procedural powers could be turned into a sword hanging over the presidency.`
- **[句 9]** 原文：`Since 2018, Banco Master had signed contracts to manage retirement accounts for state and municipal governments...` ｜ 问题：`Since 2018` 置于句首与过去完成时 `had signed` 搭配，读者会本能期待"自 2018 年起持续"的进行体；此处指反复签约，时态体貌与状语不协调。｜ 建议：`Since 2018, Banco Master had been signing contracts...` 或 `From 2018 onward, Banco Master signed contracts...`

### article_09
- **[句 8] / [句 12] / [句 40]** 原文：`Tv, it seems, is succeeding...` ／ `It is this gap that tv fills...` ／ `India restricts content from across the border on tv as well...` ｜ 问题：缩写形式不统一且不规范：句首用 `Tv`（既非 `TV` 也非 `television`），另两处用小写 `tv`，同一篇三种处理方式。｜ 建议：全篇统一为 `TV`（或统一为 `television`）。
- **[句 3]** 原文：`Two actors perform their lines while a director observes, and in an internal space the owners of the estate wait with their furniture.` ｜ 问题：`in an internal space`（内部空间）与 `wait with their furniture`（带着家具等待）都是从本地语直译而来的生硬表达，母语者会写 `indoors` 与 `sit among their own furniture`。｜ 建议：`...and indoors the owners of the house wait among their own furniture.`
- **[句 7]** 原文：`...and maintained a hostile attitude now in its eighth decade.` ｜ 问题：`an attitude in its eighth decade` 主体错位——有"第八个十年"的是敌对状态而非"态度"；且 `maintained a hostile attitude` 过于书面化。｜ 建议：`...and sustained a hostility now in its eighth decade.`

### article_15
- **[句 21] 与 [句 51]** 原文：`National uniformity on questions of federal law was, after all, among the oldest reasons for establishing a single supreme court.` ／ `National uniformity on questions of federal law is among the oldest reasons for the existence of a supreme court.` ｜ 问题：**近乎逐字重复**：两句相距 30 句，仅时态与末段措辞不同，同一论点被完整复述一遍（其余论证亦多回环，[句 14]–[句 15]、[句 49]–[句 50] 同）。这是全文最突出的行文缺陷。｜ 建议：删去 [句 51]，或将 [句 51] 改为对 [句 21] 的推进（如 `That principle has never been more relevant than it is in criminal cases.`）
- **[句 10]** 原文：`...which accounted for twenty-eight of the disputes, roughly three times the number in civil procedure, the next largest group.` ｜ 问题：三个尾随同位语/补充说明层层堆叠（`twenty-eight of the disputes` → `roughly three times the number in civil procedure` → `the next largest group`），其中 `the next largest group` 紧邻 `civil procedure`，归属含混。｜ 建议：`...which accounted for twenty-eight of the disputes — roughly three times as many as civil procedure, the next largest category.`
- **[句 30]** 原文：`its author listed various longstanding prohibitions that he left undisturbed.` ｜ 问题：`various` 与随后的限定从句 `that he left undisturbed` 语义松散——既未说明"哪些"，也未说明为何要提"未触动"；`longstanding` 宜作 `long-standing`。｜ 建议：`its author listed several long-standing prohibitions that he expressly left undisturbed.`

### article_21
- **[句 32]** 原文：`the cause is likely to lie elsewhere: in a sense that the institution is no longer functioning as its defenders claim it should.` ｜ 问题：`in a sense that...` 与固定短语 `in a sense`（"在某种意义上"）同形，读者第一遍几乎必然误读；且 `the cause lies in a sense`（原因在于一种"感觉"）表达绕。｜ 建议：`...the cause is likely to lie elsewhere: in a growing feeling that the institution no longer functions as its defenders claim it does.`
- **[句 58]** 原文：`Whether the court can recover that confidence without changing, or whether change is the only route to recovery, remains the central question...` ｜ 问题：`recover` / `recovery` 在同一句内同源重复，且两个 `whether` 从句结构不对称（一为动宾、一为主系表），收尾略显拖沓。｜ 建议：`Whether the court can regain that confidence without changing, or whether change is the only way to regain it, remains the central question...`
- **[句 31]** 原文：`Respondents were also asked how far they trusted the justices to decide cases on legal rather than political grounds...` ｜ 问题：`how far they trusted` 是英式用法，在通篇美式语域（`percent`, `favored`）中显得突兀；美式通常用 `how much`。｜ 建议：`Respondents were also asked how much they trusted the justices to decide cases on legal rather than political grounds...`

### article_27
- **[句 14] / [句 40]** 原文：`The second mechanism, the filibuster, is a procedural rule rather than a constitutional one...` ／ `What makes these arguments so difficult to resolve, however, is that the two mechanisms are intimately connected.` ｜ 问题：`the second mechanism`、`these arguments`、`the two mechanisms` 都依赖读者自行回指（首次出现的"第一个机制"从未被如此命名），衔接手法生硬。｜ 建议：[句 14] 改为 `The filibuster, the second of these two mechanisms, is a procedural rule rather than a constitutional one...`；[句 40] 改为 `What makes these disputes so difficult to resolve...`
- **[句 20]** 原文：`the bench would be occupied by a very different category of justices.` ｜ 问题：`a very different category of` + 复数名词是"伪精确"表达，英语更自然的是 `a very different kind of justice`。｜ 建议：`...the bench would be filled by a very different kind of justice.`
- **[句 13]** 原文：`a chief justice who was approached about the problem offered what one participant described as hard pushback.` ｜ 问题：`hard pushback` 是口语化的新闻套语，与本文其余部分（`insulated from`, `reciprocated`, `instruments of partisan advantage`）的正式书面语域不协调。｜ 建议：`...offered what one participant described as firm resistance.`

### B_饮食与烹饪
- **[句 15] / [句 26] / [句 38] / [句 61]，以及 [句 6][句 10][句 16][句 22][句 37][句 39][句 45] 的 `within`** ｜ 原文：`thence into southern Europe` ／ `as a rustic delicacy upon a fashionable menu` ／ `when it finally materialized upon paper` ／ `Any honest account of culture must commence, I conceive, within a kitchen.` ｜ 问题：**伪古雅用词成体系**：`thence`、`upon`（该用 `on` 处一律用 `upon`）、`commence`（该用 `begin`）、`I conceive`（该用 `I think`）、以及 10 次 `within`（多为 `in` 之误，如 `within the bin`、`within the dark`、`within the crossing`），构成明显的"仿古腔"，是全文最大的风格问题。｜ 建议：逐处替换——`thence → and from there`，`materialized upon paper → finally written down`，`must commence, I conceive, within a kitchen → must begin, I think, in a kitchen`，`within → in`（表示"在……之内"之外的场合）。
- **[句 24]** 原文：`Concurrently the wealthy were learning to admire the very same ingredients whenever a French chef incorporated them into cream and cheese.` ｜ 问题：连接词双重不当：句首 `Concurrently` 作状语在英语中极罕见（应用 `At the same time`），且 `whenever`（表"每逢"）与 `were learning`（渐进过程）语义不合。｜ 建议：`At the same time, the wealthy were learning to admire the very same ingredients once a French chef had incorporated them into dishes built on cream and cheese.`
- **[句 32] / [句 34] / [句 45] / [句 52] / [句 56]** 原文：`the peel of a carrot and the peel of a potato entered the pot` ／ `A salad is imported..., a mushroom is cultivated..., and a nut is transported...` ／ `which gratifies the reader and costs the practitioner nothing` ／ `practitioners who can afford to continue culinary practice` ｜ 问题：三行式排比与同义反复贯穿全篇：`the peel of X and the peel of Y`、`a salad...a mushroom...a nut...`、`practice / practitioners / culinary practice` 在同一句内反复换词回环；[句 52] 的 `which` 紧邻 `glossy magazines`，容易被误读为修饰杂志。｜ 建议：[句 34] 改为 `She peeled almost nothing: carrot and potato skins went into the pot with everything else.`；[句 56] 改为 `...it is sustained by cooks who can afford to keep cooking.`；[句 52] 改为 `...and photograph the dishes of immigrant grandmothers for glossy magazines — a gesture that flatters the reader and costs the cook nothing.`

### E_自然与动物_2
- **[句 7] / [句 12]** 原文：`...not through sudden catastrophe, but through a thousand small failures of timing.` ／ `Temperature constitutes the primary mechanism behind these shifts: warmth accelerates the development of buds, eggs and seeds, so a milder February pulls the sequence of spring events forward.` ｜ 问题：连接手段堆叠：[句 7] 在 `not X but Y` 中插逗号；[句 12] 用冒号作解释后又在同句内用 `so` 引出结果，形成"双重因果标记"。｜ 建议：[句 7] 删去 `catastrophe` 后的逗号；[句 12] 改为 `Temperature is the primary driver of these shifts. Warmth accelerates the development of buds, eggs and seeds, so a milder February pulls the sequence of spring events forward.`
- **[句 34]** 原文：`The familiar sequence of the year, blossom and then fruit and then the fall of the leaf, is being rearranged by degrees.` ｜ 问题：`the fall of the leaf` 是 19 世纪诗歌用语（该用 `the falling of the leaves` / `leaf-fall`），`and then...and then` 亦重复；全句语域与本文其余科技说明文不符。｜ 建议：`The familiar sequence of the year — blossom, then fruit, then leaf-fall — is being rearranged by degrees.`
- **[句 8] / [句 23] / [句 43] / [句 55]** 原文：`where individuals happened to be paying careful attention` ／ `no research vessel visits more than approximately once a decade` ／ `assumptions about when things happen` ／ `a programme that has run for a century` ｜ 问题：反复出现的泛化与含糊表达：`individuals`（该用 `people`）、`things happen`（该用具体所指）、`approximately` 与 `more than` 叠用、`has run for a century` 与 `programme` 搭配含糊，整体读来像刻意拉长句子的改写腔。｜ 建议：[句 8] `where people happened to be paying close attention`；[句 23] `that almost no research vessel visits more than once a decade`；[句 43] `assumptions about the timing of natural events`。

### K_服饰与外观
- **[句 16] / [句 39]** 原文：`the sovereign's razor reached further than his decrees, because it operated directly upon the body.` ／ `Authority confronts such inversion with predictable irritation: where the state cannot prosecute, it ridicules, and the mood of officials who feel mocked frequently turns ugly.` ｜ 问题：[句 16] 抽象化过度的断言（razor 比 decree 影响更大）与 `upon` 的伪雅用词；[句 39] 冒号 + `where` + `and` 三重标记叠加，且 `Authority` 作无冠词抽象主语过于格言化。｜ 建议：[句 16] `the sovereign's razor reached further than his decrees, because it worked directly on the body.`；[句 39] `Where the state cannot prosecute, it ridicules; and officials who feel mocked often turn ugly.`
- **[句 34] / [句 35] / [句 41]** 原文：`Everywhere the meaning of a national costume has been settled by conflict rather than by tradition.` ／ `The outcome is usually decided by those who once tried to suppress it.` ｜ `The same mechanism explains why governments are far more anxious about the dress of the young than about the dress of the middle-aged.` ｜ 问题：[句 35] 的 `it` 需跨句回指 [句 34] 的 `meaning`，且"结果由曾试图压制它的人决定"与前句"由冲突决定"逻辑相抵；[句 41] 用 `the dress of the young` / `the dress of the middle-aged` 平行短语同义反复。｜ 建议：[句 35] `The outcome is usually settled by those who once tried to suppress the garment.`；[句 41] `...far more anxious about how young people dress than about how the middle-aged dress.`
- **[句 21] / [句 22] / [句 47]** 原文：`and it is rarely expressed as a logic about power.` ／ `although the prohibition had long been honored chiefly in the breach.` ／ `A single slogan persuaded generations of couples...` ｜ 问题：[句 21] `expressed as a logic about power` 生造搭配；[句 22] `honored chiefly in the breach` 截断了莎士比亚习语（`more honoured in the breach than the observance`），读者会期待后半句；[句 47] 把说服力归于"一句口号"而非广告运动，主体错位。｜ 建议：[句 21] `...and it is rarely presented as a question of power.`；[句 22] `...although the prohibition had long been more honoured in the breach than in the observance.`；[句 47] `A single advertising campaign persuaded generations of couples...`

---

## 整体评价

八篇的语法底盘相当扎实：主谓一致、虚拟语气（`Had sixty votes still been required`, `If every seat were expected`）、从句嵌套与分词结构基本无误，article_15 与 article_27 的法学文体尤为干净，`consist of`、`anticipate + 名词`、`a number of X have` 等易错点均未出错。问题集中在两处：一是**语域与词汇层面的"仿古腔/同义词轮换"**，"定向生成"的三篇（B 饮食、E 自然、K 服饰）尤为明显——`commence`、`thence`、`upon`、`within`、`individuals`、`constitute` 被反复当作高级替代词使用，其中 `constitute` 在 E 篇出现 5 次且多次与 `mechanism`、`geography` 等词搭配失当，属于被明确点名的 constitute/comprise 型误用；二是**英美拼写混用**，8 篇中 4 篇篇内混用（K 篇最严重：`color/honored` 与 `grey/offence` 并存），另有三篇各自自洽但彼此不一致，作为同一套模拟题交付前需统一。此外发现两类系统性缺陷：**动作主体错位**（B 篇 `A salad is imported from other continents`、`transported home from Mexico`，K 篇 `the purse that women were once denied`），以及**同位语/长定语堆叠切断搭配**（article_09 句 5、article_15 句 10、B 篇句 52）。最后，article_15 句 21 与句 51 近乎逐字重复同一论点，是全部八篇中最应优先修掉的单点缺陷。
