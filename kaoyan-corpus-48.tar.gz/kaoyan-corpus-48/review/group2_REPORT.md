# 组2 语法审校报告

审校范围：`/root/DSH/kaoyan-vocab/internal/grammar_review/group2/` 下 8 篇、共 462 句（逐句通读，未抽样）。
判定原则：只报真实语言错误；拿不准的标注"存疑"；`a number of X have`、`the majority of X are`、`species` 单复数同形、`None of these questions has`（正式体）等均属正确用法，不计入错误。

## 总览

| 篇名 | A类 | B类 | C类 |
|---|---|---|---|
| article_02（news30改写） | 1 | 3 | 3 |
| article_08（news30改写） | 1 | 1 | 3 |
| article_14（news30改写） | 1 | 1 | 3 |
| article_20（news30改写） | 2 | 1 | 3 |
| article_26（news30改写） | 0 | 1 | 2 |
| A_居家与日常器物_2（定向生成） | 0 | 1 | 3 |
| E_自然与动物_1（定向生成） | 0 | 0 | 3 |
| J_商业与职场（定向生成） | 0 | 2 | 2 |

**总计：A类 5 处，B类 10 处，C类 22 处**

---

## A 类：语法错误

### article_02

- **[句 47]** 原文：`The Catholic religious belief of his grandfather led Thomas towards the priesthood, and he attended a preparatory seminary, where he was one of only two black youths.` ｜ 问题：主句主语是 `The Catholic religious belief`（祖父的宗教信仰），但 `and he attended a preparatory seminary` 的动作主体变成了 Thomas；前一分句是"信仰引导 Thomas"，后一分句却以 Thomas 作主语，两个分句主语错位，句子实际想说的是"Thomas 因祖父的信仰而走向神职，并进入预科神学院"。 ｜ 建议：`His grandfather's Catholic faith led Thomas towards the priesthood, and he attended a preparatory seminary, where he was one of only two black youths.`

### article_08

- **[句 21]** 原文：`From 1998 the Council began to admit observers, including European and Asian states with a clear interest in Arctic affairs.` ｜ 问题（存疑）：`From 1998` 表示"自 1998 年起持续"，而 `began` 是瞬时动词，两者语义冲突——"开始"这一事件只能发生在某一时点。英语中 `From 1998 the Council admitted observers`（持续义）或 `In 1998 the Council began to admit observers`（瞬时义）各自成立，但 `From ... began` 混用不成立。 ｜ 建议：`From 1998 the Council began admitting observers ...` 或更自然：`In 1998 the Council began to admit observers ...`

### article_14

- **[句 1]** 原文：`In 2036, Elon Musk recently assured an interviewer, money will no longer matter.` ｜ 问题：句首时间状语 `In 2036` 是将来时间点，`recently` 是过去时间副词，二者同时限定主句谓语 `assured`，时间状语自相矛盾。`In 2036` 本是断言内容（宾语从句）的时间，被前置到主句句首后语法上附着到了 `assured` 上。 ｜ 建议：`Elon Musk recently assured an interviewer that in 2036 money will no longer matter.`

### article_20

- **[句 39]** 原文：`In the view of such critics, his love for his wife had clouded his judgment of her intellectual capacities, about which he had been entirely deceived.` ｜ 问题：`be deceived about X` 的意思是"在 X 这件事上受骗/看错"，X 应为判断对象本身。此处 `about which` 的先行词是 `his judgment of her intellectual capacities`，字面成了"他对自己的判断受了骗"，而作者要表达的是"他被（妻子）骗了，因而对她才智的判断完全失准"。介词宾语与先行词的语义关系错位。 ｜ 建议：`... his love for his wife had clouded his judgment of her intellectual capacities, of which he had been entirely deceived.`（或改写为 `... and he had been entirely deceived about those capacities.`）
- **[句 43]** 原文：`But in the twenty-first century it is time that she were recognised as an incisive and influential thinker in her own right.` ｜ 问题（存疑）：`it is time that + 虚拟语气` 的规范形式是 `it is time (that) she was/were ...`（英式常见 `were` 的"过去虚拟"），但更常见、也更不易被判定为错误的是 `it is time she was recognised` 或 `it is time for her to be recognised`。`were` 在此虽见于英式正式文体，与 `recognised` 搭配时读起来偏古旧，且与全文的美式/中性语域不协调。 ｜ 建议：`... it is time that she was recognised as ...` 或 `... it is time for her to be recognised as ...`

**以下篇目 A 类未发现问题：** article_26、A_居家与日常器物_2、E_自然与动物_1、J_商业与职场。

---

## B 类：用词错误

### article_02

- **[句 14]** 原文：`... but about the role that a judge's own principles should perform in a system of constitutional rule.` ｜ 问题：搭配错误。`role` 的搭配动词是 `play` / `serve` / `have`；`perform` 的宾语应是 `duty`、`function`、`task`，不能是 `role`。此处是"角色—职责"的混搭。 ｜ 建议：`... but about the role that a judge's own principles should play in a system of constitutional rule.`
- **[句 46]** 原文：`Every discourse about Thomas's early period, Cruz writes, has its beginning and ending with Myers Anderson ...` ｜ 问题：搭配错误。`have its beginning with` 不是英语说法（英语是 `begin with` / `have its beginning in`），`has its ending with` 同样不成搭配。 ｜ 建议：`Every account of Thomas's early life, Cruz writes, begins and ends with Myers Anderson ...`
- **[句 18]–[句 25]（英美拼写混用）** 原文：句 19 `does not seek honor`、句 24 `does not recognize color`（美式 -or / -ize）与句 18 `is an offence`、句 25 `admissions programmes`（英式 -ce / programme）出现在同一篇内；句 43 `labouring`、句 47 `towards` 亦为英式，而句 42/45 用 `toward`（美式）。 ｜ 问题：同一篇内英美拼写体系不统一。 ｜ 建议：统一为一套（本篇其他用词偏英式，建议统一为 `honour` / `recognise` / `colour` / `offence` / `programme` / `labouring` / `towards`）。

### article_08

- **[句 35]、[句 37]（英美拼写混用）** 原文：句 35 `Militarization plays a part in this process, and it is linked to more than the defence of territory.`；句 37 `... emphasise national security and territorial integrity ...` ｜ 问题：`Militarization`（美式 -ization）与 `emphasise`（英式 -ise）、以及句中 `defence`（英式名词拼写）同篇并用，拼写体系不一致。 ｜ 建议：统一，例如 `Militarisation ... defence ... emphasise`。

### article_14

- **[句 28]** 原文：`... working-class households pay an effective rate of about 45%, the middle classes about 50%, and the upper classes slightly more.` ｜ 问题：用词错误。`effective rate`（有效税率）是各组内每个人真实税负的平均值，本例中这三组各自是一个"平均值"，不能称为 `an effective rate of about 45%`（"大约 45% 的有效税率"读起来像某单一税档）；`typical rate`（典型税率）才是描述分组平均值的词。 ｜ 建议：`... working-class households pay a typical effective rate of about 45%, the middle classes about 50%, and the upper classes slightly more.`

### article_20

- **[句 10]** 原文：`Every human being, she argued, has a right to all personal freedom which does not interfere with the happiness of some other person.` ｜ 问题：搭配与限定不当。`all personal freedom` 把不可数的抽象概念整体化，后面又用限定性 `which` 从句去切分它，逻辑上自相矛盾（"全部自由"无法再被"不干涉他人"这一条件限定）；且 `freedom` 应为复数或加冠词类限定。 ｜ 建议：`Every human being, she argued, has a right to every freedom that does not interfere with the happiness of some other person.` 或 `... has a right to all such personal freedom as does not interfere with the happiness of others.`

### article_26

- **[句 43]** 原文：`The team therefore wants to learn how to modernise and digitalise the ancient craft of three-dimensional weaving.` ｜ 问题（存疑）：用词可疑。表示"把……数字化（转为数字形式/建立数字模型）"的标准动词是 `digitise`（美式 `digitize`）；`digitalise` 虽在商业／科技文宣中偶见（义近"采用数字技术"），但用在此处（把三维编织工艺建模、数据化）并不贴切，与并列的 `modernise` 也不成对。 ｜ 建议：`... how to modernise and digitise the ancient craft of three-dimensional weaving.`

### A_居家与日常器物_2

- **[句 50]** 原文：`They create slots of opportunity for contact, and they also allow residents to manage the mess of shared life without surrendering privacy.` ｜ 问题：搭配错误。`slot` 在英语中固定用于"时段"（`a slot in the schedule`）或"狭缝"（`a slot in the door`），没有 `slots of opportunity` 这一搭配；此处是把"机会的缝隙/入口"逐字直译。 ｜ 建议：`They create small openings for contact ...` 或 `They create opportunities for casual contact ...`

### J_商业与职场

- **[句 27]（对照句 33、[句 47]、[句 48]）（英美拼写混用）** 原文：句 27 `no thesis on organizational behaviour could fully capture`（`organizational` 美式 -ization，`behaviour` 英式 -our）；句 33 `the labour market`、句 47 `honours programmes`、句 48 `rigour and relevance` 均为英式。 ｜ 问题：同一篇内英美拼写体系混用。 ｜ 建议：统一为 `organisational`（英式）或全篇改为美式 `behavior` / `labor` / `honors programs` / `rigor`。
- **[句 12]** 原文：`The dean who chaired the committee, and the professor of an allied discipline who examined the candidate, wished to establish a different question.` ｜ 问题：搭配错误。`establish` 的宾语是事实、制度、联系（`establish a fact / a rule / a link`），不能是 `question`；"提出问题"应为 `pose` / `raise` / `ask`。 ｜ 建议：`... wished to pose a different question.`

**以下篇目 B 类未发现问题：** E_自然与动物_1。

---

## C 类：不自然表达（每篇最多 3 条）

### article_02

- **[句 5]** 原文：`When he visited the justice's chambers earlier this year to propose the project, Thomas gave his accord at once ...` ｜ 问题：伪古雅用词。`give one's accord`（"予以同意"）在现代英语中已属古旧／法律文书用语，且 `accord` 通常指国家间的协定；此处是 `agreed` 的文言化替换。 ｜ 建议：`... Thomas agreed at once ...`
- **[句 42]、[句 53]** 原文：句 42 `His attitude toward existence had a powerful influence on Thomas's character.`；句 53 `... it is the product of a particular existence.` ｜ 问题：抽象名词泛用。`existence` 被用来表达"生活／人生经历"（汉语"存在"的直译），英语中 `attitude toward existence`、`a particular existence` 都显得生硬，母语者会写 `toward life`、`a particular life`。 ｜ 建议：句 42 `His attitude toward life had a powerful influence ...`；句 53 `... the product of a particular life.`
- **[句 44]** 原文：`Physical activity was thought a loss of time, and the only acceptable substitute for work was a tour of the library.` ｜ 问题：搭配生硬。`a loss of time` 意为"时间的损失/耽误"，不能表达"浪费时间"；且 `was thought a loss of time` 省略 `to be` 后更显僵硬。`a tour of the library`（"巡览图书馆"）也偏生硬。 ｜ 建议：`Physical activity was thought a waste of time, and the only acceptable substitute for work was a visit to the library.`

### article_08

- **[句 47]** 原文：`If the Arctic Council still functions, more now seems to divide its members than to unite them.` ｜ 问题：比较结构生硬。`more seems to divide ... than to unite` 把 `more` 提到 `seems` 之前，读起来像"更多的东西似乎分裂成员"，比较项（分裂 vs 团结）被 `seems` 切断。 ｜ 建议：`If the Arctic Council still functions, what divides its members now seems to outweigh what unites them.`
- **[句 7]** 原文：`... the whole structure of Arctic authority appears less stable than it did a generation ago.` ｜ 问题：替代动词不精确。`than it did` 中的 `did` 替代的是 `appears`（系动词），而比较对象是 `stable` 这一形容词状态，`than it did` 抹掉了"显得"这一层，语义滑移。 ｜ 建议：`... appears less stable than it did a generation ago.` → `... appears less stable than it was a generation ago.`
- **[句 43]** 原文：`Because fish are an important global commodity, the regulation of fisheries matters greatly, since warming may shift the distribution of stocks and thus create friction between states.` ｜ 问题：连接词堆叠。一句之内 `Because ... since ...` 两个原因连词并列使用，句内出现两个平行的因果层级，读来累赘。 ｜ 建议：`Fish are an important global commodity; the regulation of fisheries therefore matters greatly, since warming may shift the distribution of stocks and thus create friction between states.`

### article_14

- **[句 3]** 原文：`Retirement saving, he added, will shortly become irrelevant.` ｜ 问题：用词生硬。`shortly` 在当代英语中多用于"不久之后（即将发生的中性事件）"，与 `become irrelevant` 这类判断句搭配显得文白夹杂，且 `will shortly become` 是公文腔。 ｜ 建议：`Retirement saving, he added, will soon become irrelevant.`
- **[句 49]** 原文：`His remedy follows from the diagnosis.` ｜ 问题：段落过渡句过于机械，且 `follow from` 用于"诊断→处方"的比喻时是逻辑推理义（"由……推出"），与后文具体的政策建议（最低税）之间缺少承接，读来像提纲残留。 ｜ 建议：`His remedy follows directly from that diagnosis.` 或直接删除，让句 50 起句。
- **[句 38]** 原文：`... and it has encouraged many people to abandon any expectation of a fairer society, a disillusion that supplies fertile ground for reactionary movements.` ｜ 问题：同位语与先行词距离过远（中间隔两个分句），且 `disillusion` 作可数名词单数（`a disillusion`）不合常规，英语通常用不可数的 `disillusionment`。 ｜ 建议：`... and, by encouraging many people to abandon any expectation of a fairer society, it has created a disillusionment that supplies fertile ground for reactionary movements.`

### article_20

- **[句 23]** 原文：`... and her criticisms were always pro-democratic and anti-aristocratic.` ｜ 问题：生造复合形容词。`pro-democratic`、`anti-aristocratic` 属临时拼合的标签式表达，与 `criticisms`（批评）搭配也不当（批评支持民主，而非"她的批评是亲民主的"）。 ｜ 建议：`... and her criticisms were consistently democratic and hostile to aristocracy.`
- **[句 16]** 原文：`Her views amounted to a programme of reform that would be considered radical even today, let alone two centuries ago.` ｜ 问题：`let alone` 用法不规范。`let alone` 要求前后为同一方向的递进（"连 A 都不，更不用说 B"），此处 `even today` 与 `two centuries ago` 是时间对比而非程度递进，逻辑不搭。 ｜ 建议：`... a programme of reform that would be considered radical even today, and all the more so two centuries ago.`
- **[句 21]** 原文：`With language that was often witty and pithy, she cut to the heart of issues in political thought such as patriarchy, social justice and freedom.` ｜ 问题：`such as` 位置造成歧义——按语法最近的先行词是 `political thought`，字面成了"诸如父权制这样的政治思想"；实际举例对象是 `issues`。 ｜ 建议：`... she cut to the heart of such issues in political thought as patriarchy, social justice and freedom.`

### article_26

- **[句 11]、[句 13]** 原文：句 11 `... fabricated from the same amount and type of substance.`；句 13 `... or to the use of an unusual substance.` ｜ 问题：用词泛化。工程语境下 `substance`（物质）指笼统的"东西"，此处指实验材料，母语者会用 `material`；`an unusual substance` 更易被误读为化学成分。 ｜ 建议：句 11 `... fabricated from the same amount and type of material.`；句 13 `... or to the use of an unusual material.`
- **[句 46]** 原文：`Such textiles could sense, actuate, move about, bear a load and interact safely with human beings at the same time.` ｜ 问题：句末 `at the same time` 悬在五项并列动词之后，读者会先把它读成"同时与人安全互动"，而作者的意图是"这些功能可同时实现"。 ｜ 建议：`Such textiles could simultaneously sense, actuate, move about, bear a load and interact safely with human beings.`

### A_居家与日常器物_2

- **[句 12]** 原文：`The lawn performs a similar function, though more subtly: a neat lawn signals care and invites comment, while a neglected lawn signals trouble and invites concern.` ｜ 问题：同义词反复轮换。`signals ... invites` 在紧邻的两个分句中完全重复，四个动词只用了两个词形，句式机械对仗，读来自动化痕迹明显。 ｜ 建议：`... a neat lawn suggests care and draws comment, while a neglected one hints at trouble and attracts concern.`
- **[句 3]** 原文：`... they are the physical grammar through which neighbors recognize, greet, and assist one another.` ｜ 问题：隐喻生硬。`physical grammar`（"物质语法"）把语言学术语硬套到实体空间上，与后文 `recognize, greet, and assist` 的具体行为之间缺少铺垫。 ｜ 建议：`... they are the physical vocabulary through which neighbors recognise, greet and help one another.` 或更直白：`... they are the physical setting in which neighbours recognise, greet and help one another.`
- **[句 55]** 原文：`... for it is there that the private and the public meet and, occasionally, become friends.` ｜ 问题：轭式搭配（zeugma）。抽象概念 `the private and the public` 与 `become friends` 搭配不当——"私人与公共成为朋友"是拟人化的硬凑，且与全文的 `neighbors`（邻居）主语线索脱节。 ｜ 建议：`... for it is there that private life and public life meet, and where neighbours occasionally become friends.`

### E_自然与动物_1

- **[句 49]** 原文：`The wolf and the elephant command attention, and the funds that follow it; the insect, the worm and the modest patch of nettles that sustains them do not.` ｜ 问题：代词 `it` 指代不明。按语法最近的可选先行词是 `attention`（"随之而来的资金"），但读者也会先把它读成 `The wolf and the elephant` 的回指（应为 `them`），两种读法共存造成歧义；建议把指代对象显化。 ｜ 建议：`The wolf and the elephant command attention, and the funding that follows it; the insect, the worm and the modest patch of nettles that sustains them do not.`
- **[句 35]** 原文：`There is a further irony in the manner whereby cities remember the animals they have displaced.` ｜ 问题：伪古雅用词。`in the manner whereby` 是古旧／法律文体，现代英语用 `in the way (that)` 或 `in how`。 ｜ 建议：`There is a further irony in the way cities remember the animals they have displaced.`
- **[句 5]** 原文：`... researchers observe not outright eradication but an awkward and uneven reorganisation of wildlife, in which a limited number of species prosper alongside people while a much larger number decline almost unnoticed.` ｜ 问题：搭配不当。`reorganisation of wildlife` 字面是"野生动物本身被重组"，作者要表达的是"野生动物群落的构成被重新洗牌"；此外 `while` 引导的对比分句主语 `a much larger number` 与前面的 `a limited number of species` 结构上不对称（一个带 `of species`，一个省略）。 ｜ 建议：`... not outright eradication but an awkward and uneven reorganisation of urban wildlife communities, in which a limited number of species prosper alongside people while a much larger number decline almost unnoticed.`

### J_商业与职场

- **[句 19]** 原文：`The language of dividends has migrated from the stock exchange into the registrar's office, where the dividend that education is expected to yield is measured in salary rather than in understanding.` ｜ 问题：隐喻过度且逻辑迂回。`dividend` 在本句中先作"红利"（股市），再作"教育回报"，但"以薪水而非理解力来计量"把两个不可通约的量并列比较，读者需要回头重读才能确定 `it` 的所指。 ｜ 建议：`The language of dividends has migrated from the stock exchange into the registrar's office: the return that education is expected to yield is now counted in salary rather than in understanding.`
- **[句 49]** 原文：`If universities wish to define the qualified person credibly, they might begin by asking what they would want a colleague, a neighbour or a physician to have learned.` ｜ 问题：情态与语气不搭。`If ... wish ...` 引导的祈使性条件句中用 `might begin by asking`（试探性弱化）与前半句的强烈主张不协调；且 `what they would want X to have learned` 的嵌套使宾语从句主体 `a colleague, a neighbour or a physician` 被三度切分。 ｜ 建议：`If universities wish to define the qualified person credibly, they could begin by asking what they would want a colleague, a neighbour or a physician to have learned.`

---

## 整体评价

八篇在**主谓一致、时态、冠词、语态、悬垂修饰、平行结构**这几类"硬伤"上表现干净：逐句核查未发现一处主谓不一致、冠词缺失/误用、悬垂分词（如 `Living bulls have vanished`、`Melting ice ... is` 主语均正确）或平行结构破坏，`species`、`data`、`majority`、`None of these questions has` 等易错点也均处理正确，说明生成流程的基础语法控制是可靠的。问题集中在两处系统性缺陷：一是**抽象名词与动词搭配的"直译化"**（`give his accord`、`attitude toward existence`、`slots of opportunity`、`a loss of time`、`substance` 代 `material`、`establish a question`），这是汉英转换残留，也是 C 类 22 条的主要来源；二是**英美拼写混用**，article_02、article_08、J_商业与职场 三篇同篇并用 `honor/color/recognize/organizational` 与 `offence/programmes/emphasise/behaviour/labour`，属可一次性修复的系统性问题。此外 article_20、article_02、article_14 各有 1–2 处真正的语法性失误（介词宾语与先行词错位、瞬时动词与 `From+年份` 冲突、句首将来时间状语前置导致的状语冲突），数量少但性质明确。
