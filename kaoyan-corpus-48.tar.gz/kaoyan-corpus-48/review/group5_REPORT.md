# group5 语法与用法审校报告

审校对象：`/root/DSH/kaoyan-vocab/internal/grammar_review/group5/` 下 8 个 `.txt`（共 441 句）。
审校方式：逐句通读全部 8 篇，不抽样。

分类标准：
- **A 类 语法错误**：主谓不一致、时态/语态错、冠词缺失或误用、介词搭配错、从句结构错、悬垂修饰、平行结构破坏、代词指代不明。
- **B 类 用词/搭配错**：词义误用、固定搭配错、词性用错、连接副词逻辑误用（如 `as such` 当 `therefore`）。
- **C 类 不自然**：伪古雅词、同义词反复轮换、连接词堆叠、语域不合。**每篇上限 3 条**。

不计入错误的可接受变体（按要求）：`a number of X have`、`majority of X are`、`consider X to be`、`series of X that do`、限定性关系从句后的类指定冠词（如 `the X on which Y depends`）。

---

## article_05（news30改写，56 句）

### A 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| A1 | [23] | "the definitions of **foreign-assembled and foreign products** were loose enough" | 平行结构破坏：`foreign-assembled` 是形容词性复合词，`foreign products` 是名词短语，二者不能并列作 `of` 的宾语 | 改为 `the definitions of foreign-assembled products and of foreign products`（或 `the definitions of "foreign-assembled" and "foreign" products`） |
| A2 | [47] | "Since the exemption for nonavailable materials covers the very inputs on which domestic glove production depends, **they contend**, the practical result is likely to be…" | 代词指代不明：全篇至此没有复数名词先行词。前句 [46] 是 `A common objection is that…`（无人称），[45] 是 `The department's own data…`，都无法作为 `they` 的先行词 | 补出指代对象：`critics of the rule contend` / `opponents contend`；或改为被动 `it is contended` |

### B 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| B1 | [12] | "**As such**, alternatives are permitted where a product assembled abroad contains only American materials and components." | `as such` 意为"作为……本身／以那种身份"，不能当 `therefore` 用；此处逻辑是"因此/据此" | 改为 `Accordingly,` 或 `On that basis,`（或 `Thus,`） |
| B2 | [29] | "Second, **as the case may be**, the department rejected the claim that…" | `as the case may be` 意为"视情况而定"，是表示两种可能性的固定说法，不能作填充性连接语 | 删去，改为 `Second, the department rejected the claim that…`（或 `Second, as it happened,`） |
| B3 | [32] | "Third, **as the time comes**, the department concluded that no revision of the definitions was necessary…" | `as the time comes` 不是英语固定短语，语义不明（既非"届时"也非"随着时间推移"） | 改为 `Third, in due course,` 或直接 `Third,` |
| B4 | [15] | "**As it were**, each of these provisions was a concession to procurement officials…" | `as it were` 是插在句中的"可以说／打个比方"型插入语，用来弱化某个比喻性说法；此处被当成句首连接语（"可以说/换言之"）使用，位置与功能都不对，且与 [13] 的 `so to speak` 语义重复 | 删去，或改为 `In effect,` |

### C 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| C1 | [13][15][17][19][22][23][27] | `so to speak` / `as it were` / `By and large,` / `As we know,` / `As noted above,` / `As mentioned earlier,` / `As already noted,` | 系统性连接语堆叠与同义轮换：全篇 7 处用不同说法重复同一个"如前所述／可以说"功能，且多为不精确的语域套语；[22][23] 更把 `As noted above` 与 `As mentioned earlier` 连着用了两次 | 保留 1–2 处真正需要回指的（如 [22]），其余删除；[17] 的 `By and large` 改为 `On the whole,` 或删；[19] 的 `As we know` 改为 `Notably,` |
| C2 | [13] | "it must certify, **so to speak**, every 120 days that the immediate needs of a public health emergency make them necessary" | `so to speak` 用于弱化比喻或非字面表达，`certify` 是字面行为，此处插入不当，且割裂 `certify … that` 结构 | 删去 `, so to speak,` |
| C3 | [17] | "**By and large**, the public comments on the proposed rule show how sharply the question divided interested parties." | `By and large`（大体上）与后面"分歧有多尖锐"的断言不搭，属填充性套语 | 改为 `On the whole,` 或直接删去 |

### 拼写一致性

- 全文用英式：`recognised` [14]、`labelled` [23]，无混用。**未发现英美混用问题**（尽管 [3] 的 `Department of Homeland Security` 是美国机构名，属专有名词，不算拼写矛盾）。

### 存疑（不下断言）

- [5] "domestic manufacturing of **the** masks, respirators, gloves and gowns on which the national response … depends"：首次提及即用定冠词。因后接限定性关系从句，类指定冠词在语法上可接受，故不作为错误，仅标注存疑。

---

## article_11（news30改写，51 句）

### A 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| A1 | [49] | "A proposal may well seem more persuasive when it is presented over drinks in a private box, **surrounded by prominent citizens and a cheering crowd**." | 悬垂修饰：「被显要人士与欢呼人群包围」的应是**听提案的官员**，但分词短语的主语只能与主句主语 `a proposal` 一致，形成 `a proposal … surrounded by people` 的语义错配 | 补出逻辑主语：`… when it is presented to an official over drinks in a private box, with prominent citizens and a cheering crowd around him.`（**存疑**：若把 proposal 视为场所转喻，尚可勉强接受，故标注而非断言） |

### B 类

未发现问题。

（核查过的疑似项，均属正确用法，不报错：`the majority of the seats` [30] 后接复数语义可接受；`none of the clubs … has` [35] 正式文体单数一致正确；`a series of exits` [9 属 article_05] 类结构正确；[38] 的 `58 percent passed` 数与一致无误。）

### C 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| C1 | [46] | "this group is more likely than average to **follow professional sport with interest**" | 冗赘兼搭配不自然：`follow a sport` 本身已含"关注"义，`with interest` 属叠床架屋；`professional sport` 单数作不可数名词是英式用法，可接受但此处整体生硬 | 改为 `to follow professional sports closely` |

### 存疑（不下断言，含一处逻辑矛盾）

- **[37] 与 [38] 内部矛盾**：[37] 断言 "when the question is put to a referendum, voters usually reject it"（选民通常否决），紧接 [38] 却说 "A review of such votes found that **only 58 percent passed**"——58% 通过意味着**多数**公投是**通过**的，与 [37] 相反（也削弱 [39] 的对比力道）。二者必有一处数据或措辞写反。建议核实原始数据后统一（若公投通过率确为 58%，[37] 应改为 `voters often approve it, though far less readily than their representatives do`；若通过率低于半数，则 [38] 的 `58 percent passed` 应改为 `58 percent failed`）。
- [1] "six venues that the National Football League plans to **occupy**"：占用场馆的是各俱乐部而非联盟本身，属转喻用法，语义略松，**存疑**，不算语法错。
- [34] "If monopoly power **were** the main cause, … **should have reduced** the pressure on public funds"：反事实条件句主句通常用 `would have reduced`；此处 `should have` 可解作「按理本应」，形式可辩护，标为**存疑**，不判错。
- [51] 同一句内 `Owners`（复数）与 `the owner's box`（单数所有格）并置：`the owner's box` 是场馆固定房间名，可接受，标为**存疑**。
- [4] "the Bills project"：球队名直接作定语（未用所有格 `Bills'`），美国体育新闻常见写法，**不作错误**。

### 拼写一致性

- 全文英式：`summarises` [11]、`criticised` [48]、`organised` [50]、`neighbouring` [42]、`play-off` [47]、`whisky` [29]。**未发现英美混用**（`Organization` 未出现在本篇；`whisky` 与全文英式风格一致，非错误）。

---

## article_17（news30改写，54 句）

### A 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| A1 | [42] | "effective communication must be **repeated, consistent, and delivered** through channels that people already trust" | 平行结构破坏：`repeated`、`delivered` 是 `must be` 后的被动分词，`consistent` 是形容词性补足语，三者被 `and` 强行并列，同一 `must be` 无法同时支配两种补足类型 | 改为 `must be repeated and consistent, and must be delivered through channels that people already trust`（**存疑**：此类"形容词＋分词"并列在新闻体中偶见，严格语法书判为错，故标注而非重判） |

### B 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| B1 | [2] | "the evidence from the **Gulf coast** suggested otherwise" | 专有名词大小写错：该地理名称固定写作 `Gulf Coast`（同篇 [3] 又写 `the coast` 属普通名词，无误） | 改为 `the Gulf Coast` |
| B2 | [23] | "a history of neglect and **broken assurances**" | 搭配不地道：英语固定说法是 `broken promises`；`assurances` 通常与 `give/receive/repeat` 搭配，不与 `broken` 搭配 | 改为 `broken promises`（或 `unkept assurances`，但前者更自然） |

### C 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| C1 | [1] | "the comforting myth that a **modern urban city** can manage any emergency" | 语义重复：`urban` 已含"城市"义，`urban city` 属同义叠加；`modern` 亦无信息量 | 改为 `a modern city` 或 `an urban government` |

### 存疑（不下断言）

- [8][12][25][42][51] 连续使用 `has therefore become` / `was therefore not` / `is therefore central` / `must therefore be repeated` / `is therefore an act`，54 句中 5 次 `therefore`。属连接词单调重复，尚未到"堆叠"程度，**存疑**，未计入 C 类上限。
- [26] "coerce every citizen **into safety**"：`coerce sb into doing sth` 是常见句式，接名词短语 `into safety` 略松但可用，**存疑**。

### 拼写一致性

- 全文英式：`organise` [30]、`romanticise`/`recognise` [32]、`heatwave` [14]、`flats` [14]、`rumours` [29]、`man-made` [52]。**未发现英美混用**（`Gulf Coast` 大小写见 B1，属专名规范而非英美差异）。

### 总评

本篇 54 句整体干净，仅 1 处可辩护的平行结构瑕疵、2 处用词/规范小问题、1 处语义重复。**不存在系统性错误。**

---

## article_23（news30改写，57 句）

### A 类

未发现问题。

（重点核查项均正确：[1] 主语 `The tariffs … together with the retaliation` 用复数动词 `constitute` 正确；[6] `a system of rules that has governed` 单数一致正确；[42] `whose twenty-seven members trade` 关系从句一致正确；[36] `Speaking to Congress, the president …` 无悬垂。）

### B 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| B1 | [42] | "The European Union, whose twenty-seven members trade with the United States as a **single block**" | **词义误用（真错误）**：`block` 指"块、街区、阻塞"；"作为一个整体／集团"的固定词是 `bloc`（贸易集团、政治集团）。EU 语境下只能是 `bloc` | 改为 `as a single **bloc**` |
| B2 | [2] | "an earlier charge on Chinese imports doubled to **twenty**" | 计量单位省略不当：前半句 `rose to twenty-five per cent` 有单位，后半句只剩 `twenty`，读者须自行补 `per cent`；并列句中可省的是一致成分，不含计量单位 | 改为 `doubled to twenty per cent`（**偏存疑**：属可恢复省略，但多数编辑规范判为不完整） |

### C 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| C1 | [27][41] | [27] "the three governments **immediately involved**" / [41] "the three countries **immediately concerned**" | 同一公式在 57 句内原样复用两次，仅换中心词，属模板化重复 | 保留一处；[41] 改为 `beyond the three countries at the centre of the dispute` |
| C2 | [20] | "could find no **motive, reason or justification** for a decision" | 同义词三项并列（`motive`/`reason`/`justification` 语义高度重叠），有凑字之嫌 | 减为两项：`no reason or justification`，或改为 `no justification for a decision` |

### 拼写一致性

- 本篇英式拼写一致：`neighbour` [15]、`recognise` [46]、`per cent`（英式分写）[2][13 等]、`travel` 无变体。
- [4][24] 的 `World Trade Organization` 用的是 `-ization`，但它是**专有名词**，法定名称必须如此拼写，**不构成英美混用**。

### 存疑（不下断言）

- [32] "all three leading stock **indexes** fell … and each dropped about two percentage points"：`indexes` 与 `indices` 均为可接受复数（美国财经媒体惯用 `indexes`），**不报错**。

---

## article_29（news30改写，56 句）

### A 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| A1 | [26] | "At first **it** refused to take **the review** seriously, and later **it** produced a series of arguments against **it**." | 代词指代不明：同一句内三个 `it` 有两个不同先行词（前两个指 the department，最后一个指 the review），末一个 `it` 须回读才能确定 | 改为 `… and later the department produced a series of arguments against the review.` |

### B 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| B1 | [8] | "Together they suggest **a common structure to successful reform**: solid evidence, a patient alliance…" | 介词搭配不地道：`structure` 后习惯接 `of`／`underlying`／`behind`，`structure to X` 只在"there is a structure to it"这类口语框架中成立，此处作名词短语中心语时不通 | 改为 `a common structure underlying successful reform` 或 `a common pattern behind successful reform`（**存疑**：偏搭配而非硬语法错，故标注） |

### C 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| C1 | [44][45][46] | 连续三句均以 "**In each case** …" 开头（[44] `In each case the reform required…`、[45] `In each case a small group…`、[46] `In each case the opposition…`） | 句首公式三连，即便视为排比修辞，在考研阅读篇幅内也显机械呆板 | 保留 [44] 的 `In each case`，[45] 改为 `A small group of people…`，[46] 改为 `Nor was the opposition really about…` |
| C2 | [19] | "although **successive generations of health officials** had described such reform as simply impossible" | 措辞夸张失准：1937–1974 年间的官员并非"数代"，且 `successive generations` 与前文 [11] 的 `four attempts` 时间跨度不匹配 | 改为 `although health officials had long described such reform as impossible` |
| C3 | [56] | "the cost of believing it is **measured in the quality of the lives that are not improved**" | 表述缠绕：`cost` 被"用未被改善的生命质量来衡量"，逻辑上衡量的应是机会损失而非"质量"本身 | 改为 `the cost of believing it is paid in the lives that are never improved` |

### 存疑（不下断言）

- [12] "fought on emotional and political **ground** alike"：固定说法通常为 `on … grounds alike`（复数）。`ground` 单数在英式新闻中偶见，未判为错，标为**存疑**。
- [14] "to **bring** the deputy opposition leader, Gough Whitlam, **behind** the plan"：`bring sb behind a plan/deal` 在政治新闻中确有使用，但更标准是 `bring … on board` / `win … over to`。标为**存疑**。（另：1969 年时 Whitlam 已是反对党领袖而非"副领袖"，属史实问题，不属语法／用法范畴，仅提示。）
- [49] "needs three qualities: **a range of evidence**, a sense of timing, and a tolerance for personal unpopularity"：`a range of evidence` 是资源而非"个人品质"，与前两项不同类，属轻微列举范畴不齐，标为**存疑**。
- [54] "At various moments change can appear impossible, **which** is exactly what health officials once said about a universal health scheme"：`which` 指代整个前句命题，语法可通（与 [19] `described such reform as simply impossible` 呼应一致），但句式绕，标为**存疑**。

### 拼写一致性

- 全篇英式／澳式一致：`centred` [18]、`Programmes` [40]、`per cent`（分写）、`Labor`（澳大利亚工党法定拼写）。**未发现英美混用**；`Labor` 是党名而非美式拼写，不构成矛盾。

---

## C_身体与动作_2（定向生成，60 句）

### A 类

未发现问题。

（重点核查项均正确：[5] `constitutes`、[21] `constitutes` 用法正确；[29] 冒号前三个名词短语并列作 `these` 的同位语，结构完整；[37] `Where … , it goes; where … , it stays` 两分句平行一致；[55] `not whether …, but where … and who …` 平行无误；[23] `cannot do is perceive …, adjust …, and then explain …` 三个不定式并列正确。）

### B 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| B1 | [46] | "a colour that depends on **three variables at least**" | 语序不地道：`at least` 修饰数词时应前置；句末悬置的 `at least` 会被先读作"至少取决于"的模糊限定 | 改为 `depends on **at least three** variables` |
| B2 | [35] | "**Computer-controlled knitting presses the cloth** where a tailor once placed a tuck by eye" | 语义错配（**存疑**）：针织（knitting）不"压布"，压褶是 pressing／pleating 的工序，主语与谓语所述动作不属同一工艺 | 改为 `Computer-controlled pleating presses the cloth`，或 `Machine knitting forms the cloth where a tailor once placed a tuck by eye` |
| B3 | [23] | "adjust the rhythm accordingly, and then **explain subsequently why** the adjustment was necessary" | 冗余＋副词位置不当：`then` 与 `subsequently` 语义重复，且 `subsequently` 夹在 `explain … why` 之间割裂结构 | 改为 `and then explain why the adjustment was necessary`（或 `explain afterwards why …`） |

### C 类（伪古雅词集中，本篇为全组最严重）

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| C1 | [1][23] | "**commences to rotate** it" / "has **commenced to warp**" | 伪古雅：`commence` 是技术／法律文体词，工艺描写中用 `begin` 更自然；且 `commence` 习惯接动名词或直接接名词 | 改为 `begins to rotate` / `has begun to warp` |
| C2 | [1][2][4] | "the **periphery** of a European **metropolis**" [1] / "at the **extremity** of the pipe" [2] / "**the operative** is interpreting the material" [4] | 伪古雅词链：用 `periphery`／`metropolis`／`extremity` 替代 `outskirts`／`city`／`end`，用 `the operative` 替代 `the worker`／`the glassblower`，全篇语域被抬得虚高，属自造庄严 | 依次改为 `on the outskirts of a European city`、`at the end of the pipe`、`the glassblower is reading the material through his body` |
| C3 | [5][2][30] | "a specific **species** of knowledge" [5] / "**the spit of rain**" [30] / "**the pant of exertion**" [19] | 同义词轮换与生造比喻：`species of knowledge` 借生物学词表"一类知识"，`the spit of rain`、`the pant of exertion` 属生造名词化比喻，读来做作 | [5] 改为 `a distinct kind of knowledge`；[30] 改为 `nor tolerate rain blowing in through an open window`；[19] 改为 `The puffing of breath one hears beside the bench` |

### 拼写一致性

- 全篇英式一致：`romanticised` [54]、`standardised` [56]、`colour` [46]、`millimetre` [29]、`draught` [48]、`vigour` [47]。**未发现英美混用。**

### 存疑（不下断言）

- [14] "The **clutch** of the fingers is correspondingly variable"：`clutch` 作名词通常指"离合器／紧抓（的动作）"，此处指握持力度，用 `grip` 更准；标为**存疑**（因 C 类已达上限 3 条，未计入）。
- [44] "leans with his belly against the frame of the wheel"：`with his belly against …` 可通，但 `leans his belly against` 或 `braces his belly against` 更常见；**存疑**。
- [47] "the **vigour of the yeast**"：靛蓝染缸确有以酵母／麦麸发酵的做法，术语可辩护，**存疑**，不判错。
- [42] "they are easiest to observe in the training of a novice"：`easiest` 用于"最容易被观察到"属可接受的口语化评价用法，**存疑**，不判错。

### 总评

本篇**无 A 类语法错误**，但 C 类问题最突出：伪古雅词贯穿全篇（`commence`、`operative`、`extremity`、`periphery`、`metropolis`、`subsequently`），是 8 篇中最明显的语域失真样本。

---

## G_艺术与表演（定向生成，54 句）

### A 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| A1 | [49] | "Documentaries about the profession have already begun to make **this arithmetic** public" | 指示词无先行语：全篇此前从未出现任何"算术／计算／账目"的具体内容或数字账（[15] 只有 `a longer ledger` 的比喻，[22] 是 `none of these pays rent`），`this arithmetic` 无所指 | 改为 `to make this **accounting** public` 并补出所指，或直接改为 `to make the hidden costs public` |
| A2 | [26] | "The price of the exposure that finally arrives is **constant travel, irregular sleep, and an audience that expects the same twenty minutes to be fresh every night**." | 平行结构破坏：前两项 `constant travel`、`irregular sleep` 是"代价"本身，第三项却是一个"群体（观众）"，与 `The price … is` 的补足语不同类 | 改为 `… is constant travel, irregular sleep, and the expectation of an audience that wants the same twenty minutes to be fresh every night` |

### B 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| B1 | [15] | "only the most visible **entry on a longer ledger**" | 介词搭配：账簿中的"一笔记录"固定用 `an entry in a ledger`（`on` 用于 `on the books`／`on account`） | 改为 `entry in a longer ledger`（**存疑**：`on the ledger` 有零星用例，非硬错） |
| B2 | [10] | "Musicians who spend decades **behind a drum** suffer hearing loss" | 搭配不精准：打击乐手通常说 `behind a drum kit`／`behind the drums`；单数 `a drum` 会读作某一面鼓，与"数十年"的职业生涯不相称 | 改为 `behind a drum kit` 或 `at the drums` |

### C 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| C1 | [30][39] | [30] "**the standard against which** every subsequent evening is judged" / [39] "**The standard against which** performers measure themselves is not a rival but an ideal" | 同一公式在 9 句内原样复用（`the standard against which …`），属模板化重复而非有意的复沓 | [39] 改为 `Performers measure themselves against an ideal, not a rival, and no human body can fully realise it` |
| C2 | [4][47] | [4] "an **illusion of ease**" / [47] "the market rewards the **appearance of effortlessness**" | 同义词轮换指同一概念，两处措辞不同却无实质区别；且 [1] 已用 `effortless` | [47] 沿用 [4] 的说法：`rewards the illusion of ease` |

### 拼写一致性

- 全篇英式一致：`theatres` [1]、`organising` [6]、`internalised` [18]／`internalise` [40]、`memorise` [16]、`realise` [39]、`candour` [49]、`favourable` [30]。**未发现英美混用。**

### 存疑（不下断言）

- [24] "ends before the age at which most people reach mid-career"：`mid-career` 是阶段而非年龄节点，`the age at which … reach mid-career` 逻辑上略绕，但可通，**存疑**。
- [35] "What **the camera and the microphone** capture most faithfully"：镜头捕捉画面、麦克风捕捉声音，合用作主语后接 `capture` 指代两类感知通道，可接受但略粗，**存疑**。
- [51] "were borrowed against a future that has now come due"：`borrow against` 与 `come due` 属两个借贷隐喻的拼接，读来混喻，**存疑**。
- [28] "is not quite the freedom it appears to be"：`freedom` 在此指"自主选择"，`the freedom it appears to be` 中 `it` 指 `a choice`，指代可回读确定，**存疑**，未判为错。

### 总评

本篇无系统性语法问题，仅 1 处指示词失指（[49]）＋1 处平行结构破坏（[26]）＋2 处搭配不精准＋2 处措辞重复。整体质量在 8 篇中偏上。

---

## M_科技与学术（定向生成，53 句）

### A 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| A1 | [26] | "**The vocabulary of drift, they complained, was speculative, the forces required were unimaginably large, and the physicists of the period insisted** that no known process could move continents through the ocean floor." | 插入语辖域错误：`they complained`（批评者抱怨）只能管辖前两个分句，却因排比句式被读成同时管辖第三分句，于是变成"批评者抱怨物理学家坚持……"，而物理学家的坚持是事实而非抱怨内容；同时第三分句与前两项的语义类型不一致 | 断开并补出主语：`The vocabulary of drift, they complained, was speculative and the forces required unimaginably large; the physicists of the period, meanwhile, insisted that no known process could move continents through the ocean floor.` |
| A2 | [12] | "Then **optical fiber transformed** telecommunications, **the compact disc carried** recorded music into millions of homes, and **electrical engineering, surgery and manufacturing were quietly reorganized** around a beam of light." | 平行结构破坏：三项并列中前两项为主动、主语是"发明物"，第三项突转为被动、主语变成"被改造的领域"，并列项的主语类型与语态双双不一致 | 改为 `and electrical engineers, surgeons and manufacturers quietly reorganized their work around a beam of light`（**存疑**：第三项因施事不明而被迫转被动，属可辩护的变通，故标注） |

### B 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| B1 | [23] | "the community merely declined to grant it standing **for the sake of a hypothesis that refused to behave**" | **固定短语误用（真错误）**：`for the sake of` 意为"为了……的利益／看在……份上"，此处要表达的是原因（"因为该假说始终不肯就范"），介词短语用错导致整句语义不通 | 改为 `on the ground that the hypothesis refused to behave`（或 `because the underlying hypothesis refused to behave`） |
| B2 | [32] | "Younger researchers, never invested in the old framework, found the new account **superb**" | 词义误用（**存疑**）：`superb` 是"极好的、壮丽的"这类鉴赏性评价，用来描述一个科学解释的可靠性／说服力不准确 | 改为 `found the new account compelling`（或 `persuasive`；若确要表达"更优"，用 `superior`） |

### C 类

| # | 句号 | 原文片段 | 问题 | 最小修改 |
|---|---|---|---|---|
| C1 | [43][44] | [43] "the system possesses **correctives** … that the **correctives** work well enough" / [44] "offers a useful **corrective** to the suspicion" | 同一名词在相邻两句内密集复现（共 4 次，含 [43] 句内 2 次），非有意的复沓 | [44] 改为 `The history of measurement offers a useful **check** on the suspicion that…`；[43] 句内第二次可改为 `they work well enough to be worth the cost` |
| C2 | [19] | "the details were **desperately thin**" | 语域不合：`desperately` 是口语化强意副词，用于学术史叙述的冷静笔调中显得突兀，且 `desperately thin` 属生造搭配 | 改为 `the details were conspicuously thin` 或 `remarkably thin` |

### 拼写一致性（**本篇为全组唯一的英美混用篇，且同一句内混用**）

| 句号 | 证据 | 判定 |
|---|---|---|
| [45] | "suspended a delicate wooden shaft by a **fiber** a few **metres** long" | **同一句内**美式 `fiber`（英式 `fibre`）与英式 `metres`（美式 `meters`）并存，性质明确，属真错误 |
| [11][40] | `skeptical`（美式；英式 `sceptical`） | 美式 |
| [12][43] | `reorganized`／`civilization`（美式 `-ize`/`-ization`；英式 `reorganised`/`civilisation`） | 美式 |
| [21] | `artifact`（美式；英式 `artefact`） | 美式 |

- 结论：本篇需在 `fiber/fibre`、`metres/meters`、`skeptical/sceptical`、`-ize/-ise`、`artifact/artefact` 之间**统一为一种拼写体系**（其余 7 篇均内部一致，无此问题）。

### 存疑（不下断言）

- [39] "no theory of the rays was required **for them to be useful**"：`them` 需读作 the rays 才能讲通，形式上也可回指 `Practitioners`（读作" practitioners 有用"则荒谬），读者能自行消解，故标为**存疑**，不判为指代错误。建议改为 `for the rays to be useful` 以彻底消歧。
- [8] "the **machinery** of judgment" 与 [16] "the social **machinery**"：同一隐喻在 8 句间隔内复用，属轻度重复，未达 C 类，**存疑**。
- [45] `a delicate wooden shaft`：据史料卡文迪什悬吊的是木杆（木质扭秤横梁）但**悬丝是金属丝**，"by a fiber"疑为"by a wire"之误，属史实层面，不计入语法／用法，仅提示。

---

## 汇总统计

| 篇名 | 句数 | A 类语法 | B 类用词/搭配 | C 类不自然 | 小计 |
|---|---|---|---|---|---|
| article_05 | 56 | 2 | 4 | 3 | 9 |
| article_11 | 51 | 1 | 0 | 1 | 2 |
| article_17 | 54 | 1 | 2 | 1 | 4 |
| article_23 | 57 | 0 | 2 | 2 | 4 |
| article_29 | 56 | 1 | 1 | 3 | 5 |
| C_身体与动作_2 | 60 | 0 | 3 | 3 | 6 |
| G_艺术与表演 | 54 | 2 | 2 | 2 | 6 |
| M_科技与学术 | 53 | 2 | 2 | 2 | 6 |
| **合计** | **441** | **9** | **16** | **17** | **42** |

（A、B 两类中含标注为"存疑"的条目：A 类 2 条、B 类 3 条，已在各篇表中标明。）

### 系统性倾向

1. **连接语机械化堆叠／误用**——最系统的问题，横跨 5 篇。article_05 一篇内 7 处（`so to speak`／`as it were`／`By and large`／`As we know`／`As noted above`／`As mentioned earlier`／`As already noted`），且 `As such`、`as the case may be`、`as the time comes` 被当作 `therefore`／填充语误用，属真错误；article_29 [44][45][46] 三连 `In each case`；article_17 出现 5 次 `therefore`。
2. **指示词／代词失去先行语**——跨 4 篇：article_05 [47] `they contend`（全篇无复数先行词）、article_29 [26] 三 `it` 双先行词、G [49] `this arithmetic` 无先行账目、M [39] `them` 可歧解。这是生成模型的典型弱点，且**恰好落在段落收束句上，破坏力最大**。
3. **英美拼写混用集中在 M_科技与学术一篇**（含 [45] 同句 `fiber` + `metres`），其余 7 篇内部一致。属单篇缺一致性校验，非全组性问题。
4. **伪古雅词集中于 C_身体与动作_2**（`commence`、`operative`、`extremity`、`periphery`、`metropolis`、`subsequently`），是语域失真最重的一篇。
5. **平行结构破坏 4 处**（article_05 [23]、article_17 [42]、G [26]、M [12]），均为三项并列中一项不同类，属轻度重复模式。

### 明确"未发现问题"的项

- article_23：**A 类零发现**（含 `constitute` 用法正确、`a system of rules that has governed` 单数一致正确）。
- C_身体与动作_2：**A 类零发现**。
- article_11：**B 类零发现**。
- 按要求复核而未报错的可接受用法：`a number of X have`、`majority of X are`、`consider X to be`、`series of X that do`、限定性关系从句后的类指定冠词、`indexes`／`indices`、`none of the clubs … has`、`per cent` 分写、`Labor`（澳党名）、`World Trade Organization`（法定专名拼写）。

---

*报告完。全部 8 篇、441 句逐句通读完毕；每篇审完即写盘，无遗留未记录内容。*
