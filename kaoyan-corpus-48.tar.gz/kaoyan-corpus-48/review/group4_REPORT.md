# 组4 语法审校报告

审校范围：`/root/DSH/kaoyan-vocab/internal/grammar_review/group4/` 下全部 8 篇，逐句通读，不抽样。
分类约定：**A 类**=语法/形态错误（含冠词、时态、语态、一致、平行、指代、介词、从句结构、悬垂修饰，以及同一篇内英美拼写混用）；**B 类**=用词/搭配错误（如 `comprise` 误作 `constitute`、`anticipate` 后接不定式、词性误用）；**C 类**=语法无误但不自然（伪古雅词、同义词轮换、连接词堆叠），每篇最多 3 条。
拿不准的条目一律标注「存疑」，不计入确定错误。**未发现问题的篇目明确写明「未发现问题」，不凑数。**

## 总览
| 篇名 | A类 | B类 | C类 | 备注 |
|---|---|---|---|---|
| article_04 | — | — | — | 待审 |
| article_10 | — | — | — | 待审 |
| article_16 | — | — | — | 待审 |
| article_22 | — | — | — | 待审 |
| article_28 | — | — | — | 待审 |
| C_身体与动作_1 | — | — | — | 待审 |
| F_乡村与农作 | — | — | — | 待审 |
| L_文学叙事 | — | — | — | 待审 |

（总览表在各篇审校完成后回填。）

---

## 1. article_04（55 句，news30 改写）

**结论：未发现问题（A 类 0、B 类 0、C 类 0）。**

逐句通读 55 句，未发现真正的主谓一致、时态、语态、冠词、介词搭配、从句结构、悬垂修饰或平行结构错误；也未发现 `comprise/constitute`、`anticipate + to do` 一类典型搭配误用。拼写方向亦统一为**英式**（[6] `judgment`、[12] `licences`、[22] `cancelled`、[44] `behaviour`、[45] `criticises`；`labour`（[20] `labor` 系 `manual labor` 的固定搭配，非拼写选择）——同篇无 `center/organization/realize` 型美式拼写，无混用。

以下条目**经复核判定为正确用法或可接受变体，故不计入错误**，仅记录以说明不是漏检：

- **[句 10]** `A stadium tour is a business that must be welcome in dozens of countries` — `must be welcome` 中 `welcome` 为形容词，`be welcome in a country`（在某国受欢迎/被接受）成立，非被动语态误用。
- **[句 30]** `The difference between the two traditions lies in whom they address` — `whom` 作 `address` 的宾语，正式书面语用法**正确**（口语可作 `who`，但此处不算错）。
- **[句 33]** `A museum that reverses its photography policy, or a government that orders a review of a museum's content, exercises control...` — 由 `or` 连接的复合主语按就近原则取单数谓语 `exercises`，**正确**。
- **[句 28]** `something that would outlast its maker` — 过去叙事中的 backshift `would`，且 `its` 指 `something`，**正确**。
- **[句 35]** `attract far less notice than a singer's tour schedule` — 比较项略不齐整（`notice` 对 `schedule`），但为 `X attracts less notice than Y` 的常见压缩式表达，**可接受变体，不报错**。
- **[句 45]** `protest becomes a branch of entertainment, consumed in the same way as the music it criticises` — 分词 `consumed` 的逻辑主语可回溯至 `entertainment/protest`，未构成真正的悬垂修饰，**存疑但不计入**。

---

## 2. article_10（56 句，news30 改写）

**A 类 5 处（其中 1 处存疑）、B 类 3 处（其中 2 处存疑）、C 类 3 处。**

### A 类：语法错误

- **[句 2]** 原文：`The exhibition that occupies it is likely to be remembered long after the ordinary collection of exhibitions staged across the nation are forgotten.` ｜ 问题：**主谓不一致**。`are forgotten` 的主语中心词是 `the ordinary collection`（单数），而非其后的复数介词宾语 `exhibitions`；且 `long after` 引导的时间状语从句与主句 `is likely to be remembered` 的对比项也应是"这个 collection"，用 `are` 使全句结构与语义双错。｜ 建议：`...long after the ordinary collection of exhibitions staged across the nation is forgotten.`
- **[句 42]** 原文：`shooting Jodie Foster, the actress who famously performed an FBI agent in The Silence of the Lambs` ｜ 问题：**介词缺失**。`perform` 表"扮演某角色"时为不及物用法，须接 `as`；`performed an FBI agent` 直接加宾语不成立（对比 [43] `Foster training for the role` 用的是另一套正确结构）。｜ 建议：`...the actress who famously played an FBI agent in ...` 或 `...who famously performed as an FBI agent in ...`
- **[句 50]** 原文：`What is Simon not telling us, can she be trusted, and is all of this really connected?` ｜ 问题：**逗号粘连（comma splice）**。三个独立疑问分句仅以逗号连接，属结构错误。｜ 建议：`What is Simon not telling us? Can she be trusted? And is all of this really connected?` 或改用分号分隔。
- **[句 3] / [句 22]** 原文：`centered on vague notions of democracy` ／ `Simon often realises this notion` ｜ 问题：**同一篇内英美拼写混用**。[句 3] 用美式 `centered`（英式 `centred`），[句 22] 用英式 `realises`（美式 `realizes`）；同篇其余处（如 [句 22] 同一句体系）无第三种拼法，可见不统一。（[句 46] `Defense Logistics Agency` 系美国机构专名，固定拼写，不计入。）｜ 建议：全篇统一为英式（`centred / realises`）或美式（`centered / realizes`）。
- **[句 7]** 原文：`That assumption, the artist suggests, is one in which political authority has a particular interest` ｜ 问题：**关系结构/指代错误**。`one in which` 要求先行项 `one`（=assumption）是处所或情境，方能说 `in which ... has an interest`；而 `have an interest in something` 的 `in` 属**动词后置介词**，不是关系副词可替代的状语关系，故 `one in which` 读不通，应回指用 `that`。｜ 建议：`That assumption, the artist suggests, is one that political authority has a particular interest in.`（**存疑**：若把 `one` 理解为"一种局面"，`in which` 勉强可辩，但需读者回读。）

### B 类：用词/搭配错误

- **[句 22]** 原文：`Simon often realises this notion by providing images that appear innocent...` ｜ 问题：**搭配不成立**。`realise` 的宾语限于 `ambition / plan / dream / potential / value` 一类可"实现、变现"之物，`notion`（观念）不可被 realise；此处要表达的是"用图像把这一观念落实/呈现出来"。｜ 建议：`Simon often conveys this notion by providing images that...` 或 `...illustrates this notion by providing images that...`
- **[句 13]** 原文：`a vast collection of more than 1,000 images, provided alongside thousands of terms of material` ｜ 问题：**搭配与量词误用**。`terms of material` 不是英语的计量表达（`term` 指术语/期限，不指"份/条"资料），作者似在回避 `items/pages` 等词而选错。｜ 建议：`...alongside thousands of pages of material.`（**存疑**：若原意是"数以千计的检索词条"，则应写成 `thousands of entries/terms`，与 `material` 不能连用。）
- **[句 48]** 原文：`as if to mirror all the unretrievable responses that would be needed to explain the encounter` ｜ 问题：**用词错误**。英语标准形式为 `irretrievable`；`unretrievable` 属罕见/非标准变体，学术与新闻文体均不用。｜ 建议：`...all the irretrievable responses that...`（**存疑**：`unretrievable` 在个别词典有收录，但远不如 `irretrievable` 规范。）

### C 类：不自然（3 条，已达上限）

- **[句 23]** 原文：`One array of images, for instance, shows an array of individuals standing around bridges...` ｜ 问题：同一句内 `array` 出现两次且所指不同（前者"影像阵列"、后者"一群人"），读来重复且含混。｜ 建议：`One group of images, for instance, shows a series of individuals standing around bridges...`
- **[句 28]** 原文：`The connections the artist makes are vague, and their details are typically vague, seemingly by design.` ｜ 问题：并列分句内两次使用 `vague`，第二处未能推进语义，属无效重复。｜ 建议：`The connections the artist makes are vague, and their details are typically unverifiable, seemingly by design.`
- **[句 41]** 原文：`offers a clever solution to that problem by rendering any mere notion of truth obsolete` ｜ 问题：`any mere notion` 语序生硬，`mere` 与 `any` 叠加语义冗赘。｜ 建议：`...by rendering any notion of truth obsolete.`

### 经复核判定为正确、不计入错误者

- **[句 44]** `the majority of us will view` — `majority of + 复数` 后接复数动词，**正确**。
- **[句 50]** 三个疑问句本身语法无误，问题仅在标点（见 A 类）。
- **[句 5] / [句 53]** `Its central claim ... is that American history has become chaotic...` 与 [句 53] 同义复述，属篇章呼应而非语法错误。
- **[句 15]** `The collection draws into the agent's orbit an array of individuals and firms` — 宾语后置（heavy NP shift）以避开过长宾语，**正确且得体**。
- **[句 34]** `shot men whom the courts had wrongfully convicted` — `whom` 作 `convicted` 的宾语，**正确**。

---

## 3. article_16（53 句，news30 改写）

**A 类 1 处（存疑）、B 类 2 处（其中 1 处存疑）、C 类 3 处。**

拼写核查：全篇统一为**英式**（[6] `recognise`、[43] `ageing`、[50] `detention centre`），未见 `center/organization/aging` 型美式拼写，**无英美混用**。语法骨架整体扎实：主谓一致、时态、关系从句（`on whom the country has long depended have proved`）均正确。

### A 类：语法错误

- **[句 10]** 原文：`Both present themselves as the conclusion of a trilogy, which suggests that the argument has been under construction for some years.` ｜ 问题：**数不一致**。`Both`（两本书）与单数 `the conclusion`（一个结论）冲突：两卷书不能各自/共同是"那个结论"。｜ 建议：`Both present themselves as the conclusion of a trilogy` → `Both are presented by their authors as concluding a trilogy` 或 `Together the two volumes conclude a trilogy`。（**存疑**：若理解为"两书合起来构成三部曲的收尾"，可勉强成立，但字面数冲突仍明显。）

### B 类：用词/搭配错误

- **[句 47]** 原文：`None of his successors achieved the most basic measure of political success, which is re-election` ｜ 问题：**搭配冲突**。`measure` 在此指"标准/尺度"，英语中与之搭配的是 `meet`（`meet a standard/measure`），不能 `achieve a measure`；`achieve` 要求宾语是可达成之事（`achieve success/re-election`）。｜ 建议：`None of his successors met the most basic measure of political success, which is re-election` 或 `...achieved the most basic mark of political success, namely re-election.`
- **[句 38]** 原文：`A national scheme of disability support was established without adequate provision in the budget, whether through a broader revenue base or through cuts elsewhere.` ｜ 问题：**连接词逻辑误用**。`whether ... or ...` 用于列举"实际发生的两种可能之一"，而本句陈述的是两种筹资途径**都没走**，用 `whether` 造成"二选一已发生"的误读。｜ 建议：`...was established without adequate provision in the budget, either through a broader revenue base or through cuts elsewhere.`（**存疑**：省略式理解"无论按哪种途径算，都拨款不足"亦有人可接受，但需回读。）

### C 类：不自然（3 条，已达上限）

- **[句 24]** 原文：`Women also head public institutions that had never previously been led by them, including the central bank and the Productivity Commission.` ｜ 问题：`never` 与 `previously` 语义叠加冗余，且用 `them` 回指泛指的 `Women` 略显生硬（反身/无代词式更自然）。｜ 建议：`Women also head public institutions that had never before been led by a woman, including...`
- **[句 14]** 原文：`Labor has adapted to all three more successfully than the conservative coalition, and the independent crossbench, drawn largely from professional women, better still.` ｜ 问题：gapping（省略 `has adapted`）本身可接受，但gapped 成分前插入了长同位语 `drawn largely from professional women`，读者需回读才能补出谓语，属可读性受损。｜ 建议：`...and the independent crossbench, drawn largely from professional women, has adapted better still.`
- **[句 42]** 原文：`The political debate seldom reaches these structural questions, and indeed the quality of the argument suffers accordingly.` ｜ 问题：`and indeed` 与 `accordingly` 双重逻辑连接词叠加，语气冗余。｜ 建议：`...and the quality of the argument suffers accordingly.`（删 `indeed`）

### 经复核判定为正确、不计入错误者

- **[句 23]** `a majority of Labor's parliamentary party are now women` — `majority of + 复数名词` 后接复数动词，**正确**（题设明确不报）。
- **[句 11]** `Australians of migrant background and their children form a majority of the population` — 并列主语为复数，`form` **正确**。
- **[句 13]** `the allies and trading partners on whom the country has long depended have proved unreliable` — `depend on` 的介词前置为 `on whom`，谓语 `have proved` 与并列复数主语一致，**完全正确**。
- **[句 14]** gapping 省略本身合法（见 C 类，问题只在可读性）。
- **[句 44]** `Judging leaders while they are still in office is a hazardous business` — 动名词短语作主语取单数 `is`，**正确**。
- **[句 28]** `inspires less confidence ... than any world leader except those of Russia and North Korea` — 比较结构含 `except`，语义（唯俄、朝领导人信心更低）自洽，**可接受**。

---

## 4. article_22（59 句，news30 改写）

**A 类 4 处（其中 1 处存疑）、B 类 3 处（其中 2 处存疑）、C 类 3 处。**

### A 类：语法错误

- **[句 49]** 原文：`A society that forgets this will be surprised, and poorly prepared, for every crisis it eventually meets.` ｜ 问题：**并列结构中共享介词造成搭配错误**。插入语 `and poorly prepared` 使两个形容词共用同一介词 `for`，但英语为 `be surprised **by/at**` 与 `be prepared **for**`，`surprised for` 不成立（zeugma 型错误）。｜ 建议：`A society that forgets this will be surprised by every crisis it eventually meets, and poorly prepared for it.` 或 `...will be both surprised and ill-prepared for every crisis...`（若删去 `surprised` 亦可）。
- **[句 24]** 原文：`The bronze and black coloration reminded the man of ancient Egypt...` ｜ 问题：**指代不明**。[句 23] 只引出 `Two young cousins, one from New Jersey and one visiting from New Delhi`，全篇此前未出现任何男性指称，`the man` 却使用定指，读者必须自行推断他是那位来自新泽西的表亲（[27] 又改用 `her cousin`）。｜ 建议：`The bronze and black coloration reminded the cousin from New Jersey of ancient Egypt...`，并与 [27] 的 `her cousin` 统一指称。
- **[句 15] / [句 16] / [句 21] / [句 53] / [句 11]** 原文：`to criticise the nation's frenetic ... development` ／ `their scepticism was aimed ...` ／ `a public that is skeptical of authority` ／ `some degree of specialized knowledge` ／ `rapid urbanisation and globalisation` ｜ 问题：**同一篇内英美拼写系统性混用**。英式：`criticise`(15)、`scepticism`(15,16)、`urbanisation/globalisation`(11)、`centre`(8)、`programme`(30)、`fibreglass`(3)、`moulded`(26)、`instalment`(30)；美式：`skeptical`(21)、`specialized`(53)、`judgment`(28,59)。最刺眼的是**同一词根 `sceptic-/skeptic-` 在 6 句之内两种拼法并存**（[15][16] `scepticism` 对 [21] `skeptical`）。附带：`façade`(9) 与 `facade`(19,30,35,36,53) **同一词带不带变音符不统一**。｜ 建议：全篇统一为英式（`sceptical / specialised / judgement / façade 或 facade 二选一`）或统一为美式（`criticize / skepticism / urbanization / specialized / judgment / facade`），并在该词首次出现处定调。
- **[句 1]** 原文：`Ten years after his last solo show in the city, the Beijing artist Liu Wei has returned to New York...` ｜ 问题：**定指冠词使用过早**。`the city` 预设读者已知是哪座城市，但纽约直到同句后半才出现，指称顺序颠倒。｜ 建议：`...his last solo show in New York, the Beijing artist Liu Wei has returned to the city with two monumental sculptures.`（**存疑**：可辩为同句内后照应（cataphora），但正式文体宜避免。）

### B 类：用词/搭配错误

- **[句 8]** 原文：`a matte black form resembling the carved wooden scroll of a fireplace mantle sits at the centre...` ｜ 问题：**同音异形词误用**。壁炉上方的搁板/饰架标准拼写为 `mantel`（`mantelpiece`）；`mantle` 指"披风、覆盖层"。｜ 建议：`...the carved wooden scroll of a fireplace mantel sits at the centre...`
- **[句 2]** 原文：`His Speculation flanks both sides of the Metropolitan Museum of Art's main entrance` ｜ 问题：**语义冗余**。`flank` 本身即"位于……两侧"，再加 `both sides of` 属重复（"在入口两侧的两侧"）。｜ 建议：`His Speculation flanks the Metropolitan Museum of Art's main entrance...`（**存疑**：`flank both sides of` 在新闻体中确有用例，但严格看仍属冗赘。）
- **[句 46]** 原文：`Rome was not built in a day, but it was built by accumulation, improvisation and the constant repair of earlier work.` ｜ 问题：**介词搭配欠妥**。`be built by + 施事者/手段` 用于具体动作发出者，此处宾语是抽象过程，宜用 `through` 或 `by means of`。｜ 建议：`...but it was built through accumulation, improvisation and the constant repair of earlier work.`（**存疑**：`built by + 抽象名词` 并非全不可通，属边缘用法。）

### C 类：不自然（3 条，已达上限）

- **[句 59]** 原文：`The final judgment will depend on what the next generation of artists and viewers make of it, and that judgment is still forthcoming.` ｜ 问题：同一句内 `judgment` 重复两次，且后半句在语义上原地打转（"取决于后人怎么看"与"这个判断尚未出现"信息重叠）。｜ 建议：`The final verdict will depend on what the next generation of artists and viewers make of it, and that is still to come.`
- **[句 3]** 原文：`The two primary sculptures are composite forms of metal and fibreglass...` ｜ 问题：全篇只有两件雕塑，`two primary sculptures` 的 `primary` 暗示另有次要者，与事实不符。｜ 建议：`The two sculptures are composite forms of metal and fibreglass...`
- **[句 28]** 原文：`Such remarks are not expert judgments in any particular sense, yet they identify what the commission is doing more sharply than any catalogue essay could.` ｜ 问题：`in any particular sense` 为空洞填充语，未传递信息且读来生硬。｜ 建议：`Such remarks are hardly expert judgments, yet they identify what the commission is doing more sharply than any catalogue essay could.`

### 经复核判定为正确、不计入错误者

- **[句 26]** `as though the material were still being moulded by a pair of hands` — `as though` 引导虚拟语气用 `were`，**正确**。
- **[句 45]** `which is also how most cities grow` — 非限定 `which` 回指前句整体内容，**正确**。
- **[句 30]** `a programme that has previously featured Jeffrey Gibson, Lee Bul, Hew Locke and Wangechi Mutu` — `a series of X that do` 同型结构，**正确**。
- **[句 42]** `neither is a purely political event` — `neither` 回指 `Collapse and civic transformation` 两项，**正确**。
- **[句 5]** `the symbolic gestures by which Hindu and Buddhist traditions redirect energy` — `by which` 为方式状语关系，**正确**。
- **[句 31]** `on ground that belongs to the city as much as to the institution` — 省略式比较（`as much as [it belongs] to the institution`），**正确**。

---

## 5. article_28（54 句，news30 改写）

**A 类 1 处（存疑）、B 类 2 处（均存疑）、C 类 2 处。整体质量高，接近无问题。**

拼写核查：全篇统一为**英式**（[8][34] `centre`、[21] `programmes`、[31] `onwards`、[37] `neighbourhood`、[38] `cancelled`、[43] `symbolised`、[5] `storeys`），无美式拼写渗入，**无英美混用**。（[20] `facade` 不带变音符，但同篇无 `façade` 并存，故不构成不统一。）
时态链核查：全篇以现在完成/一般过去叙述史实，[5] `at a moment when national policy had banned alcohol`（禁酒令先于 1924 年开业）、[36] `By then the owners had spent years` 等 past perfect 用法**均正确**。

### A 类：语法错误

- **[句 28]** 原文：`In the late 1990s the Grand Ballroom staged a live performance by the country's biggest rock band.` ｜ 问题：**定指名词的指代对象未明确建立**。`the country's` 需要读者从 [25] `Pakistan International Airlines` / [27] `The Pakistani government` 反推"巴基斯坦"，但全篇从未出现 `Pakistan` 这一国家名，且同段上文语境是美国纽约，`the country` 存在被误读为美国的风险。｜ 建议：`...a live performance by Pakistan's biggest rock band.`（**存疑**：多数读者可回推，但正式文体宜显化。）

### B 类：用词/搭配错误

- **[句 37]** 原文：`Residents and business groups in the neighbourhood raised objections about security and about the effect on local trade` ｜ 问题：**介词搭配欠妥**。`objection` 的标准搭配介词是 `to`（`objections to a plan`），`about` 多与 `concerns` 搭配；同句后半用 `the effect on` 更显示作者在 `objection to` 与 `concerns about` 之间混用。｜ 建议：`...raised objections to the security arrangements and to the effect on local trade` 或 `...raised concerns about security and about the effect on local trade`。（**存疑**：`objections about` 在新闻体有零星用例。）
- **[句 28]** 原文：`the Grand Ballroom staged a live performance by the country's biggest rock band` ｜ 问题：**施事与场所错配**。`stage` 的主语应是主办方或演出机构（`the theatre staged a play`），`Grand Ballroom` 是**厅室**而非机构，厅室只能 `host` 演出。｜ 建议：`...the Grand Ballroom hosted a live performance by ...`（**存疑**：可辩为以酒店整体代指厅室的转喻用法。）

### C 类：不自然（2 条，未用满上限）

- **[句 25]** 原文：`Ownership changed hands several times before 1979...` ｜ 问题：**语义冗余**。`change hands` 本身即指所有权转移，`Ownership changed hands` 等于"所有权发生了所有权转移"。｜ 建议：`The property changed hands several times before 1979...`
- **[句 52]** 原文：`In this view, preservation is not a matter of sentiment but of accounting, and the building might yet be saved, but only if someone finds a use for it that the market will reward.` ｜ 问题：**连接词堆叠**。一句之内叠加 `not ... but ...`、`and`、`but only if` 三重逻辑连接，句子重心被稀释，读者需回读才能确定让步关系落在何处。｜ 建议：`In this view, preservation is not a matter of sentiment but of accounting. The building might yet be saved — but only if someone finds a use for it that the market will reward.`

### 经复核判定为正确、不计入错误者

- **[句 9] / [句 53]** `what makes its fate worth examining`、`made the image worth recording` — `worth + 动名词`，**正确**。
- **[句 5]** `Named after President Theodore Roosevelt, the hotel rose nineteen storeys...` — 分词逻辑主语即 `the hotel`，**无悬垂修饰**；`rise` 表"高达"为常见用法。
- **[句 42]** `neither position can be dismissed as merely political` — `dismissed as + 形容词`（以"仅是政治性的"为由加以否定）语义成立，**非错误**。
- **[句 51] / [句 45]** `Whether the building survives or not, the issue it raises will remain` ／ `is a question that many cities will face` — 语法与搭配**均正确**。
- **[句 31]** `large numbers of migrants reached New York` — `large numbers of + 复数` 后接复数动词，**正确**。
- **[句 11]** `Guy Lombardo and his orchestra performed there ... and their version ... became a tradition` — 并列主语取复数 `their`，**正确**。

---

## 6. C_身体与动作_1（54 句，定向生成）

**A 类 2 处、B 类 3 处（其中 3 处存疑）、C 类 3 处。** 本篇论证结构与平行句式（[47]/[48]、[42]/[43]）处理得相当好，主要问题集中在冠词与拼写统一。

### A 类：语法错误

- **[句 31]** 原文：`The concept describes the experience of knowing the ethically right course of action while being prevented, by delay or by institutional barrier, from taking it.` ｜ 问题：**可数名词单数缺限定词（冠词缺失）**。`barrier` 是可数名词，在介词 `by` 后裸用单数不成立；与之并列的 `delay` 是抽象不可数名词，故可裸用，二者形式被错误地拉平。｜ 建议：`...while being prevented, by delay or by institutional barriers, from taking it.`（或 `by an institutional barrier`）
- **[句 52] 与全篇拼写** 原文：`The question that should organize both medicine and law is therefore a plain one` ｜ 问题：**同一篇内英美拼写混用（单点渗入）**。全篇其余均为英式拼写：`favour`(24)、`neighbourhood`(39)、`judgement`(7)、`labour`(22)、`demeanour`(26)、`recognise`(36)、`towards`(13)；唯 [句 52] 用美式 `organize`（英式应为 `organise`）。｜ 建议：`The question that should organise both medicine and law...`

### B 类：用词/搭配错误

- **[句 34]** 原文：`A counsel who weeps in chambers, or who cannot stop rehearsing a client's account at night, risks being read as unsuitable rather than humane.` ｜ 问题：**名词数与法律语域用词不当**。法律英语中 `counsel` 作"出庭律师"解时为集合/不可数用法（`Counsel for the defence submits...`），不说 `a counsel`；且全篇 [30][33] 用 `lawyers`、[36] 用 `law schools`，此处突然切换为英式专属术语 `counsel / chambers`，术语体系不统一。｜ 建议：`A barrister who weeps in chambers...` 或 `Counsel who weeps in chambers...`（删掉冠词）。（**存疑**：`a counsel` 在少数法律文本中可见，但非标准用法。）
- **[句 53]** 原文：`the woman who crawls to the bathroom because nobody came will remain beyond the pale of the institutions built to notice her` ｜ 问题：**成语误嵌**。`beyond the pale` 是自足的固定成语（意为"越出可接受的界限"），后面再接 `of + 名词` 属改写成语、语义走样（原意应为"被这些机构排除在外"）。｜ 建议：`...will remain outside the reach of the institutions built to notice her.`（**存疑**：`beyond the pale of X` 有零星用例，但规范文体不宜。）
- **[句 35]** 原文：`a surgeon who admits to distress is suspected of having lost nerve` ｜ 问题：**固定搭配不完整**。`lose nerve` 通常带限定词（`lose his nerve / lose their nerve`），裸用 `lost nerve` 少见且易被读作"失去神经"。｜ 建议：`...is suspected of having lost his nerve.`（**存疑**：`lose nerve` 在英式新闻体有个别用例。）

### C 类：不自然（3 条，已达上限）

- **[句 14]** 原文：`Those who perform their distress convincingly, being articulate and fluent in the language of the clinic, are believed...` ｜ 问题：`being articulate...` 这一分词插入语被夹在主语与谓语之间，`being` 又带静态描述义，读来拖沓，读者需回读才能接上 `are believed`。｜ 建议：`Those who perform their distress convincingly — articulate and fluent in the language of the clinic — are believed...`
- **[句 34]** 原文：`A counsel who weeps in chambers...` ｜ 问题（语域层面）：`chambers` 本身在法律语境中**用词正确**（非"伪古雅"），但与本篇以 `lawyer / law school` 为主的通用语域不搭，造成术语忽英式忽通用。｜ 建议：与 B 类第 1 条合并处理，全篇统一用 `lawyer`，或统一改用英式法律术语体系。
- **[句 54]** 原文：`So will the lawyer who sits in a car park, too exhausted to drive home, in a profession that still treats such exhaustion as a personal failing.` ｜ 问题：句末介词短语 `in a profession...` 与插入语 `too exhausted to drive home` 相邻，读者易先把 `in a profession` 误挂到 `drive home` 上，句法归属需回读。｜ 建议：`So will the lawyer who sits in a car park, too exhausted to drive home — a lawyer in a profession that still treats such exhaustion as a personal failing.`

### 经复核判定为正确、不计入错误者

- **[句 24]** `the limp favours the other limb` — 医学用法中 `favour a limb` 指"把体重放到（健侧）那条腿上"，**正确**。
- **[句 2]** `depends far less on the intensity of the sensation than on who occupies that body and on what observers expect to find there` — `on who...` 与 `on what...` 并列完整，比较结构**正确**。
- **[句 42] / [句 43]** `empathy is also finite and, inside institutions, unevenly distributed` ／ `procedural rather than sentimental` — 平行与副词位置**正确**。
- **[句 13]** `speaks in whole paragraphs`、`mumbles towards the floor` — 比喻用法自然，**非错误**。
- **[句 45] / [句 46]** `make recognition less dependent on the accident of who happens to be asking` ／ `can be treated only once it has been publicly credited` — 搭配与逻辑**正确**。
- **[句 40] / [句 41]** `the familiar lines of class, race, gender and citizenship`、`A nod from the right kind of patient` — **正确**；[41] 的 `the wrong kind` 系省略 `of patient`，可接受。

---

## 7. F_乡村与农作（56 句，定向生成）

**A 类 3 处（均存疑）、B 类 3 处（均存疑）、C 类 3 处。** 本篇经济论证清晰，[55] 的对称句（`Protection without investment...` / `investment without protection...`）处理得漂亮；问题集中在几处指代与介词并列细节。

拼写核查：全篇统一为**英式**（[8][14] `specialise`、[7][43] `liberalised`、[8][46] `labour`、[36] `fertiliser`、[38] `industrialised`、[51] `programme`、[36] `licensed`），无美式拼写渗入，**无英美混用**。

### A 类：语法错误

- **[句 41]** 原文：`Indian officials describe agriculture not as a commercial question but as a livelihood question, on which seven hundred million people depend.` ｜ 问题：**关系从句先行项与语义不匹配**。`on which ... depend` 的先行项是紧邻的 `a livelihood question`，字面成为"七亿人依赖一个'问题'"，而作者本意是七亿人依赖**农业**。｜ 建议：`...not as a commercial question but as a question of livelihood, since seven hundred million people depend on agriculture.`（**存疑**：可勉强读作"生计问题"，但句法先行项确实指错。）
- **[句 22]** 原文：`Every deduction, whether for transport, moisture or broken grain, reduces the sum that eventually returns to the family that produced it.` ｜ 问题：**代词指代不明**。`it` 最贴近的先行项是 `the sum`，但"生产出这笔钱"讲不通，作者本意是 `the grain/crop`；中间又插入 `that eventually returns to the family`，使回指距离拉远。｜ 建议：`...reduces the sum that eventually returns to the family that grew the crop.`（**存疑**：读者可自行纠正，但正式文体宜显化。）
- **[句 28]** 原文：`It is tempting, faced with such evidence, to regard the peasant as a primitive, a figure stranded outside history whose habits of planting and saving were once presumed to be irrational.` ｜ 问题：**悬垂修饰 + 时态冲突**。`faced with such evidence` 的逻辑主语应是观察者（"我们"），但主句是 `It is tempting` 这一无人称结构，分词无着落；同时 `were once presumed`（过去）与 `It is tempting`（现在）冲突——既已被否定，何以现在仍"诱人"。｜ 建议：`Faced with such evidence, one is tempted to regard the peasant as a primitive, a figure stranded outside history whose habits of planting and saving have long been presumed irrational.`（**存疑**：`faced with X, it is tempting to Y` 在评论文体有用例，属边缘用法。）

### B 类：用词/搭配错误

- **[句 30]** 原文：`a single bad season can erase a decade of saving` ｜ 问题：**名词数/词义偏差**。表"积攒下来的钱"应用可数复数 `savings`；`saving` 作不可数名词指"储蓄这一行为/习惯"，"抹掉十年的储蓄行为"讲不通。｜ 建议：`...can erase a decade of savings.`（**存疑**：`saving` 偶作集合用法，但 `savings` 才是规范形式。）
- **[句 35]** 原文：`For the smallholder, integration has delivered a narrower margin and a wider risk.` ｜ 问题：**搭配欠妥**。`deliver` 要求可"交付"的结果（`delivered growth/prosperity`），`deliver a wider risk` 动宾不搭；且 `a wider risk` 本身不是英语的常规表达（风险说 `greater/greater exposure`，宽度用于 `margin`）。｜ 建议：`For the smallholder, integration has meant a narrower margin and greater risk.`（**存疑**：作者或刻意让 `narrower/wider` 形成对照，但 `wider risk` 仍属生造。）
- **[句 2]** 原文：`The price of wheat, rice or maize is not settled in the district where the crop is grown, nor even in the capital of the country that exports it.` ｜ 问题：**否定延伸词选择欠佳**。前句已是否定，续接时英语惯用 `or even`（`not ... or even ...`）；`nor even` 虽有用例，但在 `not + 介词短语` 的结构后接 `nor` 略显生硬。｜ 建议：`...is not settled in the district where the crop is grown, or even in the capital of the country that exports it.`（**存疑**：`nor even` 见于部分规范文本，故不计为硬错。）

### C 类：不自然（3 条，已达上限）

- **[句 39]** 原文：`Poorer governments, sensing that the rules were written by those who benefit from them, have grown correspondingly reluctant to make concessions.` ｜ 问题：`correspondingly` 用于此处的逻辑对应关系含糊（与什么"相应地"？），属连接副词误用。｜ 建议：`...have grown increasingly reluctant to make concessions.` 或 `...have therefore grown reluctant to make concessions.`
- **[句 24]** 原文：`Market power, moreover, is concentrated to a degree that the language of competitive trade obscures.` ｜ 问题：`to a degree that...` 与 `is concentrated` 之间隔了 `moreover`，且 `to a degree` 与关系从句套叠，读者需回读才能确定"被遮蔽"的是集中的程度还是集中这一事实。｜ 建议：`Market power, moreover, is concentrated to a degree that the language of competitive trade conceals.`（保留原句但删去 `moreover` 位置干扰）或改 `Market power is more concentrated than the language of competitive trade admits.`
- **[句 30]** 原文：`What distinguishes them is not mentality but circumstance, since they operate in markets where the state is absent, insurance is unavailable and a single bad season can erase a decade of saving.` ｜ 问题：`where` 引导的从句内并列三项，其中前两项为状态、第三项为事件（`a single bad season can erase...`），并列项性质不齐，读来有顿挫。｜ 建议：`...in markets where the state is absent and insurance unavailable, and where a single bad season can erase a decade of savings.`

### 经复核判定为正确、不计入错误者

- **[句 8]** `Countries should specialise where they possess comparative advantage` — `where` 表抽象情境（"在具备比较优势之处"），**正确**（法律/经济文体常见）。
- **[句 11]** `are costs that the small producer must accept as given rather than negotiate` — `accept as given` 与 `negotiate` 并列共享 `must`，**正确**。
- **[句 37]** `processed goods are taxed more heavily than raw commodities, which discourages the very processing...` — 非限定 `which` 回指整个前分句，**正确**。
- **[句 46]** `it also withdraws the labour on which the next planting depends` — `depend on` 介词前置为 `on which`，**正确**。
- **[句 50]** `the rural poor, who are net buyers of grain, are harmed twice over` — 复数主语取 `are`，**正确**；`twice over` 为固定搭配。
- **[句 55]** `Protection without investment merely transfers income from consumers to landlords, while investment without protection leaves farmers exposed to a competition they did not choose.` — 平行结构与 `exposed to` 搭配**均正确**。
- **[句 3]** `farmgate`（农场交货价）为农业经济学术语，**拼写可接受**，不计入错误。

---

## 8. L_文学叙事（57 句，定向生成）

**A 类 3 处（其中 1 处存疑）、B 类 3 处（其中 3 处存疑）、C 类 3 处。** 本篇是八篇中论证最紧凑者，[21] `Boys are given verbs and girls are given adjectives` 与 [54] `not censorship but multiplication` 均为地道表达；问题集中在时态与平行结构。

### A 类：语法错误

- **[句 13]** 原文：`Sexual references were softened; Rapunzel's revealing remark about her clothing supplants the original declaration that she is pregnant.` ｜ 问题：**时态错误**。前分句用过去时 `were softened`，且 [4][12] 均以过去时叙述十九世纪的编订过程，此处 `supplants`（一般现在时）突然切到现在，混用叙事时间层。｜ 建议：`...Rapunzel's revealing remark about her clothing supplanted the original declaration that she was pregnant.`（从句 `she is pregnant` 亦应随主句 backshift 为 `she was pregnant`。）
- **[句 55]** 原文：`We need tales in which a girl is not only a bride, a boy is not only a lad with a sword, and a widow may run the kingdom.` ｜ 问题：**平行结构破坏**。前两个分句共用 `is not only + 名词` 框架，第三分句却换成 `may run + 名词`，读者会先按前两项模式预期 `a widow is not only a widow` 之类，句法期待落空。｜ 建议：`We need tales in which a girl is not only a bride, a boy is not only a lad with a sword, and a widow is not only a mourner — she may run the kingdom.` 或简化为 `...and a widow may be the one who runs the kingdom.`（与前三项拉开后自成语义单元）
- **[句 19] / [句 20] / [句 35] / [句 31] / [句 32]** 原文：`A princess is characterized by what she endures` ／ `A lad is characterized by what he executes` ／ `a girl ... will recognise it when it arrives` ／ `a market and a moral programme` ｜ 问题：**同一篇内英美拼写混用**。[19][20] 用美式 `characterized`（英式 `characterised`），而 [35] 用英式 `recognise`（美式 `recognize`）、[31][32] 用英式 `programme`、[5] 等用 `-our` 型无美式渗入。｜ 建议：全篇统一为英式（`characterised / recognise / programme`）。（**存疑**：`-ize` 拼法在牛津体系中被接受，故严格说不算错拼，但**同一篇内混用**仍属不统一。）

### B 类：用词/搭配错误

- **[句 12]** 原文：`A mother who plots against her daughter in the first edition becomes a stepmother in a later one, because a mother, they assessed, could not be so abnormal.` ｜ 问题：**词义误用**。格林兄弟改动的理由是该行为在道德上"不合母性"，英语对应词是 `unnatural`；`abnormal` 指统计学/生理上的"异常"，用于描述邪恶程度属词义偏移。｜ 建议：`...because a mother, they judged, could not be so unnatural.`（**存疑**：`abnormal` 可勉强引申，但远不如 `unnatural` 贴切。）
- **[句 20]** 原文：`A lad is characterized by what he executes: he outsmarts a thief, traverses a desert, kills a monster, and thereby obtains his reward.` ｜ 问题：**动词选用生硬**。`execute` 作"执行、实施"时宾语应为计划、命令、动作等（`execute a plan`），此处要与 [19] 的 `endures` 对仗，但 `what he executes` 指代不明（他执行的是什么？），英语惯用 `what he does / what he accomplishes`。｜ 建议：`A lad is characterized by what he accomplishes: he outsmarts a thief...`（**存疑**：作者或刻意用 `execute` 的"施行"义与 `endure`（承受）构成主动/被动对照，但读来仍别扭。）
- **[句 28]** 原文：`the old woman who sets a youngster an impracticable task and rewards the one who shows benevolence` ｜ 问题：**近义词选择欠妥**。童话中这类任务的特征是"无法完成"，英语用 `impossible task`；`impracticable` 意为"不切实际、难以施行"，多用于方案与建议，与童话母题不搭。｜ 建议：`...sets a youngster an impossible task and rewards the one who shows kindness.`（**存疑**：`impracticable` 并非硬错，但属词义偏移，另 `benevolence` 偏书面抽涩，`kindness` 更贴合叙事语域。）

### C 类：不自然（3 条，已达上限）

- **[句 1]** 原文：`Every child in the English-speaking world inherits the same small cast: a queen, a princess, a wedding, and the promise of happiness that follows.` ｜ 问题：`cast`（演员阵容/人物群）后接的四项中，`a wedding` 与 `the promise of happiness` 并非"人物"，类别不齐，冒号后的列举与 `cast` 的语义要求冲突。｜ 建议：`Every child in the English-speaking world inherits the same small cast — a queen, a princess, a wicked stepmother — and the same promise of happiness at the end.`
- **[句 17]** 原文：`The bride who appears at the end of such a story is less a person than a trophy, and the tale is clear that she has been gained.` ｜ 问题：`the tale is clear that...` 不是英语的常规句式（`clear` 作表语时主语通常为 `it`，由外置从句承担内容），读来生硬。｜ 建议：`...and the tale makes it clear that she has been won.`
- **[句 44]** 原文：`A revision that preserves the throne, the wedding, and the beautiful heroine has preserved the structure that mattered.` ｜ 问题：`preserves`（一般现在，泛指）与 `has preserved`（现在完成，结果）时态搭配别扭，且 `mattered` 的过去时又引入第三层时间，一句内三个时间层。｜ 建议：`A revision that preserves the throne, the wedding, and the beautiful heroine has preserved the structure that matters.`

### 经复核判定为正确、不计入错误者

- **[句 2]** `The familiarity of these figures constitutes precisely what makes them worth examining.` — **`constitute` 用法正确**（"熟悉感构成……"），非 `comprise` 误用。
- **[句 7]** `a cultural legacy that most adults never think to question` — `think to do`（想到要去做）为固定用法，**正确**。
- **[句 5]** `a substantial set of stories exceptionally well suited to instructing children what a woman should want` — `suited to + 动名词` **正确**；`instruct sb what...` 双宾结构**正确**。
- **[句 15]** `in which a girl's future is a wedding, her virtue is compliance, and her reward is a gentleman with property` — 三项平行且均为主系表，**正确**。
- **[句 34]** `a template into which a child fits later experience` — `fit X into Y` 的介词前置形式，**正确**。
- **[句 39]** `It would be comforting to suppose that children resist what they are told` — 虚拟/委婉的 `would` 与 `what` 从句**正确**。
- **[句 46]** `where women who seek authority are still described as unnatural and men who decline it are described as weak` — 两个 `who` 从句平行、`decline it` 回指 `authority`，**正确**。
- **[句 25]** `Compliance is valued as a girl's virtue, while violence is valued as a boy's courage` — `valued as + 名词` **正确**，对照工整。

---

## 汇总

| 篇名 | A类 | B类 | C类 | 备注 |
|---|---|---|---|---|
| article_04 | 0 | 0 | 0 | **未发现问题** |
| article_10 | 5（1 存疑） | 3（2 存疑） | 3 | 主谓不一致、comma splice |
| article_16 | 1（存疑） | 2（1 存疑） | 3 | 整体扎实 |
| article_22 | 4（1 存疑） | 3（2 存疑） | 3 | 英美拼写系统性混用 |
| article_28 | 1（存疑） | 2（2 存疑） | 2 | 质量最高之一 |
| C_身体与动作_1 | 2 | 3（3 存疑） | 3 | 冠词缺失 + 拼写渗入 |
| F_乡村与农作 | 3（3 存疑） | 3（3 存疑） | 3 | 多为边缘用法 |
| L_文学叙事 | 3（1 存疑） | 3（3 存疑） | 3 | 时态与平行 |
| **合计** | **19**（其中存疑 8） | **19**（其中存疑 16） | **20** | — |

若只计**确定错误**（排除存疑）：**A 类 11 处、B 类 3 处、C 类 20 处**。

### 系统性问题

1. **英美拼写混用是最大的系统性缺陷**：8 篇中 4 篇出现混用（article_10 `centered`/`realises`；article_22 最严重，`scepticism` 与 `skeptical` 相隔 6 句、`façade` 与 `facade` 并存；C_身体与动作_1 全篇英式却单点出现 `organize`；L_文学叙事 `characterized` 与 `recognise` 并存）。**建议在生成流程中固定 locale 参数并加自动校验。**
2. **可数名词单数裸用/冠词误用**是第二大问题（article_22 [1] `the city` 定指过早、C_身体与动作_1 [31] `by institutional barrier`、F_乡村与农作 [30] `a decade of saving`），集中在抽象名词与可数名词并列处；同型问题在 group1–3 亦反复出现。
3. **C 类问题（不自然）普遍且同质**：几乎全部源于**同句内同词重复**（article_10 [23]/[28]、article_22 [59]）与**连接词/副词堆叠**（article_16 [42]、article_28 [52]、L_文学叙事 [44]），属可批量修正的风格问题。
4. article_04 完全干净，说明"news30 改写"路线的质量上限可达标；而三篇"定向生成"（C/F/L）在拼写与搭配上反而问题更多，提示**定向生成模板缺少拼写与搭配校验**。
