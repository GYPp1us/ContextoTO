# group6 语法与用法审校报告

审校范围：`/root/DSH/kaoyan-vocab/internal/grammar_review/group6/` 全部 8 篇（共 448 句，逐句通读，不抽样）。

分类口径：
- **A 类（语法错误）**：主谓不一致、时态/语态错误、冠词缺失或误用、介词搭配错、从句结构错、悬垂修饰、平行结构破坏、代词指代不明、逗号粘连。
- **B 类（用词/搭配错）**：动词后置介词被误前置为 `in which`、`perform a role` 缺 `as`、动宾不搭、固定短语误用、形近词混淆、词性用错。
- **C 类（不自然，每篇最多 3 条）**：伪古雅词、同句同词重复、连接词堆叠。

已确认**不报错**的可接受变体（前几组复核结论）：`a number of X have`、`majority of X are`、`consider X to be`、`series of X that do`、`indexes`/`indices`、`none of X has`、`per cent`（分写）、`Labor`（澳党名）、`who` 作宾语、`be welcome in a country`、复合主语按就近原则取单数。

| 篇名 | A 类 | B 类 | C 类 | 其中存疑 |
|---|---|---|---|---|
| article_06 | 0 | 2 | 2 | 0 |
| article_12 | 0 | 2 | 2 | 2 |
| article_18 | 1 | 0 | 3 | 2 |
| article_24 | 3 | 3 | 2 | 5 |
| article_30 | 3 | 1 | 1 | 3 |
| D_情感与性格_1 | 1 | 1 | 1 | 3 |
| H_运动与旅行 | 1 | 2 | 3 | 2 |
| N_感知与言说 | 1 | 1 | 1 | 3 |
| **合计** | **10** | **12** | **15** | **20** |

---

## article_06（news30改写，59 句）

**A 类（语法错误）：未发现问题。**

**B 类（用词/搭配错）：2 处**

1. **[26] 动宾搭配错（`perform` + 抽象记忆，宾语不搭）**
   - 原文：`They perform the memory of their own trade for the benefit of visitors who have come, in the majority of cases, simply for a day out.`
   - 问题：`perform` 的宾语须是可执行的实体动作/作品（perform a play / a role / a task），不能是 `memory`。与上文 [25] `serve as guides` 的语义也冲突。
   - 最小修改：`They perform the rituals of their own trade for the benefit of visitors...` 或 `They re-enact the memory of their own trade for the benefit of visitors...`

2. **[52] 英美拼写混用（同篇内 BrE 与 AmE 并存）**
   - 原文：`He says that if you want to honor the dead, you should not hide the fight that killed them.`
   - 问题：全篇为英式拼写（[5] `centres`、[38] `centre`、[12]/[23] `colour`），此处 `honor` 为美式，应作 `honour`。`-or` 不是 Oxford spelling 的容许变体（`-ize`/`-ise` 才是），属真错。
   - 最小修改：`honor` → `honour`

**C 类（不自然）：2 处**

1. **[48] 连接词堆叠（because + since 同句表述同一因果关系）**
   - 原文：`He does not go inside, because he says he does not need a museum to remember what happened, since he was there.`
   - 最小修改：删去 `since`，改为 `...because he says he does not need a museum to remember what happened; he was there.`

2. **[34] 同句同词重复（`own` 两次，且 `own` 与 `personal` 语义叠加）**
   - 原文：`The reason may be simple: people protect what they regard as their own possession, and they resent an official account of what their own personal history means.`
   - 最小修改：`people protect what they regard as their own, and they resent an official account of what their personal history means.`

**其他核查（未报错）**：[5] `a considerable number of those same sites have been reborn`（`a number of + 复数 + have`，允许）；[20] `to admire... to descend... to imagine` 平行结构完整；[33] `Where local communities have retained...` 状语从句用法正确；[28] `the exceptions are instructive enough to deserve` 搭配成立；[35] `which is precisely why` 指代整个主句，成立。
## article_12（news30改写，54 句）

**A 类（语法错误）：未发现问题。**

**B 类（用词/搭配错）：2 处（其中 1 处存疑）**

1. **[20] 名词搭配不当（`sections of a pattern`）**
   - 原文：`These are not isolated incidents but sections of a very broad pattern of disinvestment, a pattern documented in detail by staff unions and local newspapers.`
   - 问题：`section` 指实体的"部分/断面"，不能用来指"模式中的一个个事例"；此处应为 `instances` 或 `part of a broader pattern`。
   - 最小修改：`...but instances of a very broad pattern of disinvestment...`

2. **[13] 主谓语义搭配不当（存疑）**
   - 原文：`The evidence has followed very quickly, indeed almost immediately, for humanities enrolments have fallen to a ten-year low.`
   - 问题：`follow` 的主语通常是"后果/结果"，`evidence`（证据）本身不"接踵而至"；语义上应为 consequences/results。语法无误，故标存疑。
   - 最小修改：`The consequences have followed very quickly, indeed almost immediately, for humanities enrolments have fallen to a ten-year low.`

**C 类（不自然）：2 处（其中 1 处存疑）**

1. **[24] 同句同义副词堆叠（`quietly` + `almost imperceptibly`）**
   - 原文：`...and the authority to decide what counts as useful knowledge shifts quietly towards administrators, almost imperceptibly.`
   - 最小修改：`...shifts quietly towards administrators, almost imperceptibly.` → `...shifts, almost imperceptibly, towards administrators.`（保留一个副词）

2. **[25] 状语搭配自相矛盾（存疑，`often never`）**
   - 原文：`...and perhaps the most consequential loss is the one often never recorded at all.`
   - 问题：`often`（经常）与 `never`（从不）语义冲突。
   - 最小修改：`...the one that is often simply never recorded.` 或 `...the one that is never recorded at all.`

**其他核查（未报错）**：[3] `a Labor cabinet`（澳党名，正确）；[9] `117 per cent`（分写，正确）；[31] `a tolerance for ambiguity`、[36] `a tolerance for uncertainty` 为跨句重复，非句内重复，不计 C 类；[2] `to simply abolish` 分裂不定式属可接受变体；[24] `towards`、[27] `judgement`、[50] `labour market` 均为英式拼写，全篇一致（专名 `Labor` 除外），无英美混用。
## article_18（news30改写，54 句）

**A 类（语法错误）：1 处（存疑）**

- **[12] 结果状语 `thus creating` 的隐含主语与主句主语不一致（存疑）**
  - 原文：`Its stated aims are to reduce the flow of drugs across the southern border and to persuade manufacturers to move their operations home, thus creating more American jobs.`
  - 问题：主句主语是 `Its stated aims`，`-ing` 结果状语在严格句法上要求与主句主语同指，而"创造就业"的是"把业务迁回本国"这一行为，不是"目标"本身。语义可解，多数语法书接受此类结果状语，故标存疑。
  - 最小修改：`...and to persuade manufacturers to move their operations home, a shift that would create more American jobs.`

**B 类（用词/搭配错）：未发现问题。**

**C 类（不自然）：3 处（其中 1 处存疑）**

1. **[26] 同句近义词冗余（`chosen` 与 `selected`）**
   - 原文：`When trade measures are used to apply political pressure, the goods chosen are selected for their symbolic value rather than for any economic logic.`
   - 最小修改：`...the goods chosen are determined by their symbolic value rather than by any economic logic.`

2. **[41] 同句同词重复（`restraint` 两次）**
   - 原文：`Yet the deeper weakness is not legal but political: a system that depends upon the restraint of its most powerful members cannot continue to function when restraint is treated as weakness.`
   - 最小修改：`...a system that depends upon the self-restraint of its most powerful members cannot function once forbearance is treated as weakness.`

3. **[34] 状语位置歧义（存疑）**
   - 原文：`The three main American indexes have fallen sharply, and the broadest measure ended one day more than 10 per cent below its recent high.`
   - 问题：`one day`（在某一天）与 `more than 10 per cent` 紧邻，易被读成时段。
   - 最小修改：`...and the broadest measure ended the day more than 10 per cent below its recent high.`

**其他核查（未报错）**：[34] `indexes`（允许）；[9]、[29] `a duty/that a duty is a tax` 与 [43] `understand duties to be a tax`（`duties are a tax` 为新闻体公认用法，不按主谓数不一致报错）；[2] `a series of decisions whose effects reach...`（`a series of X that/whose do` 模式，允许）；[13] `aluminium`、[54] `defence`、[4]/[38] `centre` 为英式，`World Trade Organization` 属专名固定拼写，不构成英美混用错误；[19] `become collateral damage` 为既成习语。
## article_24（news30改写，57 句）

**A 类（语法错误）：3 处（其中 2 处存疑）**

1. **[45] 介词搭配错**
   - 原文：`Independent analysis suggests that they are probably authentic, though doubts have been raised from credible sources.`
   - 问题：`raise doubts` 的施事用 `by`，不用 `from`；`from` 只能表来源处所，不能引出施动者。
   - 最小修改：`...though doubts have been raised by credible sources.`

2. **[43] 代词指代不明（存疑）**
   - 原文：`In May 2026 a Spanish outlet released thirty-seven audio messages attributed to politicians, including Asfura and Hernández. They describe his return as one part of a broader scheme...`
   - 问题：`They` 前方有两个复数名词（`audio messages` / `politicians`），严格说指代不唯一；语义上指"录音内容/录音中的人"。
   - 最小修改：`The recordings describe his return as one part of a broader scheme...`

3. **[49] 平行结构破坏（时态形式不一致，存疑）**
   - 原文：`It has raided Venezuela to arrest its president on drug charges, continues to apply sanctions to Cuba, and has used varying degrees of influence to affect elections from Colombia to Brazil.`
   - 问题：三个并列谓语分别为 `has raided` / `continues to apply` / `has used`，第二个换用一般现在时，破坏并列形式。
   - 最小修改：`It has raided Venezuela..., has continued to apply sanctions to Cuba, and has used varying degrees of influence...`

**B 类（用词/搭配错）：3 处（其中 2 处存疑）**

1. **[26] 动宾不搭（`charges` + `belong to`）**
   - 原文：`The charges belonged to a corruption scheme known as Pandora, which embezzled twelve million dollars of public funds...`
   - 问题：罪名/指控不能"属于"某个方案；应为"源于/源自"。
   - 最小修改：`The charges arose from a corruption scheme known as Pandora...`

2. **[3] `convicted of ... charges`（存疑）**
   - 原文：`...Hernández was convicted in 2024 of cocaine trafficking and related charges and sentenced to forty-five years in prison.`
   - 问题：`convict` 的固定搭配为 `convicted of + 罪名` 或 `convicted on + charges`，"convicted of ... charges" 属搭配混用（新闻体常见但不严谨）。
   - 最小修改：`...was convicted in 2024 of cocaine trafficking and related offences...`

3. **[34] 美国官衔写法（存疑）**
   - 原文：`...while the American secretary of defence announced agreements for joint operations on Honduran, Colombian and Guatemalan soil.`
   - 问题：美国官衔固定为 `Secretary of Defense`；全篇为英式拼写，但专名官衔不宜英化。
   - 最小修改：`...the American Secretary of Defense announced agreements...`

**C 类（不自然）：2 处（其中 1 处存疑）**

1. **[53] 连接词堆叠（`Meanwhile` + `while`）**
   - 原文：`Meanwhile a special unit of Honduran forces was assigned to protect Hernández, while homicide and disappearance rates continue to rise.`
   - 最小修改：`A special unit of Honduran forces was meanwhile assigned to protect Hernández, while homicide and disappearance rates continue to rise.`（删去句首 `Meanwhile`）

2. **[52] 主语与谓语动作不搭（存疑）**
   - 原文：`Remittances, on which the economy heavily depends, are threatened by immigration crackdowns that deport thousands of people who fear violence at home.`
   - 问题：`crackdowns`（打击行动）本身不能 `deport`（驱逐），施行者应为当局；属转喻用法，略不严谨。
   - 最小修改：`...are threatened by immigration crackdowns that lead to the deportation of thousands of people who fear violence at home.`

**其他核查（未报错）**：[55] `None of this appears`（`none of X has` 类，允许）；[52] `on which the economy heavily depends`（介词前置正确，非误前置）；[24] `defence`、[30] `neighbour` 等英式拼写全篇一致；[19] 分号连接两个独立分句，正确；[3] 句首过去分词短语 `Extradited to the United States in 2022...` 与主句主语 `Hernández` 同指，无悬垂。
## article_30（news30改写，53 句）

**A 类（语法错误）：3 处（其中 2 处存疑）**

1. **[31] 平行结构破坏（`not merely` 分句缺少谓语）**
   - 原文：`That figure is clear evidence that demand for the fuel is outpacing supply, and not merely the demand for crude oil itself.`
   - 问题：`and not merely the demand for crude oil itself` 被写成与 `supply` 并列的成分，但语义上是要否定"原油需求"这一主语，结果第二个并列项没有谓语，结构不成立。
   - 最小修改：`That figure is clear evidence that demand for the fuel, and not merely demand for crude oil itself, is outpacing supply.`

2. **[2] 时态不一致（存疑）**
   - 原文：`Its price now stands at a record level that few analysts expected a year ago, and by September 2026 the national average in the United States had reached $6.28 a gallon.`
   - 问题：前半句以现在时 `stands` 为时间锚点，后半句却用过去完成时 `had reached`；以"现在"为参照时，`by September 2026` 应用现在完成时或一般过去时。
   - 最小修改：`and by September 2026 the national average in the United States had reached $6.28 a gallon` → `and in September 2026 the national average in the United States reached $6.28 a gallon`（或保留 `by` 并改为 `has reached`）

3. **[44] 结构歧义（`which` 从句内的并列谓语归属不清，存疑）**
   - 原文：`Prices for the coming winter are already up by 30% or more, which will place an additional burden on households that are least able to pay and may require public support.`
   - 问题：`may require public support` 与 `will place` 并列时主语是 `which`（涨价），语义荒谬；与 `that are least able to pay` 并列时主语是 households。句法上两读皆通，属歧义。
   - 最小修改：`...which will place an additional burden on households that are least able to pay and that may require public support.`

**B 类（用词/搭配错）：1 处（存疑）**

1. **[1]/[42] 英美体例混用（存疑）**
   - 原文：`...it is chemically close to the oil that heats homes in the north-east.`；`...is a primary heating fuel in the north-east.`
   - 问题：全篇为美式语境与美式拼写（[9] `sulfur`、[35] `railroads`、[2] `$6.28 a gallon`），却用英式连字符 `north-east`（美式作 `northeast`）。
   - 最小修改：`north-east` → `northeast`（两处）；或统一为英式（则 `sulfur`→`sulphur`、`railroads` 保持）。属体例统一问题，非硬错误。

**C 类（不自然）：1 处**

1. **[46] 同句同词重复（`proposed` / `proposed`）**
   - 原文：`Policy responses have been proposed, but their value is uncertain: in mid-September a senior senator proposed banning exports of diesel in order to increase domestic availability.`
   - 最小修改：`Policy responses have been put forward, but their value is uncertain: in mid-September a senior senator proposed banning exports of diesel in order to increase domestic availability.`

**其他核查（未报错）**：[1] `the fuel on which freight, farming and construction depend`（介词前置正确）；[35] `The vast majority of American diesel is used`（`majority of X are` 类允许，且此处为被动单数，无争议）；[26] `large shipments to Europe, a cold winter and heavy freight demand were pushing`（复合主语用复数，正确）；[5] `Three forces, two of which...`，[20] `the lowest figure for that point in the calendar since 1951` 均无误；[29] `demand is fixed` 为经济学固定表述，不报错。
## D_情感与性格_1（定向生成，59 句）

**A 类（语法错误）：1 处（存疑）**

1. **[3] 并列主语与关系从句谓语数不一致（存疑）**
   - 原文：`It is the sustained hostility that reformers must endure, and the psychological price exacted by that endurance, which usually determines whether a challenge survives.`
   - 问题：`which` 的先行项是 `the sustained hostility ... and the psychological price ...` 两个并列名词短语（整体概念为复数），谓语却用单数 `determines`。属强调句中的主谓一致问题。
   - 最小修改：`...which usually determine whether a challenge survives.`（或改为 `that usually determines` 并把并列改为单一中心词）

**B 类（用词/搭配错）：1 处（存疑）**

1. **[26] 动宾搭配不严谨（存疑）**
   - 原文：`...reformers who are young, female, or otherwise remote from the prevailing centre of authority attract a harsher and more personal register of attack.`
   - 问题：`attract` 的宾语应为攻击本身（attacks/hostility），`a register of attack`（攻击的语体/调门）是"攻击的方式"，不能直接作 `attract` 的宾语。
   - 最小修改：`...attract harsher and more personal attacks.`

**C 类（不自然）：1 处（存疑）**

1. **[3] 同句同根词重复（`endure` / `endurance`）**
   - 原文：`It is the sustained hostility that reformers must endure, and the psychological price exacted by that endurance, which usually determines whether a challenge survives.`
   - 最小修改：`...the sustained hostility that reformers must endure, and the psychological price exacted by that suffering, which usually determines...`

**其他核查（未报错）**：[4]-[59] 通读未见主谓、时态、语态、冠词或介词错误；[28] `freedom-of-information requests designed to exhaust them` 平行正确；[41] `consists of continuing..., of repeating..., and of resisting...` 三项 `of + 动名词` 平行完整；[48]-[49] `is not that..., It is that...` 表语从句平行正确；[5] `as though conviction were`（虚拟语气正确）；[53] `Anonymous reporting channels, ... and explicit protection ... all reduce`（复数谓语正确）；拼写全篇统一为英式（`recognisable`、`realisation`、`organisation`、`centre`、`towards`、`acknowledgement`），无英美混用。
## H_运动与旅行（定向生成，55 句）

**A 类（语法错误）：1 处（存疑）**

1. **[20] 介词搭配错（`allocate funds ... on X`）**
   - 原文：`Success on that scale compelled the committee to allocate funds it had not obtained, on drainage, seating and the wages of a second professional.`
   - 问题：`allocate` 的搭配是 `allocate funds to/for + 用途`，不用 `on`；此处 `on` 系受 `spend money on` 类表达干扰。
   - 最小修改：`...to allocate funds it had not obtained, to drainage, seating and the wages of a second professional.`（用 `to` 或 `for`）

**B 类（用词/搭配错）：2 处（其中 1 处存疑）**

1. **[50] 固定短语误用（`maintain ... together`，应为 `hold ... together`）**
   - 原文：`These small certainties maintain a community together precisely when the larger ones have gone.`
   - 问题：`maintain` 是及物动词，本身已含"使持续"之义，不能与表结果的 `together` 搭配；表示"维系不散"的固定短语是 `hold ... together` 或 `keep ... together`。
   - 最小修改：`These small certainties hold a community together precisely when the larger ones have gone.`

2. **[4]/[28]/[29] 英美语域混用（`vacation`，存疑）**
   - 原文：`...clerks who required somewhere to occupy their half-day vacation.` / `...relied upon an absurd accident during the winter vacation.` / `...a family vacation in Austria...`
   - 问题：全篇为英国背景与英式拼写（`colours`、`favourite`、`travelling`、`pounds`、county cricket），英式英语中"休假"用 `holiday`，`vacation` 属美式用词；且 [29] 同句既用 `vacation` 又用 `trip`，更显不一致。
   - 最小修改：`half-day holiday` / `winter holiday` / `family holiday in Austria`。

**C 类（不自然）：3 处**

1. **[24] 伪古雅词 + 搭配错误（`commenced to be filled`）**
   - 原文：`...and the club's second eleven commenced to be filled with men in their forties.`
   - 问题：`commence` 属伪古雅词（全篇 [9] 亦用 `commenced`），且 `commence` 后接不定式表"开始做某事"，用被动 `commenced to be filled` 既不自然又费解。
   - 最小修改：`...and the club's second eleven began to fill with men in their forties.`

2. **[18] 同句同词重复（`approximately`，全篇共 4 次）**
   - 原文：`A fast bowler's delivery struck an opposing batsman above the eye, and an ambulance required approximately eleven minutes to reach him...`
   - 问题：`approximately` 在 [1]、[18]、[23]、[33] 反复出现（`approximately a century`、`approximately eleven minutes`、`approximately two thousand jobs`、`approximately forty thousand pounds`），已成模板化堆砌。
   - 最小修改：改用 `about`、`some`、`nearly` 等交替，如 `and an ambulance took about eleven minutes to reach him`。

3. **[12] 同句同词重复（`achievement` / `achieved`）**
   - 原文：`Within three seasons the team had qualified for a national tournament, an achievement that no club of comparable size had previously achieved.`
   - 最小修改：`...an achievement that no club of comparable size had previously matched.`

**其他核查（未报错）**：[1]-[55] 通读未见主谓不一致、时态错乱、冠词缺失、悬垂修饰或逗号粘连；[26] `the driver, unable to steer, brought it to rest` 插入语与主语同指，正确；[35] 分号连接两个独立分句，正确；[41] `of Britain, of continental Europe and of the American Midwest` 三项平行完整；[49] `not that..., but that...` 表语从句平行正确；[30] `in the role of air ambulance` 为 `in the role of` 固定用法（非 `perform a role` 缺 `as`），不报错。
## N_感知与言说（定向生成，57 句）

**A 类（语法错误）：1 处（存疑）**

1. **[37] 修饰语与中心词不搭（错位修饰，存疑）**
   - 原文：`When a mayor attempts to explain the reasoning behind a local ordinance, the response is often to yell across a committee room more interested in the spectacle than in the statute.`
   - 问题：`more interested in the spectacle than in the statute` 的句法中心词是 `a committee room`，而"感兴趣"的只能是房间里的人；属转喻式修饰，严格句法上错位。
   - 最小修改：`...the response is often to yell across a committee room whose members are more interested in the spectacle than in the statute.`

**B 类（用词/搭配错）：1 处（存疑）**

1. **[11] 主语与谓语搭配不当（存疑，`a parliamentary yell` + `obliged`）**
   - 原文：`A pamphlet provoked a reply, a sermon invited a congregation's objection, and a parliamentary yell from the opposition benches obliged the minister to justify his policy in the same room.`
   - 问题：`a yell`（喊叫）本身不能 `oblige`（迫使）部长作解释，迫使部长的是质询这一行为；且 `parliamentary yell` 非常规搭配（通常作 `a challenge` / `a question`）。与前两项 `A pamphlet provoked`、`a sermon invited` 的具体施事也不平行。
   - 最小修改：`...and a challenge from the opposition benches obliged the minister to justify his policy in the same room.`

**C 类（不自然）：1 处（存疑）**

1. **[23] 名词化生硬（`a permanent mutter`）**
   - 原文：`A permanent mutter runs beneath the argument: officials complain that governing under constant scrutiny is impossible...`
   - 问题：`mutter` 作可数名词极罕见（通常用 `muttering` 或 `murmur`），`a permanent mutter runs beneath` 生硬。
   - 最小修改：`A permanent murmur runs beneath the argument: ...`

**其他核查（未报错）**：[19] `the excitement of denunciation substitutes for the labour of judgement`（`substitute for` 搭配正确）；[56] `the foundation on which every functioning institution rests`（介词前置正确）；[46] `None of this will satisfy`（`none of X has` 类，允许）；[40] 三项并列主语配复数谓语 `all assume`，正确；[25]、[41]、[53] 各句平行结构与代词指代均无问题；拼写全篇统一为英式（`neighbours`、`neighbourhoods`、`labour`、`judgement`），无英美混用；未见主谓不一致、时态错误、冠词误用或逗号粘连。

---

## 汇总

### 分类统计

- **A 类（语法错误）**：10 处，其中**存疑 5 处**
  （article_18 ×1 存疑、article_24 ×3 存疑 2、article_30 ×3 存疑 2、D ×1 存疑、H ×1 存疑、N ×1 存疑）
- **B 类（用词/搭配错）**：12 处，其中**存疑 8 处**
- **C 类（不自然）**：15 处，其中**存疑 7 处**
- 合计 37 处，其中存疑 20 处。

**两篇完全无 A 类问题**（article_06、article_12）；**article_18 无 B 类问题**。

### 最严重的 3 处

1. **article_30 [31] 平行结构破坏，句子不成立**
   `That figure is clear evidence that demand for the fuel is outpacing supply, and not merely the demand for crude oil itself.`
   第二个并列项 `and not merely the demand for crude oil itself` 被写成与 `supply` 并列，却没有谓语，句子在句法上无法成立。

2. **H_运动与旅行 [50] 固定短语误用**
   `These small certainties maintain a community together precisely when the larger ones have gone.`
   `maintain ... together` 不成立，固定短语为 `hold/keep ... together`；这是本组唯一一处毫无争议的硬性搭配错误。

3. **article_24 [45] 介词搭配错**
   `...though doubts have been raised from credible sources.`
   `raise doubts` 的施事须用 `by`，`from` 不能引出施动者。

（次严重：article_24 [26] `The charges belonged to a corruption scheme...`，罪名不能"属于"某个方案，应为 `arose from`。）

### 系统性问题（4 条）

1. **关系从句谓语数与被修饰名词不一致**（article_06 [26] `which obliges` 与复数宾语不协、D [3] `which determines` 与并列先行项不协）。定向生成篇尤甚。
2. **伪古雅/拉丁化词汇堆砌**：`commence`、`utilise` 类词在 H 篇集中出现（`commenced`×2、`conveyed`、`undertaken`×2、`relinquished`、`narrated`、`executes`），且 `commenced to be filled` 已构成搭配错误；`approximately` 一篇内重复 4 次。
3. **英美拼写与语域混用**：article_06 英式全篇中出现 `honor`（应为 `honour`）；H 篇英国背景却用 `vacation`（应为 `holiday`）；article_30 美式语境中出现 `north-east`（应为 `northeast`）。同篇内不一致属真错，仅跨篇差异不计。
4. **拉丁词源动词的宾语/介词框架错配**：`perform the memory`（article_06）、`belong to a scheme`（article_24）、`allocate funds on X`（H）、`maintain ... together`（H）、`raised from credible sources`（article_24）——均为"动词选对了、框架配错了"的同一类问题，是本组最主要的系统性缺陷。

### 已核查但明确不报错

上述"可接受变体"清单各项均在文中出现并逐一核对无误；此外 `in which` 前置结构在 8 篇中 10 处**全部正确**（无一处把动词后置介词误前置）；`one of the + 复数 + who/that` 主谓一致、`neither...nor` 就近原则、`its/it's`、逗号粘连、悬垂修饰（分词短语主语同指）均**未发现错误**；分号连接独立分句的用法全部正确。
