# 已应用的语言修复（2026-09-19）

来源：6 组子代理逐句审校（每组 8 篇、共 48 篇）+ 我本人的机械检查，**每条都由我对照原文逐条复核后才动手**。
子代理的误报未予采纳（见文末）。

## A/B 类真错误（硬伤）

| # | 篇 | 原文 | 修正 | 依据 |
|---|---|---|---|---|
| 1 | A_居家与日常器物_1 | `as though someone anticipated to return to it` | `as though someone meant to return to it` | `anticipate` 不接不定式 |
| 2 | article_10 | `the ordinary collection ... are forgotten` | `... is forgotten` | 主语中心词 `collection` 为单数 |
| 3 | article_02 | `The Catholic religious belief of his grandfather led Thomas towards the priesthood, and he attended...` | 拆分主从，使后句主语明确为 Thomas | 主语错位 |
| 4 | article_14 | `In 2036, Elon Musk recently assured an interviewer, money will no longer matter.` | `Elon Musk recently assured an interviewer that by 2036 money will no longer matter.` | 句首将来状语与 `recently` 同时限定 `assured`，时间自相矛盾 |
| 5 | article_20 | `...his judgment of her intellectual capacities, about which he had been entirely deceived` | `... in which he had been entirely deceived` | `be deceived about X` 介词宾语与先行词错位 |
| 6 | article_09 | `For older audience the habit began` | `For an older audience the habit began` | 可数名词单数缺冠词 |
| 7 | article_15 | 句 21 与句 51 近乎逐字复述同一论点（Jaccard 0.68） | 删除句 51 | 全文级重复 |
| 8 | B_饮食与烹饪 | `A salad is imported from other continents` | `The ingredients of a salad are imported from other continents` | 动作主体错位：进口的是原料 |

## 系统性：英美拼写混用（12 篇）

每篇统计英式/美式命中数，**向多数派统一**（平局取美式，与真题语料一致）。
涉及：article_01/02/04/06/09/12/16/18/23/29、K_服饰与外观、L_文学叙事。
例：article_02 `offence → offense`、article_12 `labor → labour`、article_16 `centre → center`。
复查：**48 篇均不再混用**。

## 系统性：伪古雅用词

`commence → begin`（B_饮食、C_身体_2、H_运动四处共 5 例）、
`thence → from there`、`I conceive → I take it`。
`constitute` 的若干用法（如 `walls are constituted by geography`）语法正确、
可读，属 C 类而非错误，**未改**。

## 已复核后判定为误报、未采纳

| 子代理主张 | 我的判定 |
|---|---|
| `a number of those same sites have been reborn` 主谓不一致 | **误报**——`a number of + 复数` 接复数动词是正确用法 |
| `a majority of Labor's parliamentary party are now women` 主谓不一致 | **误报**——英式中 `majority of + 集合名词` 可用复数 |
| `a prior decision that he considers to be wrong` 搭配错 | **误报**——`consider sth to be adj` 完全正确 |
| `Temperature constitutes the primary mechanism` 搭配失当 | **不采纳**——`constitute` 表"构成"在此可接受 |
| K_服饰 `the purse that women were once denied ... becomes the instrument of their enrollment` 自相矛盾 | **误报**——语义链（曾遭剥夺→获得→反被利用）自洽 |
| `a series of exhibitions and books that do` 主谓不一致 | **不采纳**——`series of + 复数` 按邻近原则用 `do` 可接受 |

> 记录保留这些误报，是因为它们说明**单靠 LLM 或单靠正则都会产生假阳性**，
> 两层的输出都必须人工过一遍。

## 修复后复核

48 篇重新跑 `check_draft.py`：**词数/句长/密度/靶词覆盖 0 处越界**。
`check_naturalness.py`：**48 篇全部通过**（中位数 0.8 个伪古雅标记/千词）。
