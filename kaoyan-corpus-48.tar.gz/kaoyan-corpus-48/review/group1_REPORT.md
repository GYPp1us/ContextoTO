# group1 语法与用法审校报告

审校对象：`/root/DSH/kaoyan-vocab/internal/grammar_review/group1/` 下 8 篇考研英语一阅读风格文章（共 446 句）。
审校方式：逐句通读，不抽样。按篇追加写入本文件。

分类口径：
- **A 类（语法错误）**：主谓不一致、时态/语态错误、冠词缺失或误用、介词搭配错、从句结构错、悬垂修饰、平行结构破坏、代词指代不明。
- **B 类（用词/搭配错）**：词义误用、固定搭配错、词性用错（如 `comprise` 当 `constitute` 用、`anticipate` 接不定式）。
- **C 类（不自然）**：伪古雅词（chamber 指房间、commence、utilise、subsequent to）、同义词反复轮换、连接词堆叠。每篇最多记 3 条。

已排除的**非错误**（可接受变体，不记为问题）：`a number of X have`、`majority of X are`、`consider X to be`、`series of X that do`、集体名词单复数两可、英式/美式拼写本身。

| 篇名 | 句数 | A 类 | B 类 | C 类 | 拼写一致性 |
|---|---|---|---|---|---|
| article_01 | 55 | 0 | 0 | 0 | 英式，一致 |
| article_07 | 58 | 0 | 0 | 0 | 英式，一致 |
| article_13 | 52 | 0 | 1 | 0 | 英式，一致 |
| article_19 | 56 | 0 | 0 | 0 | 英式，一致（[10] 地名未大写） |
| article_25 | 60 | 0 | 0 | 0 | 英式，一致 |
| A_居家与日常器物_1 | 60 | 0 | 1 | 3 | **英美混用** |
| D_情感与性格_2 | 55 | 0 | 0 | 1 | 英式，一致 |
| I_宗教与信仰 | 58 | 0 | 0 | 2 | 英式一致（大小写需统一） |

详见文末汇总结论。

---

## article_01（news30 改写，55 句）

逐句读完。整体质量高，未发现明确 A/B 类语法或用词错误。

**存疑（不记入计数）**
1. **[6] 时态/语义存疑**：“The strait is a major waterway: roughly one-fifth of the world's oil and liquefied natural gas **once flowed** through it.”
   前句用一般现在时 `is`，本句却用 `once flowed`，而 [9] 又用现在时 `only about two-thirds of pre-war traffic gets through`。若意在说明该海峡当前仍是主要通道，`once flowed` 会让读者误认为该流量已成历史，与 [9] 冲突。建议：`roughly one-fifth of the world's oil and liquefied natural gas flows through it`（或保留历史义但改为 `flowed` 的对照句，并补上 `before the war`）。

**已复核但判定为正确的用法（不报错）**
- [18] `Charges are permitted only for specific services actually rendered to a ship` —— 状态被动，正确。
- [20] `Its insistence that inbound traffic be routed ... and obtain clearance` —— 坚持义名词从句用原形虚拟，两个并列动词形式一致，正确。
- [23] `leading shipping organisations recently restated` —— 复数主谓一致正确。
- [28] `cooperation and agreement, and the straits ... show` —— 主语为 the straits，复数动词正确。
- [41] `if their scale and effects are grave enough` —— 条件从句时态正确。
- [44] `more likely to raise ... than to lower them` —— 比较结构平行正确。

**英美拼写一致性**：全文英式（`defence` [42]、`organisations` [23]、`neighbours` [12]、`licence` [31]、`organised` [54]）自洽；[23] `International Maritime Organization` 为专有名词固定拼写，不算混用。**无问题。**

**本篇结论：未发现确凿错误（A 0 / B 0 / C 0；1 条存疑）。**

---

## article_07（news30 改写，58 句）

逐句读完。**未发现确凿的 A/B/C 类错误。**

**存疑（不记入计数）**
1. **[24] 标点/结构存疑**：“a congressional map that a state adopted, **which** a lower court found was drawn to favour one party.” 语法上 `which` 作 `was drawn` 的主语、`a lower court found` 为插入语，成立；但缺少逗号会让 `found was drawn` 连读而瞬时歧义。建议改为 `which, a lower court found, was drawn to favour one party`，或拆句 `...; a lower court found that it was drawn to favour one party.`
2. **[39] 搭配存疑**：“The Court's refusal to disturb the Boston ruling **fits this account** rather neatly.” `fit an account` 搭配偏松，指“与该解释相符”时更常见的说法是 `is consistent with this account`。属可接受变体，不断言错误。

**已复核但判定为正确的用法（不报错）**
- [15] `a series of new voting rules ... that **are** challenged` —— 依任务约定，`a series of X that do` 为正确用法。
- [19] `The available data **suggest**` —— data 作复数，正确。
- [37] `What it can do is **to identify** ... and **refuse**` —— 并列不定式平行正确。
- [53] `a modest proposal ... is that election administration **be** entrusted to officials` —— 坚持/建议义名词从句原形虚拟，正确。
- [4] `had already blocked it, holding that the agency **had exceeded** the authority Congress **granted** it` —— 过去完成时与过去时先后关系正确。
- [5] `while Justice Alito, joined by Justice Thomas, dissented` —— 插入语未破坏主谓，正确。

**英美拼写一致性**：全文英式（`organisations` [16][17]、`favour` [24]、`favouring` [51]），一致。**无问题。**

**本篇结论：未发现确凿错误（A 0 / B 0 / C 0；2 条存疑）。**

---

## article_13（news30 改写，52 句）

**B 类（用词/搭配错）**

1. **[32] 搭配与主语错位（本篇最严重）**：“**A private group that uses a painting bought for a public collection as an instrument of advertising raises an obvious objection.**”
   `raise an objection` 是固定搭配，义为“（人/机构）提出反对”，主语必须是有意志的施事者。此处主语是 “A private group”，字面读成“这家私人集团提出了反对”，与上下文（下文 [33] “The deeper problem is that the taxpayer funds 90 per cent of the campaign” 是在**针对该集团**提出反对）正好相反——反对是冲着这家集团来的，不是它提出的。
   最小修改：`The practice of a private group that uses a painting bought for a public collection as an instrument of advertising **invites** an obvious objection.`（或 `... **meets with** an obvious objection.`）

**存疑（不记入计数）**
2. **[3] 专有名词大小写存疑**：“The **ministry of culture** had already classified ...” 作为法国政府部门专名，通例作 `the Ministry of Culture`。全文他处无对应大写形式，故仅标存疑。
3. **[8] 用词存疑**：“Caillebotte's reputation has **followed a curious line**.” 表达“经历了一条奇特的轨迹”时，`line` 用在此处不自然，常规说法为 `has followed a curious course / trajectory`。属 C 类边缘，存疑不断言。
4. **[38] 悬垂修饰存疑**：“**To celebrate its arrival** in public collections, the canvas was sent on a tour ...” 目的状语 `To celebrate` 的逻辑主语是策展方，而主句主语是 `the canvas`，属典型悬垂不定式。建议 `To celebrate its arrival ..., the museum sent the canvas on a tour ...`。
5. **[44] 语义不明存疑**：“the trunk did not own the painting, but the association was useful all the same.” 前半句似为俏皮话，但字面语义无法确定（行李箱“拥有”画作一事无所指），建议改写为 `the trunk had nothing to do with the painting's making, but the association was useful all the same` 之类，或直接删去。

**已复核但判定为正确的用法（不报错）**
- [20] `the cost falls on the **general body of** taxpayers` —— 英式惯用表达，成立。
- [27] `Criticised for the gesture, Arnault broke his usual silence` —— 过去分词状语与主句主语一致，非悬垂，正确。
- [39] `proposed that it **travel** between cities by boat` —— 建议义从句原形虚拟，正确。
- [49] `Limits imposed by parliament after 2014 **have reduced**` —— 复数主谓一致正确。

**英美拼写一致性**：全文英式（`labour` [9]、`Criticised` [27]、`lorry` [40]、`per cent` [5]），一致。**无问题。**

**本篇结论：A 0 / B 1（[32]）/ C 0；另 4 条存疑。**

---

## article_19（news30 改写，56 句）

**A/B/C 类：未发现确凿错误。**

**拼写/大小写（不计入 A/B/C 计数，但属确凿的非标准写法）**

1. **[10] 专有名词未大写**：“The route runs along the Silk Road towards **east Asia** and across the Indian Ocean towards **south-east Asia**.”
   `East Asia`、`South-East Asia` 是专有地名，通例两词均大写（同篇 [9] 的 `Asia` 已大写，[13] 的 `European` 亦然）。最小修改：`towards East Asia ... towards South-East Asia`。
   （同篇 [9] `across Asia over more than two millennia` 无问题。若系全文统一的“小写方向词”策略则属风格选择，但本句 `east Asia` 与 `Asia` 并置，仍以改为大写为妥。）

**存疑（不记入计数）**
2. **[21] 同义堆叠存疑**：“helped the incoming settlers to **adjust and adapt** to an unfamiliar environment” —— `adjust` 与 `adapt` 在此近义重复，属 C 类边缘（同义词反复）。建议保留其一：`helped the incoming settlers to adapt to an unfamiliar environment`。因属可接受变体，不断言为错误，故不记入 C 类计数。
3. **[49] 省略存疑**：“offers the appearance of change and **the substance of none**.” `none` 回指 `change`，句式偏文但可解。存疑，不报错。

**已复核但判定为正确的用法（不报错）**
- [2] `Visitors had little reason to ask ... and still less to ask ...` —— `still less` 用于否定后的追加否定，正确。
- [22] `A digital exhibition marking 160 years ... **restores**` —— 主语为单数 `exhibition`，插入的 `marking` 短语不影响主谓一致，正确。
- [48] `substitute the vocabulary of decolonisation **for** the labour of research` —— `substitute A for B`（以 A 代 B）搭配正确。
- [43] `each of these imposes its own conditions` —— `each of` + 单数动词，正确。
- [33] `insists ... that examining the ideas ... **matters** more than adding texts` —— 动名词短语作主语用单数，正确。

**英美拼写一致性**：全文英式（`labour` [2][48]、`programme` [36]、`colonised`/`marginalised`、`towards` [10]），一致。**无问题。**

**本篇结论：A 0 / B 0 / C 0；1 条大小写问题（[10]）；另 2 条存疑。**

---

## article_25（news30 改写，60 句）

逐句读完。**未发现确凿的 A/B/C 类错误。**

**存疑（不记入计数）**
1. **[1] 语义重复存疑**：“a telescope designed to provide the first **complete** map of the **entire** sky” —— `complete` 与 `entire` 语义重叠（同义反复），可直接写 `the first complete map of the sky` 或 `the first map of the entire sky`。属 C 类边缘的可读性建议，不断言为错误。
2. **[32] 主语搭配存疑**：“The mission's **price** of 488 million dollars **came from** public funds.” 严格说资金来源的是“这笔钱”而非“价格”，可改为 `The mission was financed from public funds at a cost of 488 million dollars.` 因属常见转喻，仅标存疑。
3. **[3] 数的照应存疑**：“four small satellites, each about the size of a suitcase, bound for **a separate orbit** over the poles.” 四颗卫星共用一个不定单数 `a separate orbit` 略显不协调。若四星共用一轨，宜作 `bound for a separate orbit over the poles`（与本句亦可解为“相对主载荷的另一条轨道”，故不断言）。

**已复核但判定为正确的用法（不报错）**
- [1] `has placed in polar orbit a telescope designed to ...` —— 宾语后置以避重尾，语法正确。
- [3] `each about the size of a suitcase` —— 独立主格修饰，正确。
- [24] `Detectors sensitive to 102 separate colours, most of them invisible to the human eye, will allow ...` —— 主语中心词为复数 `Detectors`，插入语未影响一致，正确。
- [35] `many smaller projects, each with a reasonable chance of a real result` —— `each` + 独立主格，正确。
- [39] `the industry to which it belongs` —— 介词后关系代词，正确。
- [43] `near minus 210 degrees Celsius` —— 读数表达可接受。

**英美拼写一致性**：全文英式（`colours` [24]、`rainbow-coloured` [25]、`kilometres` [13]、`defence` [33]、`programme` [40]、`motorway` [40]、`aluminium` [44]、`judgment` 为英式法律/通用拼法），一致。**无问题。**
另注：全篇 `the earth`、`the sun` 一律小写（[4][44][48]），前后一致，属刊物体例选择，不作错误计。

**本篇结论：未发现确凿错误（A 0 / B 0 / C 0；3 条存疑）。**

---

## A_居家与日常器物_1（定向生成，60 句）

**B 类（用词/搭配错）**

1. **[24] 动词句型错（本篇最严重）**：“The toilet had been left with its lid down, as though someone **anticipated to return** to it.”
   `anticipate` 不接不定式，其后只能接名词/动名词或 that 从句（`anticipate returning` / `anticipated that someone would return`）。
   最小修改：`as though someone **expected to return** to it.` 或 `as though someone **anticipated returning** to it.`
   （按任务给定的分类口径记入 B；若按“动词句型”归类亦可记为 A。）

**C 类（不自然）**

2. **[5] `constitute` 语义误用/同义反复**：“the house **constituted an archive of a family rather than a mere container of objects**.”
   `constitute` 义为“构成、组成（整体）”，主语通常是部分、要素（`Three chapters constitute the book.`）。此处主语 `the house` 即整体本身，用作“相当于/无异于”时不地道，属 `comprise`/`constitute` 混用一族的用词问题。最小修改：`the more the house **amounted to** an archive of a family rather than a mere container of objects`（或 `... functioned as an archive ...`）。
3. **[17] 美式拼写+被动式不自然**：“A kitchen, as an anthropologist might remark, is a place where memory is **practiced** rather than simply stored.”
   ① `practiced` 为美式拼写，与本篇英式取向（[40] `labour`）冲突；② `memory is practiced` 被动化后语义含混（“记忆被练习”），此处宜用主动。最小修改：`a place where we **practise** memory rather than simply store it`。
4. **[31] 同词反复轮换（一句内五次 `record`）**：“...hold the most detailed **record**, precisely because no one thought them worth **recording**; they reveal a routine that no document **records**, because no one ever considered that routine worth describing.”
   同一句内 `record`（名/动）出现三次，加之全篇 [15][31][44][47] 反复以 `record` 承载“记录/史录”义，属典型的同义词轮换缺失。最小修改：把末句改为 `they reveal a routine that no document **captures**, because no one ever thought that routine worth describing.`

**拼写混用（英美并存，非 A/B/C 计数）**

5. **同一篇内英式与美式拼写并存**：`organize` [9]（美式 -ize，与英式 `organise` 相对）、`odor` [48]（美式；英式 `odour`）、`practiced` [17]（美式；英式 `practised`），而 [40] 用英式 `labour`。若目标为英式英语，应统一为 `organise` / `odour` / `practised`。

**存疑（不记入计数）**
- **[44] `culinary utensil`**：“a pan is a **culinary utensil**” 属生硬搭配（`culinary` 通常直接修饰 `skill/tradition/art`），常规说法为 `a kitchen utensil` 或 `a cooking utensil`。存疑，不断言。
- **[23] `permanent ring` / [30] `softens exactly where...`**：描写可解，无语法问题。

**已复核但判定为正确的用法（不报错）**
- [6] `each of these represented` —— `each of` + 单数动词，正确。
- [9] `The material remains of ordinary domestic life ... **do** not simply accompany memory` —— 复数主谓一致正确。
- [40] `clearing a house involves not only physical **labour** but a series of small historical interpretations` —— `not only ... but ...` 并列项均为名词短语，平行正确。
- [53] `the furniture **has** been distributed, the clothing donated, and the jars and bowls **packed** into boxes` —— 后两项省略 `has been` 的并列被动，正确。
- [56] `we break a series of connections between objects and the individuals who used them` —— `a series of` + 复数，正确。

**本篇结论：A 0 / B 1（[24]）/ C 3（[5][17][31]）；另 1 条英美拼写混用与 2 条存疑。**

---

## D_情感与性格_2（定向生成，55 句）

**C 类（不自然）**

1. **[5] 罕见/古雅名词用词不当**：“The **impress** of that design is visible in the ordinary statistics of leisure.”
   `impress` 作名词（义为“印记、痕迹”）在现代英语中已属罕用文雅用法，此处显系想表达“印痕/影响”，正常写法为 `imprint` 或 `impression`。最小修改：`The **imprint** of that design is visible in the ordinary statistics of leisure.`

**存疑（不记入计数）**
2. **[12] 及物动词缺宾语存疑**：“the promise of luck **arouses** more than its realisation ever does.” `arouse` 通常为及物（`arouse interest/suspicion`），此处不带宾语，只能理解为省略（`arouses [excitement]`）。最小修改：`the promise of luck **excites** more than its realisation ever does`，或补宾语 `arouses more **eagerness**`。
3. **[19] 介词搭配存疑**：“the raw material **from which** engagement **is refined**.” 若与 `sugar is refined from cane` 类比可辩护，但更自然的说法是 `the raw material **that is refined into** engagement`。存疑，不断言。
4. **[38] 逗号粘连存疑**：“Engineers optimise a metric, the metric rewards whatever holds a gaze for a fraction longer, and the cumulative effect is a culture that has difficulty sustaining an argument, a friendship or a silence.”
   前两个独立分句仅以逗号相连，形式上属逗号粘连（comma splice）；但同篇 [34] 使用了同样的意合链式结构（`The harm is acknowledged, regret is expressed, ... and the hearing concludes`），可见系作者刻意的修辞装置，故此处不判为确凿错误，仅标存疑。若要求严格，可将首个逗号改为分号。

**已复核但判定为正确的用法（不报错）**
- [1] `Nobody who has observed a stranger interrupt a conversation ... requires persuading that ...` —— 感官动词 + 省 to 不定式正确；`require` + 动名词表被动（BrE）正确。
- [6] `The hours once devoted to conversation, to reading, and to nothing in particular **have** been transferred` —— 主语中心词 `hours` 复数，正确。
- [24] `loses a capacity for reflection that it is never permitted to exercise` —— 关系从句中 `it` 回指 `a mind`，正确。
- [29] `What distinguishes the present moment is not that desire is manufactured ... but that the manufacturing is now continuous` —— `not that ... but that ...` 表语从句平行正确。
- [44] `The familiar advice to delete ..., to set a timer, to place ... **treats** a collective problem` —— 主语 `advice` 不可数单数，正确。
- [50] `a capacity ... is worth defending ... and that such a capacity is acquired slowly` —— `be worth doing` 正确。

**英美拼写一致性**：全文英式（`realisation` [12]、`personalised` [29]、`optimise` [38]、`scepticism` [16]、`fortnight` [46]、`application` [20]），一致。**无问题。**

**本篇结论：A 0 / B 0 / C 1（[5]）；另 3 条存疑。**

---

## I_宗教与信仰（定向生成，58 句）

**A/B 类：未发现确凿错误。**

**C 类（不自然）**

1. **[27] 生僻词误用（边缘）**：“Anthropologists have long noted that the **deed** of participation changes people far more than the doctrine they are asked to accept.”
   此处要表达的是“参与这一行为”，而 `deed` 义为“业绩、事迹”或“契据”，不表“行为/举动”这一中性义（正确用词为 `act`、`participation` 本身）。与姊妹篇 D_情感与性格_2 [5] 的 `impress` 属同一类“选生僻词求雅”的倾向。最小修改：`the **act** of participation changes people far more than the doctrine they are asked to accept`。
2. **[46] 同词反复**：“These ceremonies work, when they work, because they borrow the very structure they have officially renounced, and **the structure performs the essential work**.”
   `work`（动词“奏效”/名词“作用”）与 `structure` 在同一句内重复，末句近乎赘述。最小修改：删去 `, and the structure performs the essential work`，或改为 `..., and it is that borrowed structure that does the essential work.`

**拼写/大小写（不计入 A/B/C 计数）**

3. **[14][21] 专有名词未大写**：“A congregation that reads from **the bible**”（[14]）、“A funeral therefore borrows from **the bible**”（[21]）。
   指基督教《圣经》这一特定书名时通例作 `the Bible`。
4. **[54] 同句内大小写不统一**：“**Churches**, **synagogues** and **mosques** already possess the buildings ...”——并列三项中仅第一项大写，句内不一致；[38] 亦作 `Churches`，而 [14][18][48] 作小写 `church`。建议全篇统一：泛指宗教机构时一律小写 `churches, synagogues and mosques`，或一律大写。（[17] `the devil`、[18] `a hell of their own making` 小写属世俗报刊通行体例，不报错。）

**存疑（不记入计数）**
5. **[7] 同词反复存疑**：“a social instrument, refined over centuries, for **managing** experiences that no modern institution has learned to **manage** as well.” 一句内 `manage` 两次。系刻意呼应，存疑不报错。
6. **[35] 语义存疑**：“for a **spell** of collective silence cannot be manufactured on demand.” `spell`（一段时间）与 `manufactured` 语义张力较大，若指“一段集体沉默”宜作 `a stretch of collective silence`。属可接受变体，存疑。

**已复核但判定为正确的用法（不报错）**
- [2] `A congregation of many hundreds, many of whom would describe themselves as ... , **stood** for "Amazing Grace"` —— 主语中心词单数 `A congregation`，插入的非限制性从句未影响一致，正确。
- [37] `**None of this constitutes** an argument for piety` —— `none of this` + 单数动词，正确。
- [9] `it constitutes the original substance out of which the idea of the divine is fashioned` —— constitute 用法正确（部分/要素构成整体）。
- [10] `did not initially invent a deity and **subsequently construct** churches to house it` —— `did not` 辖域内的并列原形，正确。
- [45] `the number of humanist funerals **has grown**` —— `the number of` + 单数，正确。
- [53] `to recognize that practice and conviction can be separated ..., and that a person may sing a hymn without asserting a metaphysics` —— 两个 that 从句平行，正确。

**英美拼写一致性**：全文英式（`recognize` [53] 属 -ize 通拼，`livestreamed`、`personnel` 无变体冲突），**无问题**。

**本篇结论：A 0 / B 0 / C 2（[27][46]）；另 2 条大小写问题与 2 条存疑。**

---

## 汇总

| 篇名 | 句数 | A 类 | B 类 | C 类 | 其他（拼写/大小写） |
|---|---|---|---|---|---|
| article_01 | 55 | 0 | 0 | 0 | 无（1 存疑） |
| article_07 | 58 | 0 | 0 | 0 | 无（2 存疑） |
| article_13 | 52 | 0 | 1 | 0 | 无（4 存疑） |
| article_19 | 56 | 0 | 0 | 0 | 1（[10] 大小写） |
| article_25 | 60 | 0 | 0 | 0 | 无（3 存疑） |
| A_居家与日常器物_1 | 60 | 0 | 1 | 3 | 1（英美拼写混用） |
| D_情感与性格_2 | 55 | 0 | 0 | 1 | 无（3 存疑） |
| I_宗教与信仰 | 58 | 0 | 0 | 2 | 1（大小写 2 处） |
| **合计** | **446** | **0** | **2** | **6** | **3 类** |

**总评**
- 8 篇共 446 句逐句读完，仅确认 2 处 B 类、6 处 C 类；**A 类语法错误为 0**。
- 主谓一致、时态、虚拟语气（`insistence that ... be routed`、`proposal ... be entrusted`）、比较结构平行、关系从句、非谓语状语均无实质错误，整体语法控制力强。
- 系统性倾向有三条：① 偶发“选生僻/文雅词求雅”（`impress`、`deed`）；② 偶发同词反复（`record`、`manage`、`work`）；③ 定向生成的三篇专有名词大小写与英美拼写不够统一。news30 改写的五篇拼写一致性反而最好。
- 唯一确凿的用词硬伤是 A_居家与日常器物_1 [24] 的 `anticipated to return`（anticipate 不接不定式）。
